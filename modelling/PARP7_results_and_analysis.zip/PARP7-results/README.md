# PARP7 comparative model — results and analysis

Every model, log, score, docked pose, interaction profile and figure behind the
manuscript and thesis chapter. The code that produced all of it is in the
companion archive `PARP7-comparative-model`.

---

## Start here

| File | What it is |
|---|---|
| `models/PARP7_refined_holo.pdb` | **the final model**: protein + RBN-2397, residues 462–648 |
| `models/PARP7_refined_receptor.pdb` | the same, protein only — the docking receptor |
| `docking/vina_box.conf` | the search box. Reuse it unchanged for the whole campaign |
| `interactions/interaction_tables.txt` | the measured binding mode, all four structures side by side |

---

## Contents

```
models/
  PARP7_FINAL_holo.pdb          model B99990098 as built (protein + ligand)
  PARP7_FINAL_receptor.pdb      as built, protein only — the file sent to MolProbity and ProSA
  PARP7_refined_holo.pdb        after restrained minimisation
  PARP7_refined_receptor.pdb    after restrained minimisation, protein only
  PARP7_refined_receptor_H.pdb  with the hydrogens used during minimisation
  AF_PARP7_ART.pdb              AlphaFold control, ART domain
  candidates/                   the three finalists (candidate3 = B99990098)
  ensemble_top20/               the twenty best-scoring members of the ensemble

scores/
  ensemble_all100.csv           all 100 models: molpdf, DOPE, z-DOPE, GA341,
                                every structural criterion, and the verdict
  model_scores.csv              MODELLER's own scoring output
  selection_table_top25.csv     the leading 25, as written by 07_select_model.py

validation/
  molprobity_as_built.txt       full MolProbity report for the as-built model
  prosa_as_built.txt            ProSA-web Z-score
  dope_profiles.csv             per-residue DOPE: holo build, apo build, AlphaFold
  rescore_dope.log              protein-only rescoring, so holo and apo compare like for like
  rescore_benchmark.log         the same scoring applied to the crystal and to AlphaFold
  logs/                         select_all, validate, alphafold, gate_cand1-3, versions

docking/
  redock_seed{1,2,3}.sdf        twenty poses per run
  pose_rmsd.csv                 all 60 poses: rank, Vina score, in-place RMSD
  vina_box.conf                 the frozen search box
  reference.sdf, probe.sdf      the crystallographic pose and the re-embedded conformer

interactions/
  profile_{crystal,asbuilt,refined,docked}.txt   full measured profiles
  compare_refined_vs_crystal.txt                 residue by residue, via the alignment
  packing_audit.txt                              the measure that diagnosed the clashscore
  interaction_tables.txt                         the comparison tables used in the paper
  tables/*.csv                                   the same, machine-readable
  plip/                                          independent PLIP 3.0.1 reports
  *.json                                         every profile, structured

figures/
  Fig1–Fig7, PNG at 300 dpi and PDF
```

---

## The headline numbers

| | |
|---|---|
| Redocking RMSD, three seeds | **0.73 / 0.73 / 0.75 Å**, top-ranked every time |
| Vina score of the recovered pose | −10.87 / −10.79 / −10.81 kcal mol⁻¹ |
| Crystal contact positions recovered | 22 of 23, mean \|Δd\| 0.21 Å |
| Ligand burial | 86.1 % (624.5 of 725.4 Å²) — crystal 83.2 % |
| ProSA-web Z-score | −5.55 |
| z-DOPE | −0.698 (crystal 6V3W −1.642, AlphaFold −1.668) |
| Non-local C···C < 3.4 Å | 132 as built → **12** refined (crystal 11) |
| Pocket Cα movement on refinement | 0.164 Å |

Two assessments are still outstanding on the refined coordinates: a MolProbity
re-run and the redocking gate. Until those land, `PARP7_FINAL_holo.pdb` is the
model with a complete validation record and `PARP7_refined_holo.pdb` is the model
with the better stereochemistry.

---

## Reading the binding mode

RBN-2397 is a 4-(trifluoromethyl)pyridazin-3(2H)-one and binds as a nicotinamide
mimic. In the refined model:

- the lactam makes the bidentate anchor to **Gly533** — N30–H···O=C at 2.91 Å and
  Gly533 N–H···O29 at 2.98 Å (crystal 2.77 and 2.92 Å);
- **Ser572** OG donates a third hydrogen bond to the same carbonyl at 3.07 Å;
- the warhead π-stacks on **Phe575**: centroid 3.32 Å, interplanar angle 10.7°,
  offset 1.07 Å — and Phe575 is one of the four residues engineered into the
  template to make it PARP7-like;
- **Asp548** and **Tyr564** backbone amides engage the distal pyrimidine (2.89 Å)
  and the propanamide carbonyl (3.09 Å);
- the pyrimidinyl CF₃ makes a near-linear C–F···O=C contact to **Gly541**
  (3.06 Å, 165°).

Nearly all of these are *backbone* contacts, which is the part of a comparative
model that is most reliable.

## Provenance

Built from UniProt Q7Z3E1 and PDB 6V3W with MODELLER 10.8. Coordinates derived
from 6V3W inherit the PDB's CC0 terms; the AlphaFold model is CC BY 4.0.
