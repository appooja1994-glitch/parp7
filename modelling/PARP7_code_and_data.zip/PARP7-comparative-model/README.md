# A validated comparative model of the human PARP7 catalytic domain

Code and input data to rebuild, from scratch, the PARP7 ADP-ribosyltransferase
domain model used for structure-based virtual screening, and to reproduce every
number reported in the accompanying manuscript and thesis chapter.

No experimental structure of human PARP7 exists in the PDB. This repository
builds one by comparative modelling and — more to the point — proves that the
result can recover a crystallographic ligand pose before it is used for anything.

---

## What is here

```
scripts/     the pipeline, numbered in run order
docs/        RUNBOOK, VALIDATION and HOLO_REBUILD notes
data/
  01_sequence/   PARP7 sequence (UniProt Q7Z3E1)
  02_template/   PDB 6V3W, full entry and the cleaned chain A
  03_alignment/  the PIR alignment MODELLER reads, and the residue map
  reference/     AlphaFold AF-Q7Z3E1-F1, and the RBN-2397 reference pose
```

Results, models, logs and figures live in the companion archive
`PARP7-results`.

---

## The short version of the science

| | |
|---|---|
| Target | human PARP7 (TiPARP, ARTD14), UniProt Q7Z3E1, ART domain 462–648 |
| Template | PDB 6V3W chain A, 2.04 Å — a PARP12 catalytic fragment with four PARP7 pocket residues engineered in |
| Identity | 49.4 % over 178 aligned positions |
| Ligand | RBN-2397 (PDB chemical component QO4), co-crystallised in the template |
| Models built | 100, all in the holo state |
| Selected | B99990098 |
| Redocking gate | 0.73 / 0.73 / 0.75 Å, top-ranked in every run |

The template matters more than it looks. 6V3W is not merely the nearest
PARP-family relative: four of its pocket residues were deliberately mutated to
their PARP7 identities (570 Phe→Val, 573 Ala→Gly, 577 Gln→His, 607 Tyr→Phe,
corresponding to PARP7 Val538, Gly541, His545 and Phe575). The dominant aromatic
contact RBN-2397 makes — a parallel π-stack on the pyridazinone warhead — is made
by residue 607, one of those four. The template reproduces the PARP7 pharmacophore
because it was built to.

---

## Requirements

MODELLER needs a free academic licence key; register at
<https://salilab.org/modeller/registration.html> and use the key issued to you.
A key circulated informally will be rejected with `Invalid license key`, an error
routinely misread as a broken installation.

```bash
conda create -n parp7 --override-channels -c salilab -c conda-forge \
      modeller biopython numpy scipy
conda activate parp7
conda install -c conda-forge rdkit openbabel vina openmm pdbfixer matplotlib
pip install plip freesasa
```

`--override-channels` avoids the Anaconda default channels, whose terms of service
otherwise abort an unattended solve with `CondaToSNonInteractiveError`.

MODELLER ships Python bindings compiled against one interpreter version. Driving
it from a newer system Python fails with import errors that look like installation
damage. Run model building inside the conda environment, which supplies both.

Versions this was run with: MODELLER 10.8, Biopython 1.88, RDKit 2026.03.1,
AutoDock Vina build f458505, Open Babel 3.2.1, OpenMM 8.6, PLIP 3.0.1.

---

## Running it

```bash
bash   scripts/setup_env.sh
bash   scripts/00_fetch.sh                 # UniProt, RCSB, AlphaFold
python scripts/01_prepare_alignment.py     # cleaned template + verified alignment
N_MODELS=100 python scripts/02_model_parp7.py
python scripts/03_validate_model.py
python scripts/04_alphafold_compare.py
python scripts/07_select_model.py --all    # six structural criteria, all 100 models

for i in 1 2 3; do                         # the gate, on each candidate
  cp 03_model/candidates/candidate$i.pdb 03_model/PARP7_model_primary.pdb
  python scripts/06_redock_gate.py 2>&1 | tee 04_validation/gate_cand$i.log
done

python scripts/08_rescore_dope.py          # protein-only DOPE, measured like for like
python scripts/09_dope_profile.py          # per-residue profiles
python scripts/11_minimise_restrained.py 03_model/PARP7_FINAL_holo.pdb --out refined
python scripts/06_redock_gate.py           # the gate again: atoms moved
python scripts/12_interaction_profile.py refined_holo.pdb --lig QO4 --tag model
```

`00_fetch.sh` treats the UniProt and RCSB downloads as fatal and the AlphaFold
download as non-fatal: the AlphaFold model is a control, not an input, and its API
returns 403 to some clients.

---

## What each script does

| Script | Purpose |
|---|---|
| `setup_env.sh` | miniforge + the conda environment |
| `setup_docking.sh` | Vina, Open Babel and RDKit for the gate |
| `00_fetch.sh` | sequence, template, AlphaFold model |
| `01_prepare_alignment.py` | cleans the template and writes the PIR alignment, deriving both from one residue list; every check is a hard failure |
| `02_model_parp7.py` | builds the ensemble; pre-flight residue counting; post-build renumbering with verification |
| `03_validate_model.py` | geometry, pocket composition, chain integrity |
| `04_alphafold_compare.py` | superposition against the AlphaFold control |
| `05_place_ligand.py` | transfers the reference pose into an apo model (not needed for a holo build) |
| `06_redock_gate.py` | **the decisive test** — re-embeds the ligand and docks it back |
| `07_select_model.py` | the six structural criteria, over the whole ensemble |
| `08_rescore_dope.py` | protein-only DOPE so holo and apo builds are measured identically |
| `09_dope_profile.py` | per-residue DOPE, to localise a global deficit |
| `10_refine_loops.py` | optional MODELLER loop refinement |
| `11_minimise_restrained.py` | restrained minimisation; backbone plus a 6 Å shell held |
| `12_interaction_profile.py` | contacts, hydrogen bonds, stacking, fluorine, burial — measured, not thresholded |
| `13_compare_profiles.py` | model against crystal, residue by residue, through the alignment |
| `14_pose_to_pdb.py` | writes a docked pose out with crystallographic atom names |
| `15_interaction_summary.py` | the comparison tables used in the paper |
| `16_packing_audit.py` | non-local C···C contacts; the measure that diagnosed the clashscore |
| `17_pose_rmsd_table.py` | symmetry-corrected in-place RMSD for every pose |
| `18_figures.py`, `19_interaction_map.py` | the figures |
| `build_resmap.py` | target↔template residue map from the alignment and the observed numbering |
| `renumber_model.py` | standalone renumbering with pocket verification |

---

## The validation hierarchy

Cheapest first, most decisive last. Each level removes candidates the next would
waste effort on.

1. **GA341** — fold correctness. Saturated here: 1.000 for all 100 models.
2. **z-DOPE** — global packing. Spans only 0.434 units across the ensemble.
3. **Six structural criteria** — clash, Lys554 clearance, both Gly533 hydrogen bonds, Ser572 contact, cleft aperture. 45 of 100 pass.
4. **ProSA-web** — knowledge-based Z-score against an independent database.
5. **MolProbity** — stereochemistry and all-atom contacts.
6. **AlphaFold comparison** — agreement with an orthogonal method.
7. **Redocking gate** — can the protocol recover a known pose? **This decides.**

The selected model is the *worst* of the three finalists by z-DOPE and the best by
every functional measure. For a receptor destined for docking, pose recovery is the
criterion that should decide.

---

## Four traps, recorded because they cost real time

**The PIR header has exactly ten colon-separated fields.** Eleven — easy to produce
by writing an empty field as a doubled colon — is rejected with an error that names
neither the field nor the count.

**`structureX` must span the ligand.** MODELLER reads only template residues inside
the declared range. If the range ends at the last amino acid while the ligand sits
at 701, the ligand is never read and the build fails with a residue-count mismatch
that points nowhere near the cause.

**`CalcRMS`, not `GetBestRMS`.** `GetBestRMS` superposes before measuring and so
answers "is this the same conformer", not "is it in the same place". Here it
reported 2.50 Å where the true in-place value was 4.94 Å.

**Do not filter the ligand PDBQT on `line[:6]`.** That truncates `ENDBRANCH` to
`ENDBRA` and silently deletes the torsion tree. Match whole tokens, and check that
BRANCH and ENDBRANCH counts balance.

---

## Reproducibility note

`11_minimise_restrained.py` was re-run from scratch on `candidate3.pdb` after being
rewritten for release. It finds the same 32-residue shell, restrains the same 878
heavy atoms, and reaches −26 173 kJ/mol against the published −26 196. Its output
agrees with the published refined coordinates to **0.086 Å over the backbone and
0.092 Å over the pocket**; the overall 0.20 Å figure comes entirely from
unrestrained surface side chains, which are free to settle into equivalent minima.
Expect that much run-to-run variation away from the site and none inside it.

---

## Limitations

- The template is an engineered PARP12 construct. Outside the four substituted
  positions the site is PARP12 geometry with the PARP7 sequence threaded onto it.
- Two genuine substitutions line the site: Trp581→Pro549 and Val586→Lys554. The
  model places Lys554 Nζ 2.92 Å from the ligand ether oxygen — a PARP7-selective
  contact that *cannot* exist in the template. Treat it as a prediction to test,
  not an observation.
- A single rigid receptor will favour ligands shaped like RBN-2397.
- The gate was passed with one ligand. That shows the protocol can recover a known
  pose; it does not show it can rank a diverse library.

## Licence

Code: MIT (see `LICENSE`). Input data remain under the terms of their sources —
UniProt (CC BY 4.0), RCSB PDB (CC0), AlphaFold DB (CC BY 4.0).
