# Validation and final model selection — remaining steps

Run in order. Each step gates the next: do not proceed past a failure.

```bash
cd ~/parp7/parp7_model && conda activate parp7
```

---

## Step 1 — Structural triage of the ensemble

```bash
python scripts/07_select_model.py          # top 25 by z-DOPE
python scripts/07_select_model.py --all    # all 100, slower
```

Applies the acceptance criteria to every model, **hard structural filters
first, ranking second**. A model with excellent z-DOPE and a blocked pocket is
rejected; that is the lesson of the apo build.

| Criterion | Requirement | Why |
|---|---|---|
| Ligand present | ≥ 1 het residue | A holo build must carry it |
| Pocket residues | all 9, correct identity and number | The site must exist |
| Severe clashes | **0** below 2.2 Å | What the apo build failed (7 clashes) |
| Lys554 clearance | **≥ 3.0 Å** | The residue that blocked the apo pocket (1.20 Å) |
| Gly533 N and O | 2.5–3.5 Å | The bidentate anchor |
| Ser572 OG | 2.4–3.6 Å | Third conserved hydrogen bond |
| Tyr564–Phe575 cleft | 5.5–9.5 Å | Stacking platform separation |
| z-DOPE | ranking only | Not a filter |

Outputs `04_validation/selection_table.csv`, copies the three best survivors to
`03_model/candidates/`, and sets `PARP7_model_primary.pdb` to the leader.

**The number to look at first is Lys554.** Apo build: 1.20 Å. If the holo
models are ≥ 3.0 Å, retaining the ligand did what it was supposed to.

*If no model passes:* the holo build did not resolve the loop. Refine 550–560
explicitly with DOPELoopModel in the presence of the ligand, or treat Lys554 as
a flexible side chain during docking.

---

## Step 2 — Pocket validation of the primary

```bash
python scripts/03_validate_model.py
```

The model carries its own ligand now, so contacts are measured directly;
`05_place_ligand.py` is not needed. Expect PASS with Gly533 near 2.9 Å,
Ser572 near 3.1 Å, cleft 6.5–9 Å.

---

## Step 3 — Orthogonal cross-check

```bash
python scripts/04_alphafold_compare.py
```

Pocket Cα RMSD < 1.5 Å means the two independent methods agree. The apo build
gave 0.99 Å; expect similar.

---

## Step 4 — The redocking gate, on all three candidates

```bash
mkdir -p 04_validation
for i in 1 2 3; do
  if [ -f 03_model/candidates/candidate$i.pdb ]; then
    cp 03_model/candidates/candidate$i.pdb 03_model/PARP7_model_primary.pdb
    echo "=== candidate $i ==="
    python scripts/06_redock_gate.py 2>&1 | tee 04_validation/gate_cand$i.log
  fi
done
grep -H "top-ranked in-place RMSD" 04_validation/gate_cand*.log
```

**PASS is ≤ 2.0 Å on the top-ranked pose in all three seeds.** RMSD is computed
in place with CalcRMS; the apo build gave 4.94–4.99 Å.

Running all three candidates rather than one gives a receptor-sensitivity
result at no extra thought: if they disagree, that is a finding worth reporting
and argues for ensemble docking downstream.

---

## Step 5 — External validation servers

Only for the model that passes Step 4. These are the tier-2 checks still
outstanding, and a thesis chapter needs them — z-DOPE and GA341 alone are not
sufficient.

Upload `03_model/PARP7_model_primary.pdb` to:

| Server | URL | Report |
|---|---|---|
| MolProbity | molprobity.biochem.duke.edu | Ramachandran favoured ≥ 98 %, outliers ≤ 0.2 %, rotamer outliers < 1 %, clashscore < 10, MolProbity score < 2.0 |
| SAVES v6.1 | saves.mbi.ucla.edu | ERRAT > 90 %, Verify3D ≥ 80 % of residues ≥ 0.2, PROCHECK G-factors |
| ProSA-web | prosa.services.came.sbg.ac.at | z-score inside the cloud of X-ray structures of similar length |
| QMEANDisCo | swissmodel.expasy.org/qmean | global score ≥ 0.70 |

Strip the ligand first if a server rejects het records:

```bash
grep -v HETATM 03_model/PARP7_model_primary.pdb > 04_validation/model_protein_only.pdb
```

Record every number — they go straight into the methods section.

---

## Step 6 — Fix the final selection

```bash
cp 03_model/PARP7_model_primary.pdb 03_model/PARP7_FINAL.pdb
grep -v HETATM 03_model/PARP7_FINAL.pdb > 03_model/PARP7_FINAL_apo.pdb   # docking receptor
sha256sum 03_model/PARP7_FINAL*.pdb > 04_validation/FINAL_model.sha256
cp 05_site/vina_box.conf 04_validation/
```

Write `04_validation/FINAL_model.md` recording: which model file, its z-DOPE
and GA341, the Step 1 structural numbers, the Step 3 RMSD, the Step 4 gate
result per seed, and the Step 5 server scores. That table is the evidence for
the selection and belongs in the thesis verbatim.

From here the box, the receptor and the protocol are frozen. Any later change
means repeating Steps 4 and 5.

---

## Step 7 — What follows

1. Build the PARP12 wild-type counter-target by reverting the four engineered
   substitutions in 6V3W — same crystal, same conformation, so selectivity
   comparisons are not confounded.
2. Assemble the compound library (the long pole, 4–6 weeks).
3. Retrospective docking validation on actives and property-matched decoys.
4. Freeze the protocol, then screen.

---

## Expected results at a glance

| Measure | Apo build | Holo target |
|---|---|---|
| Lys554 to ligand | 1.20 Å | ≥ 3.0 Å |
| Severe clashes | 7 | 0 |
| Pocket Cα RMSD vs AlphaFold | 0.99 Å | ≤ 1.5 Å |
| Redocking, top pose in place | 4.94–4.99 Å | ≤ 2.0 Å |
| Best z-DOPE | −1.108 | < −1.0 |
