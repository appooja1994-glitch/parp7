# Holo rebuild — step by step

The apo model failed the redocking gate because Lys554's side chain occupied
the nicotinamide slot. Rebuilding with the ligand retained prevents that: the
side chain cannot be optimised into a space the ligand already fills.

The earlier holo attempt failed for a different, now-fixed reason — see
"What was wrong" at the end.

---

## Step 0 — Update the three scripts

From your laptop:

```bash
scp 01_prepare_alignment.py 02_model_parp7.py 06_redock_gate.py \
    ataul@admin1:~/parp7/parp7_model/scripts/
```

On the server, confirm all three landed:

```bash
cd ~/parp7/parp7_model
grep -c "structureX range extended" scripts/01_prepare_alignment.py   # 1
grep -c "residues MODELLER reads"   scripts/02_model_parp7.py         # 1
grep -c "CalcRMS"                   scripts/06_redock_gate.py         # 1
```

Any `0` means that file did not transfer.

---

## Step 1 — Preserve the apo work

```bash
conda activate parp7
mkdir -p apo_build
cp 03_model/PARP7_model_primary.pdb      apo_build/
cp 03_model/model_scores.csv             apo_build/
cp 03_model/parp7_6v3w.ali               apo_build/
cp 03_model/alignment_report.txt         apo_build/
```

The apo build is reportable: it is the evidence for the Lys554 diagnosis and
belongs in the thesis.

---

## Step 2 — Clear the previous alignment and template

```bash
rm -f 03_model/parp7_6v3w.ali 02_template/6v3wA.pdb 02_template/6v3wA_apo.pdb
rm -f 03_model/PARP7_ART.B9999*.pdb 03_model/PARP7_model_primary.pdb
```

Leave `02_template/6V3W.pdb` and `01_sequence/` alone — those are the downloads.

---

## Step 3 — Rebuild the alignment WITH the ligand

```bash
python scripts/01_prepare_alignment.py
```

Note: `KEEP_LIGAND` must be unset. Do not prefix the command with
`KEEP_LIGAND=0` this time.

Expect:

```
  het residues retained: 1 -> ['QO4 A 701']
  structureX range extended to 701 to include the ligand (protein ends at 677)
  ...
consistency check:
  residues in 02_template/6v3wA.pdb : 178 protein + 1 het = 179
  residues in the alignment entry   : 179
  structureX range 498-701 covers the ligand at 701
  match - MODELLER will accept this pair
```

The two lines that matter are the extended range and `179 = 179`.

---

## Step 4 — Smoke test

```bash
N_MODELS=5 python scripts/02_model_parp7.py
```

The pre-flight runs first and takes a second:

```
Pre-flight:
  structureX range        : 498-701
  residues MODELLER reads : 178 protein + 1 het = 179
  alignment declares      : 179 residues (1 ligand '.')
  match - proceeding
```

If it reports a mismatch it stops there and prints the cause — no 20-minute
wait to discover a problem.

MODELLER will print, once, that residue QO4 is not recognised and will be
treated as a rigid body. That is the intended behaviour, not a warning to act
on.

---

## Step 5 — Full build

```bash
python scripts/02_model_parp7.py
```

20–60 min. Requirements: best z-DOPE below −1.0, GA341 1.000.
Models come out numbered 462–648 already; no renumbering step.

---

## Step 6 — Check the obstruction is gone

This is the specific test for the thing that failed last time.

```bash
python - <<'PY'
import numpy as np
m = '03_model/PARP7_model_primary.pdb'
prot = [l for l in open(m) if l[:6]=='ATOM  ' and (l[76:78].strip() or 'C')!='H']
het  = [l for l in open(m) if l[:6]=='HETATM' and l[17:20].strip() not in ('HOH','CL')]
if not het:
    raise SystemExit('No ligand in the model - it was built apo. Re-check step 3.')
xyz = lambda l: np.array([float(l[30:38]),float(l[38:46]),float(l[46:54])])
L = np.array([xyz(l) for l in het])
k = [l for l in prot if int(l[22:26])==554 and l[12:16].strip() not in ('N','CA','C','O')]
if k:
    d = np.linalg.norm(np.array([xyz(l) for l in k])[:,None,:]-L[None,:,:],axis=2).min()
    print('Lys554 side chain to ligand : %.2f A   (apo build: 1.20 A)' % d)
    print('  %s' % ('PASS - pocket is clear' if d >= 3.0 else 'STILL BLOCKED'))
A = np.array([xyz(l) for l in prot])
dm = np.linalg.norm(A[:,None,:]-L[None,:,:],axis=2)
print('severe clashes < 2.2 A      : %d   (apo build: 7)' % int((dm<2.2).sum()))
print('ligand atoms in the model   : %d' % len(het))
PY
```

Want `Lys554 ≥ 3.0 Å` and `0` clashes.

---

## Step 7 — Validate

```bash
python scripts/03_validate_model.py
```

The model now carries its own ligand, so the contact measurements run directly.
`05_place_ligand.py` is not needed.

```bash
python scripts/04_alphafold_compare.py
```

---

## Step 8 — The gate

```bash
python scripts/06_redock_gate.py
```

It now detects the holo model, extracts the ligand as the reference pose,
strips it from the receptor, and measures RMSD **in place**:

```
model is HOLO: using its own ligand as the redocking reference
receptor: removed 36 ligand/het atoms before docking
...
top-ranked in-place RMSD : x.xx, x.xx, x.xx
```

PASS is ≤ 2.0 Å on the top-ranked pose in all three seeds.

---

## What was wrong before

The alignment's `structureX` line declares which residues MODELLER should read:

```
structureX:6v3wA:498:A:677:A:...
```

That says 498 to 677. The ligand sits at residue **701**, outside the range, so
MODELLER read 178 protein residues and never saw it — while the alignment
declared 179 (178 protein + one `.` for the ligand). Hence
`179 178`, a difference of exactly one: the ligand.

The fix sets the range end to the ligand's residue number, and adds a
chain-break `/` before the `.` as MODELLER's convention requires. The
pre-flight in `02` now counts residues inside the declared range — reproducing
MODELLER's own logic — so this class of error is caught in one second rather
than inside a traceback.

## If the gate still fails

1. Re-run Step 6. If Lys554 is clear and clashes are 0 but docking still fails,
   the problem is not the obstruction and is worth investigating separately.
2. Check protonation: `python scripts/03_validate_model.py` reports the pocket
   contacts; a wrong His532 tautomer can alter the site's electrostatics.
3. Treat Lys554 as a flexible side chain in Vina — a recognised approach for a
   single mobile residue lining a site.
4. Refine the 550–560 loop in the presence of the ligand with DOPELoopModel.
