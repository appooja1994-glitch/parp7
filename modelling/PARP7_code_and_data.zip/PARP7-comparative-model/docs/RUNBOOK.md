# PARP7 homology modelling — Linux server runbook

Builds a validated comparative model of the human PARP7 (TIPARP) ART catalytic
domain on PDB **6V3W**, and cross-checks it against AlphaFold.

There is no experimental structure of human PARP7. 6V3W is a 2.04 Å structure of
the **PARP12** catalytic fragment carrying four engineered substitutions
(F570V, A573G, Q577H, Y607F) that make its NAD+ site identical to PARP7 at those
positions, with the clinical inhibitor RBN-2397 bound. Identity over the ART
domain is **48.9 %**, with no gaps in the catalytic core.

Total: ~15 min setup, ~1 min of commands, 20–60 min unattended for the model build.

---

## Step 1 — Upload the package

From your laptop:

```bash
scp PARP7_modelling_linux.zip you@server:~/
```

On the server:

```bash
cd ~ && unzip PARP7_modelling_linux.zip && cd parp7_model
ls scripts/
```

Seven files: `setup_env.sh`, `00_fetch.sh`, `01_prepare_alignment.py`,
`02_model_parp7.py`, `03_validate_model.py`, `04_alphafold_compare.py`,
`run_modelling.sbatch`.

---

## Step 2 — Build the environment (once)

```bash
bash scripts/setup_env.sh
```

Installs Miniforge into `$HOME` if conda is absent, then creates a `parp7`
environment with MODELLER and Biopython. **No root required.**

It deliberately does not pin a Python version — conda picks one MODELLER has
bindings for. That is exactly the mismatch that makes the macOS `.dmg` fail
(it ships Python 3.8 bindings only).

Ends with:

```
  Python     : 3.1x.x
  MODELLER   : 10.x
  Biopython  : 1.8x
Environment ready.
```

**Then install your licence key.** The script prints the path; it looks like
`~/miniforge3/envs/parp7/lib/modeller-10.x/modlib/modeller/config.py`. Edit it:

```python
license = 'YOUR_KEY'
```

Free academic registration: https://salilab.org/modeller/registration.html
(the key arrives by email in about a minute).

*If the server has no outbound internet:* build the env on a machine that does,
then move it with `conda-pack`. Most clusters allow HTTPS from login nodes.

---

## Step 3 — Activate (every session)

```bash
cd ~/parp7_model
conda activate parp7
```

Everything below runs with `python`, not `python3` — inside the environment they
are the same interpreter, the one that can import both MODELLER and Biopython.

---

## Step 4 — Fetch inputs

```bash
bash scripts/00_fetch.sh
```

Downloads the PARP7 sequence (UniProt Q7Z3E1), the template (PDB 6V3W), and
optionally the AlphaFold model. **AlphaFold is allowed to fail** — it is used
only in Step 8 and blocks nothing before it.

Ends with:

```
  PARP7 sequence : 657 aa  OK
  6V3W template  : 4 engineered mutations present  OK
      SEQADV 6V3W VAL A  570  UNP  Q9H0J9    PHE   570 ENGINEERED MUTATION
      SEQADV 6V3W GLY A  573  UNP  Q9H0J9    ALA   573 ENGINEERED MUTATION
      SEQADV 6V3W HIS A  577  UNP  Q9H0J9    GLN   577 ENGINEERED MUTATION
      SEQADV 6V3W PHE A  607  UNP  Q9H0J9    TYR   607 ENGINEERED MUTATION
```

If UniProt or RCSB fail you are behind a proxy — nothing works until they don't.

---

## Step 5 — Build and verify the alignment  ← the step that matters

```bash
python scripts/01_prepare_alignment.py
```

A one-residue frameshift here yields a model that passes every stereochemical
check and is still useless. This script refuses to write a bad alignment:

The exact span depends on which residues are ordered in the deposited file —
6V3W's chain A begins around residue 498, so expect roughly PARP7 462–648:

```
template chain A: 180 observed residues, numbered 498-677
alignment: ..% identity, N gap positions
aligned span: PARP7 462-648  <->  6V3W 498-677
verifying landmarks:
  PARP7 HGTS @532 -> 6V3W HGTS @564  OK
  PARP7 GSYFA @562 -> 6V3W GSYFA @594  OK
engineered mutations -> PARP7 equivalents:
  6V3W 570 PHE->VAL   PARP7 V538   match
  6V3W 573 ALA->GLY   PARP7 G541   match
  6V3W 577 GLN->HIS   PARP7 H545   match
  6V3W 607 TYR->PHE   PARP7 F575   match
all 9 pocket residues have a template partner
PIR headers verified: 10 fields each
```

Any failure aborts with exit code 1 and nothing is written.

---

## Step 6 — Build the models

**Smoke-test first.** Two minutes, and it proves the licence and the whole chain
work before you commit an hour:

```bash
N_MODELS=5 python scripts/02_model_parp7.py
```

Then the real run:

```bash
python scripts/02_model_parp7.py
```

or, on a cluster:

```bash
sbatch scripts/run_modelling.sbatch     # edit partition/account first
```

MODELLER is single-threaded, so the job asks for one core — more will not make
it faster and only lengthens the queue wait.

Ends with:

```
100 models built. Best 5 by normalised DOPE:
  PARP7_ART.B99990042.pdb      zDOPE   -1.4xx   GA341 1.000
copied ... -> 03_model/PARP7_model_primary.pdb
```

**z-DOPE must be below −1.0.** Above 0 means the model is no better than random
for its size — go back to Step 5.

---

## Step 6b — If you built apo (KEEP_LIGAND=0)

MODELLER did not carry the inhibitor through, so the model has no ligand to
validate against and no reference pose for the redocking gate. Put it back by
superposition:

```bash
python scripts/05_place_ligand.py
```

Writes `03_model/PARP7_model_primary_withlig.pdb` (for Step 7) and
`03_model/RBN2397_reference.pdb` (the crystal pose in your model's frame — the
reference for the redocking gate).

---

## Step 7 — Validate the pocket

```bash
python scripts/03_validate_model.py
# apo build: validate the ligand-bearing copy instead
# python scripts/03_validate_model.py 03_model/PARP7_model_primary_withlig.pdb
```

MolProbity and ProSA tell you the model is a plausible protein. They cannot tell
you the nicotinamide slot is right. This measures it:

```
contacts to the retained ligand:
  Gly533 N-H  -> ligand acceptor:  2.9x A   OK
  Gly533 C=O  -> ligand donor   :  3.0x A   OK
  Ser572 OG   -> ligand O/N     :  2.7x A   OK
aromatic cleft Tyr564 <-> Phe575 centroid:  7.xx A   OK
PASS - pocket geometry is consistent with the holo template.
```

It also prints each truncation point's distance to the pocket — want > 15 Å,
which is the sanity check for the MD construct (simulate 458–648 only, with
ACE/NME caps).

On FAIL, do not dock against the model.

Then upload `03_model/PARP7_model_primary.pdb` to the generic servers:
MolProbity, SAVES v6.1, ProSA-web, QMEANDisCo.

---

## Step 8 — AlphaFold cross-check

If `00_fetch.sh` could not download it, fetch it by hand:
https://alphafold.ebi.ac.uk/entry/Q7Z3E1 → PDB download → save as
`03_model/AF-Q7Z3E1-F1.pdb`.

```bash
python scripts/04_alphafold_compare.py
```

| pocket Cα RMSD | what to do |
|---|---|
| < 1.5 Å | models agree — template model primary, AlphaFold joins the docking ensemble |
| 1.5–2.5 Å | run the retrospective validation on **both** receptors, report both |
| > 2.5 Å | stop; re-inspect the Step 5 alignment and the pocket pLDDT |

---

## Step 9 — The redocking gate  ← go/no-go for the whole campaign

```bash
conda activate parp7
bash scripts/setup_docking.sh        # once: vina, openbabel, rdkit
python scripts/06_redock_gate.py
```

Re-embeds RBN-2397 from scratch, docks it into your apo model, and compares
the result with the crystallographic pose using symmetry-corrected RMSD.

| Outcome | Meaning | Action |
|---|---|---|
| **PASS** (top pose ≤ 2.0 Å, every seed) | model + protocol reproduce the crystal pose | freeze the protocol, build the library |
| **PARTIAL** (correct pose found, not ranked first) | sampling fine, scoring weak | report honestly; pick rescoring on a benchmark, not on this |
| **FAIL** (pose never recovered) | the pocket is wrong | do not screen; re-check validation, protonation, apo collapse |

It also writes `05_site/vina_box.conf` — the box centred on the reference
ligand. Reuse it unchanged for every docking run in the project.

---

## What you end up with

| File | Use |
|---|---|
| `03_model/PARP7_model_primary.pdb` | primary docking receptor (ligand retained) |
| `02_template/6v3wA.pdb` / `_apo.pdb` | template; apo copy for the redocking gate |
| `03_model/AF_PARP7_ART.pdb` | second ensemble member / independent check |
| `03_model/parp7_6v3w.ali` + `alignment_report.txt` | methods and supplementary |
| `03_model/model_scores.csv` | the ensemble, for receptor-sensitivity testing |

Next in the main protocol: protonation, the docking box, and the RBN-2397
redocking gate — which must pass at ≤ 2.0 Å before any screening.

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `conda: command not found` | shell hook not loaded | `source ~/miniforge3/etc/profile.d/conda.sh` |
| `MODELLER could not be imported` | environment not active | `conda activate parp7` |
| `check_lic_E> ... license key` | placeholder key | edit `config.py`, see Step 2 |
| `SyntaxError` / `No module named __future__` | wrong interpreter | you are outside the env; `conda activate parp7` |
| `parp7_6v3w.ali not found` | Step 5 not run | `python scripts/01_prepare_alignment.py` |
| z-DOPE above −1.0 | bad alignment, not bad modelling | re-check Step 5 output |
| `CondaToSNonInteractiveError` | conda is pulling Anaconda's default channels | already handled: `setup_env.sh` passes `--override-channels`. If you hit it manually, add that flag |
