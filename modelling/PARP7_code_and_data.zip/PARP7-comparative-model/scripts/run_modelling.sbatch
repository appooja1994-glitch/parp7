#!/bin/bash
#SBATCH --job-name=parp7_model
#SBATCH --output=logs/parp7_model_%j.out
#SBATCH --error=logs/parp7_model_%j.err
#SBATCH --time=04:00:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#
# MODELLER's comparative modelling is single-threaded, so one core is correct -
# asking for more will not make it faster and may lengthen your queue wait.
#
#   sbatch scripts/run_modelling.sbatch
#
# Adjust the partition/account lines for your cluster before first use, e.g.
##SBATCH --partition=compute
##SBATCH --account=your_project

set -euo pipefail
cd "$SLURM_SUBMIT_DIR"

source "$HOME/miniforge3/etc/profile.d/conda.sh"
conda activate parp7

echo "host    : $(hostname)"
echo "started : $(date)"

python scripts/02_model_parp7.py
python scripts/03_validate_model.py

echo "finished: $(date)"
