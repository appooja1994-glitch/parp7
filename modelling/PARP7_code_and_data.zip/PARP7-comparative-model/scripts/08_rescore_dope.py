#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Re-score the candidates WITHOUT the ligand, so z-DOPE is comparable with the
apo build and with the -1.0 native-like threshold.

Why this is needed: the holo ensemble scores z-DOPE -0.79 to -0.36, while the
apo ensemble scored -1.11 to -0.86. No holo model falls below -1.0. Either the
protein really is strained by being built around a rigid ligand, or the BLK
ligand residue is contributing to the DOPE sum and the two ensembles are not
being measured the same way. Stripping the ligand and re-scoring settles it.

    conda activate parp7
    python scripts/08_rescore_dope.py
"""
import os
import sys
import glob

try:
    from modeller import Environ, Selection
    from modeller.scripts import complete_pdb
except ImportError:
    sys.exit("MODELLER not importable - run 'conda activate parp7' first")

root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
os.chdir(root)

targets = sys.argv[1:] or sorted(glob.glob("03_model/candidates/*.pdb"))
if not targets:
    targets = ["03_model/PARP7_model_primary.pdb"]
targets = [t for t in targets if os.path.exists(t)]
if not targets:
    sys.exit("no model files found")

env = Environ()
env.libs.topology.read(file="$(LIB)/top_heav.lib")
env.libs.parameters.read(file="$(LIB)/par.lib")

os.makedirs("04_validation/protein_only", exist_ok=True)

print("%-34s %12s %12s %12s" % ("model", "DOPE", "z-DOPE", "verdict"))
print("-" * 74)
out = []
for t in targets:
    stripped = os.path.join("04_validation/protein_only",
                            os.path.basename(t).replace(".pdb", "_protein.pdb"))
    n_het = 0
    with open(stripped, "w") as fh:
        for line in open(t):
            if line[:6] == "HETATM":
                n_het += 1
                continue
            if line[:6] in ("ATOM  ", "TER   ", "END   ", "END\n"):
                fh.write(line)
        fh.write("END\n")

    try:
        mdl = complete_pdb(env, stripped)
        sel = Selection(mdl)
        dope = sel.assess_dope()
        zdope = mdl.assess_normalized_dope()
    except Exception as e:
        print("%-34s  failed: %s" % (os.path.basename(t), e))
        continue

    verdict = "native-like" if zdope < -1.0 else "above threshold"
    print("%-34s %12.1f %12.3f %12s"
          % (os.path.basename(t), dope, zdope, verdict))
    out.append((os.path.basename(t), dope, zdope, n_het))

print()
print("ligand atoms removed before scoring: %s"
      % ", ".join("%s=%d" % (o[0], o[3]) for o in out))
print()
print("Compare with the as-built (holo, ligand included) values in")
print("03_model/model_scores.csv. If the protein-only z-DOPE drops below -1.0,")
print("the holo figures were depressed by the BLK ligand and the two ensembles")
print("were never measured the same way - report the protein-only value.")
print("If it stays above -1.0, the protein genuinely is strained by the rigid")
print("ligand restraint, which is a real finding and should be reported as one.")
