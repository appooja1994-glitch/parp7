#!/usr/bin/env bash
# Add the docking tools to the existing parp7 environment.
#   conda activate parp7 && bash scripts/setup_docking.sh
set -uo pipefail

if [ "${CONDA_DEFAULT_ENV:-}" != "parp7" ]; then
  echo "Activate the environment first:  conda activate parp7" >&2
  exit 1
fi

echo "==> installing docking tools (override-channels: no repo.anaconda.com)"
conda install --override-channels -c conda-forge -y \
      vina openbabel rdkit numpy scipy || {
  echo "conda install failed; trying pip for the python-only parts" >&2
  python -m pip install rdkit numpy scipy || exit 1
}

echo
echo "==> verifying"
command -v vina    >/dev/null && echo "  vina    : $(vina --version 2>&1 | head -1)" || echo "  vina    : NOT FOUND"
command -v obabel  >/dev/null && echo "  obabel  : $(obabel -V 2>&1 | head -1)"      || echo "  obabel  : NOT FOUND"
python - <<'PY'
for m in ("rdkit", "numpy", "scipy"):
    try:
        mod = __import__(m)
        print("  %-8s: %s" % (m, getattr(mod, "__version__", "ok")))
    except ImportError:
        print("  %-8s: NOT FOUND" % m)
PY
echo
echo "Next:  python scripts/06_redock_gate.py"
