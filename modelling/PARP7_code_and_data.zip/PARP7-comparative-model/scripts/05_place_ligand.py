#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Put RBN-2397 back into the finished model's frame.

Needed when the model was built apo (KEEP_LIGAND=0): MODELLER did not carry the
ligand through, so the model has no ligand to validate against and no reference
pose for the redocking gate. This superposes the original 6V3W onto your model
using the aligned residues, applies that transform to the inhibitor, and writes:

    03_model/PARP7_model_primary_withlig.pdb   model + ligand (for 03_validate)
    03_model/RBN2397_reference.pdb             ligand alone, in the model frame
                                               (the reference pose for redocking)

    conda activate parp7
    python scripts/05_place_ligand.py
"""
import os
import sys
import math

from Bio import Align, SeqIO
from Bio.Align import substitution_matrices
from Bio.PDB import PDBParser, Superimposer

AA3 = {'ALA':'A','ARG':'R','ASN':'N','ASP':'D','CYS':'C','GLN':'Q','GLU':'E',
       'GLY':'G','HIS':'H','ILE':'I','LEU':'L','LYS':'K','MET':'M','PHE':'F',
       'PRO':'P','SER':'S','THR':'T','TRP':'W','TYR':'Y','VAL':'V','MSE':'M'}
SKIP_HET = {'HOH','WAT','CL','NA','K','SO4','PO4','GOL','EDO','ACT','MG','ZN',
            'CA','MN','NO3','ACY','DMS','PEG','TRS','IOD','BR','FMT','CIT'}
POCKET = {532:'His532 catalytic', 533:'Gly533 bidentate anchor',
          564:'Tyr564 aromatic wall', 572:'Ser572 H-bond',
          575:'Phe575 stacking platform'}


def die(m):
    sys.stderr.write("\nABORTED: " + m + "\n"); sys.exit(1)


def read_chain(path, chain='A'):
    seq, nums, ca, het = [], [], {}, []
    seen = set()
    for line in open(path):
        rec = line[:6]
        if rec == 'ATOM  ' or (rec == 'HETATM' and line[17:20].strip() == 'MSE'):
            if line[21] != chain or line[16] not in (' ', 'A'):
                continue
            r3 = line[17:20].strip()
            if r3 not in AA3:
                continue
            key = line[22:27]
            if key not in seen:
                seen.add(key)
                seq.append(AA3[r3]); nums.append(int(line[22:26]))
            if line[12:16].strip() == 'CA':
                ca[int(line[22:26])] = (float(line[30:38]), float(line[38:46]),
                                        float(line[46:54]))
        elif rec == 'HETATM':
            if line[21] != chain:
                continue
            if line[17:20].strip() in SKIP_HET or line[17:20].strip() == 'MSE':
                continue
            het.append(line)
    return ''.join(seq), nums, ca, het


def main():
    root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
    os.chdir(root)

    fa = '01_sequence/PARP7_Q7Z3E1.fasta'
    raw = '02_template/6V3W.pdb'
    mdl = '03_model/PARP7_model_primary.pdb'
    for f in (fa, raw, mdl):
        if not os.path.exists(f):
            die("missing %s" % f)

    p7 = str(next(SeqIO.parse(fa, 'fasta')).seq)
    tseq, tnums, tca, thet = read_chain(raw)
    if not thet:
        die("no ligand found in %s" % raw)
    ligname = thet[0][17:20].strip()
    print("ligand in template: %s (%d atoms)" % (ligname, len(thet)))

    al = Align.PairwiseAligner()
    al.substitution_matrix = substitution_matrices.load('BLOSUM62')
    al.open_gap_score, al.extend_gap_score, al.mode = -11, -1, 'local'
    aln = al.align(p7, tseq)[0]
    A, B = str(aln[0]), str(aln[1])
    c = aln.coordinates
    ti, qi = int(c[1][0]), int(c[0][0])
    pairs = {}
    for a, b in zip(A, B):
        t = None if b == '-' else ti
        q = None
        if b != '-':
            ti += 1
        if a != '-':
            qi += 1; q = qi
        if t is not None and q is not None:
            pairs[q] = tnums[t]

    _, mnums, mca, _ = read_chain(mdl)
    print("model residues: %d (%d-%d)" % (len(mnums), mnums[0], mnums[-1]))

    fixed, moving, used = [], [], []
    for pn in mnums:
        tn = pairs.get(pn)
        if tn is not None and pn in mca and tn in tca:
            fixed.append(mca[pn]); moving.append(tca[tn]); used.append(pn)
    if len(fixed) < 30:
        die("only %d residue pairs for superposition - too few" % len(fixed))

    class _A(object):
        def __init__(self, c): self.coord = c
        def get_coord(self): return self.coord
    import numpy as np
    sup = Superimposer()
    sup.set_atoms([_A(np.array(x, dtype='f')) for x in fixed],
                  [_A(np.array(x, dtype='f')) for x in moving])
    rot, tran = sup.rotran
    print("superposed on %d Ca pairs, RMSD %.2f A" % (len(fixed), sup.rms))
    if sup.rms > 3.0:
        print("  WARNING: high RMSD - check that the model and template "
              "really correspond")

    out = []
    for line in thet:
        xyz = np.array([float(line[30:38]), float(line[38:46]),
                        float(line[46:54])], dtype='f')
        x, y, z = np.dot(xyz, rot) + tran
        out.append(line[:30] + "%8.3f%8.3f%8.3f" % (x, y, z) + line[54:])

    with open('03_model/RBN2397_reference.pdb', 'w') as fh:
        fh.writelines(out + ['END\n'])
    with open('03_model/PARP7_model_primary_withlig.pdb', 'w') as fh:
        for line in open(mdl):
            if not line.startswith(('END', 'CONECT', 'MASTER')):
                fh.write(line)
        fh.writelines(out + ['END\n'])
    print("wrote 03_model/RBN2397_reference.pdb")
    print("wrote 03_model/PARP7_model_primary_withlig.pdb")

    lig = [(float(l[30:38]), float(l[38:46]), float(l[46:54]))
           for l in out if l[76:78].strip() in ('N', 'O')]
    st = PDBParser(QUIET=True).get_structure('m', mdl)
    res = {r.id[1]: r for r in next(st[0].get_chains()) if r.id[0] == ' '}
    print("\ncontacts of the placed ligand (polar atoms only):")
    for n in sorted(POCKET):
        r = res.get(n)
        if r is None:
            print("  %-34s MISSING" % POCKET[n]); continue
        best = min(math.dist(a.coord, p) for a in r for p in lig) if lig else None
        print("  %-34s closest polar contact %5.2f A" % (POCKET[n], best))

    print("""
Use these for the redocking gate:
  receptor  03_model/PARP7_model_primary.pdb   (apo, ligand removed)
  reference 03_model/RBN2397_reference.pdb     (crystal pose, model frame)
Dock RBN-2397 into the receptor and require the top pose within 2.0 A
symmetry-corrected heavy-atom RMSD of the reference.
""")


if __name__ == '__main__':
    main()
