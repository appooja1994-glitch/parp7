#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Restore PARP7 numbering to models that MODELLER wrote starting from 1.

AutoModel renumbers its output from 1 unless told otherwise, so a model of
PARP7 462-648 comes out as 1-187. Every downstream step - pocket validation,
the docking box, the pharmacophore, selectivity analysis - refers to PARP7
numbering, so this must be fixed before any of them are run.

The offset is determined by aligning the model's own sequence to the PARP7
reference, not assumed, and the result is checked against known pocket
residues before anything is written.

    python scripts/renumber_model.py 03_model/PARP7_model_primary.pdb
    python scripts/renumber_model.py 03_model/PARP7_ART.B9999*.pdb
"""
import os
import sys
import glob

from Bio import Align, SeqIO
from Bio.Align import substitution_matrices

AA3 = {'ALA':'A','ARG':'R','ASN':'N','ASP':'D','CYS':'C','GLN':'Q','GLU':'E',
       'GLY':'G','HIS':'H','ILE':'I','LEU':'L','LYS':'K','MET':'M','PHE':'F',
       'PRO':'P','SER':'S','THR':'T','TRP':'W','TYR':'Y','VAL':'V','MSE':'M'}
# residue types that must be found at these PARP7 positions once renumbered
EXPECT = {532:'H', 533:'G', 538:'V', 541:'G', 545:'H',
          564:'Y', 566:'A', 572:'S', 575:'F'}


def die(m):
    sys.stderr.write("\nABORTED: " + m + "\n"); sys.exit(1)


def model_sequence(path):
    seq, nums, seen = [], [], set()
    for line in open(path):
        if line[:6] != 'ATOM  ':
            continue
        r3 = line[17:20].strip()
        if r3 not in AA3:
            continue
        key = line[21] + line[22:27]
        if key in seen:
            continue
        seen.add(key)
        seq.append(AA3[r3]); nums.append(int(line[22:26]))
    return ''.join(seq), nums


def main():
    root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
    os.chdir(root)

    targets = []
    for a in sys.argv[1:]:
        targets.extend(glob.glob(a))
    if not targets:
        targets = ['03_model/PARP7_model_primary.pdb']
    targets = [t for t in targets if os.path.exists(t)]
    if not targets:
        die("no model files found - pass a path, e.g. 03_model/PARP7_model_primary.pdb")

    fa = '01_sequence/PARP7_Q7Z3E1.fasta'
    if not os.path.exists(fa):
        die("missing %s" % fa)
    p7 = str(next(SeqIO.parse(fa, 'fasta')).seq)

    al = Align.PairwiseAligner()
    al.substitution_matrix = substitution_matrices.load('BLOSUM62')
    al.open_gap_score, al.extend_gap_score, al.mode = -11, -1, 'local'

    for path in targets:
        mseq, mnums = model_sequence(path)
        if not mseq:
            print("%s: no protein residues, skipped" % path); continue

        aln = al.align(p7, mseq)[0]
        c = aln.coordinates
        p7_start = int(c[0][0]) + 1          # 1-based PARP7 residue
        m_start_idx = int(c[1][0])
        ident = sum(1 for a, b in zip(str(aln[0]), str(aln[1]))
                    if a == b and a != '-')
        pairs = sum(1 for a, b in zip(str(aln[0]), str(aln[1]))
                    if a != '-' and b != '-')
        pct = 100.0 * ident / pairs

        if pct < 95:
            die("%s aligns to PARP7 at only %.1f%% - this does not look like a "
                "PARP7 model" % (path, pct))

        offset = p7_start - mnums[m_start_idx]
        if offset == 0:
            print("%s: already in PARP7 numbering (%d-%d), unchanged"
                  % (path, mnums[0], mnums[-1]))
            continue

        # verify the offset against known pocket residues before writing
        pos = {n + offset: mseq[i] for i, n in enumerate(mnums)}
        bad = [(k, v, pos.get(k)) for k, v in EXPECT.items()
               if k in pos and pos[k] != v]
        missing = [k for k in EXPECT if k not in pos]
        if bad:
            die("offset %+d gives wrong residues at %r - refusing to write"
                % (offset, [(k, 'expected ' + v, 'got ' + str(g))
                            for k, v, g in bad]))

        out, nres = [], 0
        for line in open(path):
            if line[:6] in ('ATOM  ', 'HETATM', 'ANISOU', 'TER   '):
                try:
                    n = int(line[22:26])
                except ValueError:
                    out.append(line); continue
                out.append(line[:21] + 'A' + ('%4d' % (n + offset)) + line[26:])
            elif line[:6] == 'CONECT':
                continue
            else:
                out.append(line)

        bak = path + '.orig'
        if not os.path.exists(bak):
            os.rename(path, bak)
        with open(path, 'w') as fh:
            fh.writelines(out)

        checked = sorted(k for k in EXPECT if k in pos)
        print("%s: renumbered %+d  ->  PARP7 %d-%d   (identity %.1f%%, "
              "verified %d/%d pocket residues%s)"
              % (path, offset, mnums[0] + offset, mnums[-1] + offset, pct,
                 len(checked), len(EXPECT),
                 '' if not missing else ', %d outside model' % len(missing)))
        print("    original kept as %s" % bak)

    print("\nNow re-run the downstream steps:")
    print("    python scripts/05_place_ligand.py")
    print("    python scripts/03_validate_model.py 03_model/PARP7_model_primary_withlig.pdb")


if __name__ == '__main__':
    main()
