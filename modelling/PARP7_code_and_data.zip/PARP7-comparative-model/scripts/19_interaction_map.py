#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""A 2D interaction map of RBN-2397 in the PARP7 site.

The ligand is laid out by RDKit from the PDB chemical component's own SMILES;
the contacts are the ones measured by 12_interaction_profile.py, placed on the
atoms they actually involve. Nothing here is drawn by hand, so the picture
cannot disagree with the table.
"""
import json, math, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.lines import Line2D
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, rdDepictor
RDLogger.DisableLog("rdApp.*")

OUT = os.environ.get("PARP7_FIGDIR", "figures")
C = {"blue": "#2a78d6", "orange": "#eb6834", "aqua": "#1baf7a", "yellow": "#eda100",
     "ink": "#0b0b0b", "ink2": "#55544e", "muted": "#8a8880",
     "grid": "#e1e0d9", "surface": "#ffffff"}
ELEM_COL = {"N": "#2a78d6", "O": "#c0392b", "F": "#1baf7a", "C": "#0b0b0b"}

PROFILE = "out/refined.json"
LIGPDB = "inputs/lig_model.pdb"

# contacts to draw: (residue label, ligand atom, kind)
HBOND = [("Gly533 O", "N30", "2.91"), ("Gly533 N", "O29", "2.98"),
         ("Ser572 OG", "O29", "3.07"), ("Asp548 N", "N16", "2.89"),
         ("Tyr564 N", "O8", "3.09"), ("His532 ND1", "N30", "3.49")]
HALO = [("Gly541 O", "F24", "3.06"), ("Ile542 N", "F24", "3.18"),
        ("Tyr564 O", "F35", "2.89"), ("Ala566 N", "F35", "3.48"),
        ("Phe565 N", "F35", "3.35")]
STACK = [("Phe575", ["C28", "N30", "N31", "C32", "C26", "C27"], "3.32 Å parallel")]
HYDROPHOB = ["Ile542", "Val551", "Cys552", "Phe547", "Phe531", "Val538", "His545"]


def build():
    ref = Chem.MolFromPDBFile(LIGPDB, removeHs=True, sanitize=False)
    names = [a.GetPDBResidueInfo().GetName().strip() for a in ref.GetAtoms()]
    smi = ("C[C@@H](COCCC(=O)N1CCN(c2ncc(C(F)(F)F)cn2)CC1)"
           "Nc1cn[nH]c(=O)c1C(F)(F)F")
    tpl = Chem.MolFromSmiles(smi)
    mol = AllChem.AssignBondOrdersFromTemplate(tpl, ref)
    rdDepictor.SetPreferCoordGen(True)
    mol2 = Chem.Mol(mol)
    mol2.RemoveAllConformers()
    Chem.SanitizeMol(mol2)
    Chem.Kekulize(mol2, clearAromaticFlags=True)   # draw alternating bonds
    rdDepictor.Compute2DCoords(mol2)
    conf = mol2.GetConformer()
    xy = {}
    for i, n in enumerate(names):
        p = conf.GetAtomPosition(i)
        xy[n] = np.array([p.x, p.y])
    return mol2, names, xy


# contacts grouped by the ligand atom they land on, so one box per anchor
GROUPS = [
    ("N30",  [("Gly533 O", "2.91"), ("His532 ND1", "3.49")], "hb"),
    ("O29",  [("Gly533 N", "2.98"), ("Ser572 OG", "3.07")], "hb"),
    ("N16",  [("Asp548 N", "2.89")], "hb"),
    ("O8",   [("Tyr564 N", "3.09")], "hb"),
    ("F24",  [("Gly541 O", "3.06"), ("Ile542 N", "3.18")], "halo"),
    ("F35",  [("Tyr564 O", "2.89"), ("Phe565 N", "3.35"),
              ("Ala566 N", "3.48")], "halo"),
]


def main():
    mol, names, xy = build()
    P = np.array([xy[n] for n in names])
    cx, cy = P[:, 0].mean(), P[:, 1].mean()
    x0, x1 = P[:, 0].min(), P[:, 0].max()
    y0, y1 = P[:, 1].min(), P[:, 1].max()

    fig, ax = plt.subplots(figsize=(9.0, 6.4))
    ax.set_aspect("equal"); ax.axis("off")

    conf = mol.GetConformer()
    for b in mol.GetBonds():
        i, j = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
        a, c = P[i], P[j]
        if b.GetBondTypeAsDouble() == 2.0:
            d = c - a; nrm = np.array([-d[1], d[0]])
            nrm = nrm / (np.linalg.norm(nrm) + 1e-9) * 0.075
            for o in (nrm, -nrm):
                ax.plot([a[0] + o[0], c[0] + o[0]], [a[1] + o[1], c[1] + o[1]],
                        color=C["ink"], lw=1.3, zorder=3, solid_capstyle="round")
        else:
            ax.plot([a[0], c[0]], [a[1], c[1]], color=C["ink"], lw=1.6, zorder=3,
                    solid_capstyle="round")
    for i, n in enumerate(names):
        el = mol.GetAtomWithIdx(i).GetSymbol()
        if el == "C":
            continue
        ax.scatter(*P[i], s=165, color=C["surface"], zorder=4, linewidths=0)
        ax.text(P[i][0], P[i][1], el, ha="center", va="center", fontsize=9,
                color=ELEM_COL.get(el, C["ink"]), weight="bold", zorder=5)

    # pyridazinone ring highlight + stacking partner
    ring = STACK[0][1]
    pts = np.array([xy[n] for n in ring]); rc = pts.mean(axis=0)
    th = np.linspace(0, 2 * math.pi, 90)
    ax.plot(rc[0] + 0.70 * np.cos(th), rc[1] + 0.70 * np.sin(th),
            color=C["orange"], lw=1.7, ls=(0, (3, 2)), zorder=2)

    # ---- leader-line layout: labels on two rails, above and below ----------
    items = [(xy[a], a, lines, kind) for a, lines, kind in GROUPS]
    items.append((rc, "__ring__", [(STACK[0][0], None)], "stack"))
    up = sorted([it for it in items if it[0][1] >= cy], key=lambda it: it[0][0])
    dn = sorted([it for it in items if it[0][1] < cy], key=lambda it: it[0][0])
    span = (x1 - x0)
    rail_y_up = y1 + 0.26 * (y1 - y0) + 2.0
    rail_y_dn = y0 - 0.26 * (y1 - y0) - 2.0
    colmap = {"hb": C["blue"], "halo": C["aqua"], "stack": C["orange"]}
    stylemap = {"hb": (0, (4, 2)), "halo": (0, (1, 1.6)), "stack": (0, (3, 2))}

    def rail(group, ry):
        n = len(group)
        if not n:
            return
        xs = (np.linspace(0.04, 0.96, n) * span + x0 if n > 1
              else np.array([(x0 + x1) / 2.0]))
        for (pos, anchor, lines, kind), lx in zip(group, xs):
            col = colmap[kind]
            txt = "\n".join(["%s  %s \u00c5" % (r, d) if d
                             else "%s\n3.32 \u00c5, parallel" % r
                             for r, d in lines])
            ax.annotate("", xy=(pos[0], pos[1] + (0.42 if ry > cy else -0.42)),
                        xytext=(lx, ry - (0.40 if ry > cy else -0.40)),
                        arrowprops=dict(arrowstyle="-", color=col, lw=1.3,
                                        linestyle=stylemap[kind],
                                        shrinkA=0, shrinkB=0),
                        zorder=2)
            ax.text(lx, ry, txt, ha="center", va="center", fontsize=8.2,
                    color=C["ink"], zorder=6, linespacing=1.45,
                    bbox=dict(boxstyle="round,pad=0.34", fc=C["surface"],
                              ec=col, lw=1.1))

    rail(up, rail_y_up)
    rail(dn, rail_y_dn)

    ax.text(x0, rail_y_dn - 2.05,
            "Hydrophobic enclosure: " + ", ".join(HYDROPHOB) +
            "\n86.1 % of the ligand surface is buried "
            "(624.5 of 725.4 \u00c5$^2$)",
            fontsize=8.2, color=C["ink2"], va="top", ha="left")

    ax.legend(handles=[
        Line2D([], [], color=C["blue"], lw=1.7, ls=(0, (4, 2)), label="hydrogen bond"),
        Line2D([], [], color=C["aqua"], lw=1.7, ls=(0, (1, 1.6)),
               label="C\u2013F\u00b7\u00b7\u00b7O/N contact"),
        Line2D([], [], color=C["orange"], lw=1.7, ls=(0, (3, 2)),
               label="\u03c0\u2013\u03c0 stacking (Phe575)")],
        loc="upper center", bbox_to_anchor=(0.5, -0.045), ncol=3, fontsize=8.4)

    ax.set_title("RBN-2397 in the refined PARP7 model: measured contacts",
                 fontsize=11, weight="bold", color=C["ink"], pad=10)
    ax.set_xlim(x0 - 2.4, x1 + 2.4)
    ax.set_ylim(rail_y_dn - 4.1, rail_y_up + 1.6)
    for ext in ("png", "pdf"):
        fig.savefig("%s/Fig7_interaction_map.%s" % (OUT, ext), dpi=300,
                    bbox_inches="tight", facecolor=C["surface"])
    print("wrote Fig7_interaction_map.png / .pdf")


if __name__ == "__main__":
    main()
