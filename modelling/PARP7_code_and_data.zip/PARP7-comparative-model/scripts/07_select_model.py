#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Structural triage of the model ensemble, and selection of candidates.

Applies the acceptance criteria to every model that MODELLER produced, in a
fixed order: hard structural filters first, then ranking by statistical
potential among whatever survives. Writes a selection table and copies the
leading candidates for the redocking gate.

    conda activate parp7
    python scripts/07_select_model.py            # top 25 by z-DOPE
    python scripts/07_select_model.py --all      # every model

Criteria, and why each is applied:
  1. Ligand present          a holo build must carry it; absence means the
                             model was built apo
  2. Pocket residues correct nine residues, right identity, right number
  3. No severe clash         no protein atom within 2.2 A of the ligand -
                             this is what the apo build failed
  4. Lys554 clearance        the residue that blocked the apo pocket
  5. Gly533 bidentate        the anchor every nicotinamide-site inhibitor makes
  6. Ser572 contact          the third conserved hydrogen bond
  7. Aromatic cleft          Tyr564-Phe575 separation
  8. z-DOPE                  ranking among survivors, not a filter
"""
import os, sys, csv, math, glob, shutil

POCKET = {532:'HIS', 533:'GLY', 538:'VAL', 541:'GLY', 545:'HIS',
          564:'TYR', 566:'ALA', 572:'SER', 575:'PHE'}
SKIP_HET = {'HOH','WAT','CL','NA','K','SO4','PO4','GOL','EDO','ACT','MG','ZN','CA'}
RING = ('CG','CD1','CD2','CE1','CE2','CZ')

LIMITS = dict(clash=2.2, lys554_min=3.0,
              g533_lo=2.5, g533_hi=3.5,
              s572_lo=2.4, s572_hi=3.6,
              cleft_lo=5.5, cleft_hi=9.5)


def d(a, b):
    return math.sqrt((a[0]-b[0])**2 + (a[1]-b[1])**2 + (a[2]-b[2])**2)


def read(path):
    prot, het = [], []
    for l in open(path):
        if l[:6] == 'ATOM  ':
            e = (l[76:78].strip() or l[12:16].strip()[0])
            if e == 'H':
                continue
            prot.append((int(l[22:26]), l[17:20].strip(), l[12:16].strip(),
                         (float(l[30:38]), float(l[38:46]), float(l[46:54]))))
        elif l[:6] == 'HETATM':
            if l[17:20].strip() in SKIP_HET:
                continue
            e = (l[76:78].strip() or l[12:16].strip()[0])
            if e == 'H':
                continue
            het.append((int(l[22:26]), l[17:20].strip(), l[12:16].strip(),
                        (float(l[30:38]), float(l[38:46]), float(l[46:54]))))
    return prot, het


def centroid(pts):
    n = len(pts)
    return tuple(sum(p[i] for p in pts)/n for i in range(3))


def assess(path):
    r = {'model': os.path.basename(path)}
    prot, het = read(path)
    r['n_lig'] = len(het)
    if not prot:
        r['fail'] = 'no protein atoms'; return r
    if not het:
        r['fail'] = 'no ligand (apo build?)'; return r

    ca = {p[0]: p for p in prot if p[2] == 'CA'}
    bad = [n for n, aa in POCKET.items() if n not in ca or ca[n][1] != aa]
    r['pocket_ok'] = not bad
    if bad:
        r['fail'] = 'pocket residues wrong/absent: %r' % bad[:4]; return r

    L = [a[3] for a in het]
    Lpolar = [a[3] for a in het if a[2][0] in ('N', 'O')]
    Lar = L

    worst, nclash = 9.9, 0
    for n, rn, an, p in prot:
        for q in L:
            dd = d(p, q)
            if dd < LIMITS['clash']:
                nclash += 1
            if dd < worst:
                worst = dd
    r['clashes'] = nclash
    r['closest'] = worst

    k = [p for p in prot if p[0] == 554 and p[2] not in ('N','CA','C','O')]
    r['lys554'] = min((d(p[3], q) for p in k for q in L), default=float('nan'))

    g = {p[2]: p[3] for p in prot if p[0] == 533}
    r['g533_N'] = min((d(g['N'], q) for q in Lpolar), default=float('nan')) if 'N' in g else float('nan')
    r['g533_O'] = min((d(g['O'], q) for q in Lpolar), default=float('nan')) if 'O' in g else float('nan')
    s = {p[2]: p[3] for p in prot if p[0] == 572}
    r['s572'] = min((d(s['OG'], q) for q in Lpolar), default=float('nan')) if 'OG' in s else float('nan')

    y = [p[3] for p in prot if p[0] == 564 and p[2] in RING]
    f = [p[3] for p in prot if p[0] == 575 and p[2] in RING]
    r['cleft'] = d(centroid(y), centroid(f)) if len(y) >= 5 and len(f) >= 5 else float('nan')

    fails = []
    if nclash > 0:                                       fails.append('clash')
    if not (r['lys554'] >= LIMITS['lys554_min']):        fails.append('Lys554')
    if not (LIMITS['g533_lo'] <= r['g533_N'] <= LIMITS['g533_hi']): fails.append('G533-N')
    if not (LIMITS['g533_lo'] <= r['g533_O'] <= LIMITS['g533_hi']): fails.append('G533-O')
    if not (LIMITS['s572_lo'] <= r['s572'] <= LIMITS['s572_hi']):   fails.append('S572')
    if not (LIMITS['cleft_lo'] <= r['cleft'] <= LIMITS['cleft_hi']): fails.append('cleft')
    r['fails'] = fails
    r['pass'] = not fails
    return r


def main():
    root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
    os.chdir(root)
    want_all = '--all' in sys.argv
    topn = 10 ** 6 if want_all else 25

    csvp = '03_model/model_scores.csv'
    if not os.path.exists(csvp):
        sys.exit('missing %s - run 02_model_parp7.py first' % csvp)
    rows = list(csv.DictReader(open(csvp)))
    rows.sort(key=lambda r: float(r['zDOPE']))
    rows = rows[:topn]
    print('assessing %d of %d models (ranked by z-DOPE)\n'
          % (len(rows), sum(1 for _ in csv.DictReader(open(csvp)))))

    out = []
    for row in rows:
        p = os.path.join('03_model', os.path.basename(row['model']))
        if not os.path.exists(p):
            print('  %s: file missing' % row['model']); continue
        a = assess(p)
        a['zDOPE'] = float(row['zDOPE']); a['GA341'] = float(row['GA341'])
        out.append(a)

    hdr = ('%-26s %8s %7s %7s %8s %7s %7s %7s %7s  %s'
           % ('model','zDOPE','lig','clash','Lys554','G533N','G533O','S572','cleft','verdict'))
    print(hdr); print('-'*len(hdr))
    for a in out:
        if 'fail' in a:
            print('%-26s %8.3f  %s' % (a['model'], a.get('zDOPE', 0), a['fail'])); continue
        print('%-26s %8.3f %7d %7d %8.2f %7.2f %7.2f %7.2f %7.2f  %s'
              % (a['model'], a['zDOPE'], a['n_lig'], a['clashes'], a['lys554'],
                 a['g533_N'], a['g533_O'], a['s572'], a['cleft'],
                 'PASS' if a['pass'] else 'fail: ' + ','.join(a['fails'])))

    good = [a for a in out if a.get('pass')]
    print('\n%d of %d assessed models pass every structural criterion' % (len(good), len(out)))

    with open('04_validation/selection_table.csv', 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=['model','zDOPE','GA341','n_lig','clashes',
                                           'closest','lys554','g533_N','g533_O','s572',
                                           'cleft','pass','fails'])
        w.writeheader()
        for a in out:
            row = {}
            for k in w.fieldnames:
                if k == 'fails':
                    row[k] = ','.join(a.get('fails', [])) or a.get('fail', '')
                else:
                    v = a.get(k, '')
                    row[k] = ('%.3f' % v) if isinstance(v, float) else v
            w.writerow(row)
    print('wrote 04_validation/selection_table.csv')

    if not good:
        print('\nNo model passes. Compare against the apo build:')
        print('  apo primary had Lys554 at 1.20 A and 7 severe clashes.')
        print('  If Lys554 is still under 3.0 A, the holo build did not resolve')
        print('  the loop and it needs explicit refinement (DOPELoopModel).')
        return 1

    good.sort(key=lambda a: a['zDOPE'])
    os.makedirs('03_model/candidates', exist_ok=True)
    print('\nleading candidates (ranked by z-DOPE among those that passed):')
    for i, a in enumerate(good[:3], 1):
        src = os.path.join('03_model', a['model'])
        dst = '03_model/candidates/candidate%d.pdb' % i
        shutil.copy(src, dst)
        print('  %d. %-26s zDOPE %7.3f  Lys554 %.2f A  ->  %s'
              % (i, a['model'], a['zDOPE'], a['lys554'], dst))

    shutil.copy(os.path.join('03_model', good[0]['model']),
                '03_model/PARP7_model_primary.pdb')
    print('\nprimary: %s -> 03_model/PARP7_model_primary.pdb' % good[0]['model'])
    print('\nNext: run the redocking gate on each candidate.')
    print('  for i in 1 2 3; do')
    print('    cp 03_model/candidates/candidate$i.pdb 03_model/PARP7_model_primary.pdb')
    print('    python scripts/06_redock_gate.py 2>&1 | tee 04_validation/gate_cand$i.log')
    print('  done')
    return 0


if __name__ == '__main__':
    sys.exit(main())
