#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
The redocking gate: can your model and your docking protocol recover the
crystallographic pose of RBN-2397?

This is the go/no-go test for the whole screening campaign. A model that
cannot reproduce a 2.04 A crystal pose produces meaningless numbers for every
compound screened against it, and it is the first thing an examiner will ask.

The ligand is re-embedded from scratch before docking, so the search has to
find the pose rather than start sitting on it.

    conda activate parp7
    python scripts/06_redock_gate.py

Pass: top-ranked pose within 2.0 A symmetry-corrected heavy-atom RMSD.
"""
import os
import sys
import subprocess
import shutil

RECEPTOR = "03_model/PARP7_model_primary.pdb"
REFPDB = "03_model/RBN2397_reference.pdb"
OUT = "05_site"
BOX = 22.5
EXHAUST = 32
SEEDS = [1, 2, 3]
PASS_RMSD = 2.0


def die(m):
    sys.stderr.write("\nABORTED: " + m + "\n"); sys.exit(1)


def need(cmd):
    if shutil.which(cmd) is None:
        die("'%s' not found. Run:  bash scripts/setup_docking.sh" % cmd)


def main():
    # REFPDB is rebound below when the model carries its own ligand;
    # without this, Python treats it as local for the whole function
    # and the apo branch raises UnboundLocalError on first read.
    global REFPDB
    root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    os.chdir(root)
    os.makedirs(OUT, exist_ok=True)

    if not os.path.exists(RECEPTOR):
        die("missing %s - run 02_model_parp7.py first" % RECEPTOR)

    # A model built holo carries the ligand itself; use that as the reference.
    # A model built apo needs the pose placed by 05_place_ligand.py.
    _modelhet = [l for l in open(RECEPTOR)
                 if l.startswith("HETATM") and l[17:20].strip() not in
                 ("HOH", "WAT", "CL", "NA", "SO4", "GOL", "EDO")]
    if _modelhet:
        os.makedirs(OUT, exist_ok=True)
        REFPDB = "%s/reference_from_model.pdb" % OUT
        with open(REFPDB, "w") as fh:
            fh.writelines(_modelhet + ["END\n"])
        print("model is HOLO: using its own ligand as the redocking reference")
        print("  %d ligand atoms extracted to %s" % (len(_modelhet), REFPDB))
    else:
        print("model is APO: no ligand HETATM records in %s" % RECEPTOR)
        if not os.path.exists(REFPDB):
            die("the receptor carries no ligand and %s is missing.\n"
                "       If you meant to test the refined HOLO model, you copied the\n"
                "       wrong file - PARP7_refined_receptor.pdb is protein only.\n"
                "       Use:  cp PARP7_refined_holo.pdb %s\n"
                "       Otherwise run 05_place_ligand.py first."
                % (REFPDB, RECEPTOR))
        print("  using the transferred pose in %s" % REFPDB)
    need("vina"); need("obabel")

    try:
        from rdkit import Chem
        from rdkit.Chem import AllChem, rdMolAlign
        from rdkit import RDLogger
        RDLogger.DisableLog("rdApp.*")
    except ImportError:
        die("rdkit not available. Run:  bash scripts/setup_docking.sh")

    # ---- reference pose, with correct bond orders -------------------------
    ref = Chem.MolFromPDBFile(REFPDB, removeHs=False, sanitize=False)
    if ref is None:
        die("could not read %s" % REFPDB)
    resn = ref.GetAtomWithIdx(0).GetPDBResidueInfo().GetResidueName().strip()
    print("ligand component: %s, %d atoms" % (resn, ref.GetNumAtoms()))

    ideal = "%s/%s_ideal.sdf" % (OUT, resn)
    if not os.path.exists(ideal):
        url = "https://files.rcsb.org/ligands/download/%s_ideal.sdf" % resn
        print("fetching bond orders from %s" % url)
        if subprocess.call(["curl", "-fsSL", "-o", ideal, url]) != 0:
            ideal = None
            print("  could not fetch; falling back to bond perception "
                  "(less reliable for aromatics)")

    if ideal and os.path.exists(ideal):
        tpl = Chem.MolFromMolFile(ideal, removeHs=True)
        if tpl is None:
            die("could not parse %s" % ideal)
        try:
            ref = AllChem.AssignBondOrdersFromTemplate(tpl, ref)
            print("bond orders assigned from the PDB chemical component")
        except Exception as e:
            die("could not match the reference to the ideal component (%s).\n"
                "       The ligand may be incomplete in the crystal." % e)
        smiles = Chem.MolToSmiles(Chem.RemoveHs(tpl))
    else:
        Chem.SanitizeMol(ref, Chem.SANITIZE_ALL ^ Chem.SANITIZE_KEKULIZE)
        smiles = Chem.MolToSmiles(Chem.RemoveHs(ref))
    print("SMILES: %s" % smiles)

    ref = Chem.RemoveHs(ref)
    conf = ref.GetConformer()
    cx = sum(conf.GetAtomPosition(i).x for i in range(ref.GetNumAtoms())) / ref.GetNumAtoms()
    cy = sum(conf.GetAtomPosition(i).y for i in range(ref.GetNumAtoms())) / ref.GetNumAtoms()
    cz = sum(conf.GetAtomPosition(i).z for i in range(ref.GetNumAtoms())) / ref.GetNumAtoms()
    print("box centre (reference centroid): %.3f %.3f %.3f" % (cx, cy, cz))

    cfg = "%s/vina_box.conf" % OUT
    with open(cfg, "w") as fh:
        fh.write("center_x = %.3f\ncenter_y = %.3f\ncenter_z = %.3f\n"
                 "size_x = %.1f\nsize_y = %.1f\nsize_z = %.1f\n"
                 % (cx, cy, cz, BOX, BOX, BOX))
    print("wrote %s  (reuse this unchanged for the whole campaign)" % cfg)

    Chem.MolToMolFile(ref, "%s/reference.sdf" % OUT)

    # ---- fresh conformer: the search must FIND the pose -------------------
    probe = Chem.AddHs(Chem.MolFromSmiles(smiles))
    ps = AllChem.ETKDGv3(); ps.randomSeed = 0xC0FFEE
    if AllChem.EmbedMolecule(probe, ps) != 0:
        die("could not embed the ligand")
    AllChem.MMFFOptimizeMolecule(probe, mmffVariant="MMFF94s", maxIters=2000)
    Chem.MolToMolFile(probe, "%s/probe.sdf" % OUT)

    # ---- prepare receptor and ligand --------------------------------------
    # Vina's PDBQT parser rejects any record it does not recognise, and
    # MODELLER writes "EXPDTA  THEORETICAL MODEL" which Open Babel carries
    # through. Strip the input to coordinates, and filter the output too.
    def strip_pdb(src, dst):
        """Protein atoms only. A holo model contains the ligand; docking it
        into a receptor that already holds the ligand would be meaningless."""
        n, dropped = 0, 0
        with open(dst, "w") as fh:
            for line in open(src):
                if line[:6] == "ATOM  ":
                    fh.write(line); n += 1
                elif line[:6] == "HETATM":
                    dropped += 1
            fh.write("END\n")
        if dropped:
            print("receptor: removed %d ligand/het atoms before docking" % dropped)
        return n

    def clean_receptor_pdbqt(path):
        """Keep only coordinate records. Match on the whole first token:
        line[:6] would truncate ENDBRANCH to ENDBRA and silently drop it."""
        allowed = {"ATOM", "HETATM", "TER", "END"}
        kept, dropped = [], set()
        for line in open(path):
            if not line.strip():
                continue
            tag = line.split()[0]
            if tag in allowed:
                kept.append(line)
            else:
                dropped.add(tag)
        with open(path, "w") as fh:
            fh.writelines(kept)
        return dropped

    rec_clean = "%s/receptor_clean.pdb" % OUT
    natoms = strip_pdb(RECEPTOR, rec_clean)
    print("receptor: %d atom records kept" % natoms)

    rec_pdbqt = "%s/receptor.pdbqt" % OUT
    lig_pdbqt = "%s/probe.pdbqt" % OUT
    if subprocess.call(["obabel", rec_clean, "-O", rec_pdbqt, "-xr", "-p", "7.4"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) != 0:
        die("obabel failed on the receptor")
    if subprocess.call(["obabel", "%s/probe.sdf" % OUT, "-O", lig_pdbqt, "-p", "7.4"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) != 0:
        die("obabel failed on the ligand")

    d = clean_receptor_pdbqt(rec_pdbqt)
    if d:
        print("receptor pdbqt: removed non-coordinate records %s" % sorted(d))

    # The ligand pdbqt is left exactly as Open Babel wrote it. Its
    # ROOT/BRANCH/ENDBRANCH/TORSDOF records define the torsion tree and
    # removing any of them makes the file unparseable.
    tags = set()
    for line in open(lig_pdbqt):
        if line.strip():
            tags.add(line.split()[0])
    nb = sum(1 for l in open(lig_pdbqt) if l.startswith("BRANCH"))
    ne = sum(1 for l in open(lig_pdbqt) if l.startswith("ENDBRANCH"))
    print("ligand pdbqt: %d BRANCH / %d ENDBRANCH, torsion tree %s"
          % (nb, ne, "balanced" if nb == ne else "UNBALANCED"))
    if nb != ne:
        die("ligand torsion tree is malformed (%d BRANCH vs %d ENDBRANCH)" % (nb, ne))

    for f, what in ((rec_pdbqt, "receptor"), (lig_pdbqt, "ligand")):
        if not any(l.startswith(("ATOM", "HETATM")) for l in open(f)):
            die("%s pdbqt has no atoms - obabel conversion failed" % what)

    # ---- dock --------------------------------------------------------------
    results = []
    for seed in SEEDS:
        out_pdbqt = "%s/redock_seed%d.pdbqt" % (OUT, seed)
        cmd = ["vina", "--receptor", rec_pdbqt, "--ligand", lig_pdbqt,
               "--config", cfg, "--exhaustiveness", str(EXHAUST),
               "--num_modes", "20", "--seed", str(seed), "--out", out_pdbqt]
        print("\ndocking, seed %d (exhaustiveness %d) ..." % (seed, EXHAUST))
        if subprocess.call(cmd, stdout=subprocess.DEVNULL) != 0:
            die("vina failed (seed %d)" % seed)

        sdf = out_pdbqt.replace(".pdbqt", ".sdf")
        subprocess.call(["obabel", out_pdbqt, "-O", sdf],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        poses = [m for m in Chem.SDMolSupplier(sdf, removeHs=True) if m is not None]
        if not poses:
            die("no poses parsed from %s" % sdf)

        rms = []
        for i, p in enumerate(poses):
            try:
                # in place: CalcRMS, NOT GetBestRMS (which superposes first)
                rms.append(rdMolAlign.CalcRMS(Chem.RemoveHs(Chem.Mol(p)), ref))
            except Exception:
                rms.append(float("nan"))
        results.append((seed, rms))
        print("  rank 1 RMSD %.2f A    best of %d poses %.2f A (rank %d)"
              % (rms[0], len(rms), min(rms), rms.index(min(rms)) + 1))

    # ---- verdict -----------------------------------------------------------
    top = [r[1][0] for r in results]
    best = [min(r[1]) for r in results]
    print("\n" + "=" * 62)
    print("top-ranked pose RMSD by seed : " + ", ".join("%.2f" % x for x in top))
    print("best pose RMSD by seed       : " + ", ".join("%.2f" % x for x in best))
    passed = sum(1 for x in top if x <= PASS_RMSD)
    print("=" * 62)
    if passed == len(top):
        print("PASS - the top pose is within %.1f A in every run." % PASS_RMSD)
        print("       The model and protocol reproduce the crystal pose.")
        print("       Freeze this protocol and proceed to the library.")
    elif any(x <= PASS_RMSD for x in best):
        print("PARTIAL - the correct pose is generated but not always ranked")
        print("          first. Report this honestly. Consider rescoring")
        print("          (Vinardo/GNINA) chosen on a benchmark, not on this.")
    else:
        print("FAIL - the crystal pose is never recovered.")
        print("       Do NOT screen against this model. Re-check the pocket")
        print("       (03_validate_model.py), the protonation, and whether the")
        print("       apo build collapsed the site.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
