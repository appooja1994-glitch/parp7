#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
OPTIONAL. Refine the two strained loops of the holo model, with the ligand kept.

The holo model's DOPE deficit relative to the apo build is concentrated in two
poorly-templated regions - the 550-560 loop and the 485-500 stretch - and is
absent from the binding site (pocket residues contribute -1.4 of +1082). The
model is already fit for docking. This is only worth running if you want the
global z-DOPE closer to the -1.0 guideline for the thesis.

    conda activate parp7
    python scripts/10_refine_loops.py

Writes refined models to 03_model/refined/. Re-score and re-run the gate after.
"""
import os
import sys

try:
    from modeller import Environ, Selection, log
    from modeller.automodel import DOPELoopModel, assess, refine
except ImportError:
    sys.exit("MODELLER not importable - run 'conda activate parp7' first")

INIMODEL = "03_model/candidates/candidate3.pdb"
N_LOOP = 30
LOOPS = [(550, 560), (485, 500)]          # PARP7 numbering

root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
os.chdir(root)
if not os.path.exists(INIMODEL):
    sys.exit("missing %s" % INIMODEL)
os.makedirs("03_model/refined", exist_ok=True)

log.verbose()
env = Environ()
env.io.atom_files_directory = [".", "03_model", "03_model/candidates", "02_template"]
env.io.hetatm = True                       # keep the ligand during refinement


class Refine(DOPELoopModel):
    def select_loop_atoms(self):
        sel = Selection()
        for lo, hi in LOOPS:
            try:
                sel.add(self.residue_range("%d:A" % lo, "%d:A" % hi))
            except Exception as e:
                print("could not select %d-%d: %s" % (lo, hi, e))
        return sel


print("refining loops %s of %s, ligand retained"
      % (", ".join("%d-%d" % l for l in LOOPS), INIMODEL))

m = Refine(env, inimodel=INIMODEL, sequence="PARP7_refined",
           loop_assess_methods=(assess.DOPE, assess.normalized_dope))
m.loop.starting_model = 1
m.loop.ending_model = N_LOOP
m.loop.md_level = refine.slow
m.make()

rows = []
for o in m.loop.outputs:
    if o["failure"] is None:
        rows.append((o["Normalized DOPE score"], o["name"]))
rows.sort()
if not rows:
    sys.exit("every loop model failed - see the log above")

print("\nbest loop models by normalised DOPE:")
for z, n in rows[:5]:
    print("  %-34s %8.3f" % (n, z))
print("\nstarting model candidate3 was -0.698")

import shutil
shutil.copy(rows[0][1], "03_model/refined/PARP7_refined_best.pdb")
print("\nbest -> 03_model/refined/PARP7_refined_best.pdb")
print("""
Now re-validate. Refinement moved atoms, so the gate must be re-run:

    python scripts/08_rescore_dope.py 03_model/refined/PARP7_refined_best.pdb
    cp 03_model/refined/PARP7_refined_best.pdb 03_model/PARP7_model_primary.pdb
    python scripts/07_select_model.py 2>&1 | head -20
    python scripts/06_redock_gate.py

Keep the refined model ONLY if it still passes the gate at <= 2.0 A AND the
pocket checks still pass. A better z-DOPE with worse pose recovery is a worse
model: the functional test is the one that matters.
""")
