#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Compare the ligand environment of the model with that of the template
crystal, residue by residue, using the MODELLER alignment to decide which
template residue corresponds to which model residue. A fixed numbering
offset would be wrong: gaps make the offset vary from 27 to 36 across this
domain."""
import csv, json, sys

AA3 = {"A":"Ala","R":"Arg","N":"Asn","D":"Asp","C":"Cys","Q":"Gln","E":"Glu",
       "G":"Gly","H":"His","I":"Ile","L":"Leu","K":"Lys","M":"Met","F":"Phe",
       "P":"Pro","S":"Ser","T":"Thr","W":"Trp","Y":"Tyr","V":"Val"}

resmap = sys.argv[1] if len(sys.argv) > 1 else "out/resmap.csv"
model_json = sys.argv[2] if len(sys.argv) > 2 else "out/refined.json"
tmpl_json = sys.argv[3] if len(sys.argv) > 3 else "out/crystal_native.json"

q2t, t2q, q_aa, t_aa = {}, {}, {}, {}
for r in csv.DictReader(open(resmap)):
    q = r["parp7_resi"]; t = r["tmpl_resi"]
    if q: q_aa[int(q)] = r["parp7_aa"]
    if t: t_aa[int(t)] = r["tmpl_aa"]
    if q and t:
        q2t[int(q)] = int(t); t2q[int(t)] = int(q)

M = json.load(open(model_json)); T = json.load(open(tmpl_json))
m = dict((r["resi"], r) for r in M["site_residues"])
t = dict((r["resi"], r) for r in T["site_residues"])

keys = sorted(set(list(m.keys()) + [t2q.get(k) for k in t if t2q.get(k)]))
print("=" * 94)
print("LIGAND ENVIRONMENT: PARP7 MODEL vs 6V3W TEMPLATE")
print("=" * 94)
print("%-11s %-12s | %8s %8s | %8s %8s | %s"
      % ("PARP7", "6V3W", "model", "xtal", "d(model)", "d(xtal)", "note"))
print("-" * 94)
same = diff = 0
rows = []
for q in keys:
    tq = q2t.get(q)
    mr = m.get(q); tr = t.get(tq) if tq else None
    if mr is None and tr is None:
        continue
    qa = AA3.get(q_aa.get(q, ""), q_aa.get(q, "?"))
    ta = AA3.get(t_aa.get(tq, ""), "-") if tq else "-"
    md = mr["min_dist"] if mr else None
    td = tr["min_dist"] if tr else None
    note = ""
    if qa != ta and tq:
        note = "substitution"
    if md is not None and td is not None:
        if abs(md - td) > 1.0:
            note = (note + "; " if note else "") + "shift %+.2f A" % (md - td)
        same += 1
    elif md is not None:
        note = (note + "; " if note else "") + "model only"
    else:
        note = (note + "; " if note else "") + "template only"
    print("%-11s %-12s | %8s %8s | %8s %8s | %s"
          % ("%s%d" % (qa, q), ("%s%d" % (ta, tq)) if tq else "(insertion)",
             "yes" if mr else "-", "yes" if tr else "-",
             ("%.2f" % md) if md is not None else "-",
             ("%.2f" % td) if td is not None else "-", note))
    rows.append({"parp7": "%s%d" % (qa, q), "tmpl": ("%s%d" % (ta, tq)) if tq else None,
                 "d_model": md, "d_xtal": td, "note": note})
print("-" * 94)
both = [r for r in rows if r["d_model"] is not None and r["d_xtal"] is not None]
if both:
    import statistics
    dd = [abs(r["d_model"] - r["d_xtal"]) for r in both]
    print("%d residues line the site in both; mean |d difference| %.2f A, max %.2f A"
          % (len(both), statistics.mean(dd), max(dd)))
    print("%d within 0.5 A, %d within 1.0 A"
          % (sum(1 for x in dd if x <= 0.5), sum(1 for x in dd if x <= 1.0)))
print("model-only : %s" % ", ".join(r["parp7"] for r in rows if r["d_xtal"] is None))
print("xtal-only  : %s" % ", ".join((r["tmpl"] or "?") for r in rows if r["d_model"] is None))
json.dump(rows, open("out/compare.json", "w"), indent=2)
