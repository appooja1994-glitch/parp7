#!/usr/bin/env bash
# Fetch every input the modelling run needs.
#
# UniProt and the PDB are REQUIRED - the script stops if either fails.
# AlphaFold is OPTIONAL: it is only used by 04_alphafold_compare.py, so a
# failure there is reported and the script carries on.
set -uo pipefail

UA='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'
mkdir -p 01_sequence 02_template 03_model 04_validation

die() { echo; echo "FAILED: $*" >&2; exit 1; }

echo "[1/4] PARP7 reference sequence (UniProt Q7Z3E1)"
curl -fsSL -A "$UA" -o 01_sequence/PARP7_Q7Z3E1.fasta \
     "https://rest.uniprot.org/uniprotkb/Q7Z3E1.fasta" \
  || die "could not reach UniProt"

echo "[2/4] Template coordinates (PDB 6V3W)"
curl -fsSL -A "$UA" -o 02_template/6V3W.pdb \
     "https://files.rcsb.org/download/6V3W.pdb" || die "could not reach RCSB"
curl -fsSL -A "$UA" -o 02_template/6V3W.cif \
     "https://files.rcsb.org/download/6V3W.cif" || true

echo "[3/4] AlphaFold model (AF-Q7Z3E1-F1)  -- optional"
AF_OK=0
AF_OUT=03_model/AF-Q7Z3E1-F1.pdb

# (a) ask the API which version is current
URL=$(curl -fsSL -A "$UA" "https://alphafold.ebi.ac.uk/api/prediction/Q7Z3E1" 2>/dev/null \
      | python3 -c "import sys,json;d=json.load(sys.stdin);print(d[0]['pdbUrl'])" 2>/dev/null) || URL=""
if [ -n "$URL" ]; then
  echo "      API reports: $URL"
  curl -fsSL -A "$UA" -o "$AF_OUT" "$URL" && AF_OK=1
fi

# (b) the API is sometimes blocked; sweep the known version suffixes.
#     AlphaFold files sit on object storage, where a MISSING file returns
#     403 (access denied), not 404 - so a 403 usually means "wrong version".
if [ "$AF_OK" -eq 0 ]; then
  for v in 6 5 4 3; do
    echo "      trying model_v$v"
    if curl -fsSL -A "$UA" -o "$AF_OUT" \
         "https://alphafold.ebi.ac.uk/files/AF-Q7Z3E1-F1-model_v$v.pdb"; then
      AF_OK=1; echo "      got model_v$v"; break
    fi
  done
fi

if [ "$AF_OK" -eq 0 ]; then
  rm -f "$AF_OUT"
  cat <<'MSG'

      AlphaFold could not be downloaded automatically.
      This does NOT block the model build - it is only needed for the
      optional cross-check in 04_alphafold_compare.py.

      To get it by hand (10 seconds):
        1. open  https://alphafold.ebi.ac.uk/entry/Q7Z3E1
        2. click the PDB download button
        3. save it as  03_model/AF-Q7Z3E1-F1.pdb
      then re-run only:  python scripts/04_alphafold_compare.py
MSG
else
  echo "      saved $AF_OUT"
fi

echo "[4/4] Verifying what was downloaded"
python3 - <<'PY'
import os, sys
from Bio import SeqIO

r = next(SeqIO.parse('01_sequence/PARP7_Q7Z3E1.fasta', 'fasta'))
assert len(r.seq) == 657, f"PARP7 length {len(r.seq)}, expected 657 - wrong isoform?"
assert str(r.seq).endswith('EEVSNTVSI'), "PARP7 C-terminus unexpected"
print(f"  PARP7 sequence : {len(r.seq)} aa  OK")

muts = [l for l in open('02_template/6V3W.pdb')
        if l.startswith('SEQADV') and 'ENGINEERED MUTATION' in l]
assert len(muts) == 4, f"expected 4 engineered mutations in 6V3W, found {len(muts)}"
print(f"  6V3W template  : 4 engineered mutations present  OK")
for m in muts:
    print("      " + m.rstrip())

af = os.path.exists('03_model/AF-Q7Z3E1-F1.pdb')
print(f"  AlphaFold model: {'present' if af else 'ABSENT (optional - see above)'}")
PY
rc=$?

echo
if [ $rc -eq 0 ]; then
  echo "Ready. Next:  python scripts/01_prepare_alignment.py"
else
  echo "Verification failed - do not continue until it passes."
  exit 1
fi
