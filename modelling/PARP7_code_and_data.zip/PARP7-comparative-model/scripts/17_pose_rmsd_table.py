#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Symmetry-corrected, in-place RMSD of every docked pose to the reference.

rdMolAlign.CalcRMS, not GetBestRMS: GetBestRMS superposes the two molecules
first, which answers "is this the same conformer" rather than "is it in the
same place". For a redocking test only the in-place value is meaningful.
"""
import sys, csv
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, rdMolAlign
RDLogger.DisableLog("rdApp.*")

refpdb, out = sys.argv[1], sys.argv[2]
sdfs = sys.argv[3:]

ref = Chem.MolFromPDBFile(refpdb, removeHs=True, sanitize=False)
rows = []
for sdf in sdfs:
    seed = sdf.split("seed")[-1].split(".")[0]
    poses = [m for m in Chem.SDMolSupplier(sdf, removeHs=True, sanitize=True) if m]
    r2 = AllChem.AssignBondOrdersFromTemplate(poses[0], ref)
    for i, p in enumerate(poses):
        score = None
        if p.HasProp("minimizedAffinity"):
            score = float(p.GetProp("minimizedAffinity"))
        elif p.HasProp("REMARK"):
            for ln in p.GetProp("REMARK").splitlines():
                if "VINA RESULT" in ln:
                    score = float(ln.split(":")[1].split()[0]); break
        rows.append({"seed": int(seed), "rank": i + 1,
                     "rmsd": round(rdMolAlign.CalcRMS(p, r2), 2),
                     "score": score})
with open(out, "w") as fh:
    w = csv.DictWriter(fh, ["seed", "rank", "rmsd", "score"]); w.writeheader()
    w.writerows(rows)
for s in sorted(set(r["seed"] for r in rows)):
    rr = [r for r in rows if r["seed"] == s]
    print("seed %d: rank1 %.2f A (%s kcal/mol), best %.2f A at rank %d"
          % (s, rr[0]["rmsd"],
             ("%.2f" % rr[0]["score"]) if rr[0]["score"] is not None else "n/a",
             min(x["rmsd"] for x in rr),
             min(rr, key=lambda x: x["rmsd"])["rank"]))
print("wrote %s (%d poses)" % (out, len(rows)))
