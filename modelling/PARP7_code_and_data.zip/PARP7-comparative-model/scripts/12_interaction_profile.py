#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
12_interaction_profile.py - characterise the RBN-2397 binding mode.

For a holo structure (protein + ligand in one PDB) this reports:

  * every residue with a heavy atom within CONTACT_CUT of the ligand, with
    its closest approach and the number of contacts at several cut-offs.
    Distances are printed rather than thresholded, so a contact that falls
    0.1 A outside a published cut-off is visible instead of silently absent.
  * hydrogen bonds by heavy-atom geometry (D...A distance, D-H...A angle
    where hydrogens are present)
  * aromatic ring stacking: centroid separation, interplanar angle and the
    lateral offset that distinguishes a true stack from an edge contact
  * organofluorine contacts to backbone carbonyls
  * ligand solvent accessibility free and bound, i.e. how deeply buried it is

Run it on the model AND on the template crystal, then compare. A model that
does not reproduce the crystallographic contact set cannot be trusted to
rank compounds that exploit those contacts.

    python 12_interaction_profile.py holo.pdb --lig QO4 --tag model --offset 0

--offset is added to this structure's residue numbers before reporting, so a
template in its own numbering can be printed in the target's numbering and
the two reports compared line for line.
"""
import sys
import os
import json
import math
import argparse

import numpy as np

CONTACT_CUT = 6.0      # residue is "in the site" if any heavy atom is this close
HYDROPHOB_CUT = 4.5    # C...C
HBOND_DA = 3.6         # donor...acceptor heavy-atom distance
HBOND_ANGLE = 120.0    # minimum D-H...A angle when hydrogens are present
RING_CENT = 6.0        # centroid separation worth reporting
HALOGEN_CUT = 4.0      # F...O

SOLVENT = ("HOH", "WAT", "DOD")
IONS = ("NA", "CL", "K", "MG", "ZN", "CA", "SO4", "PO4", "GOL", "EDO", "ACT")

# ring atom names, by residue type
PROT_RINGS = {
    "PHE": [("6", ["CG", "CD1", "CD2", "CE1", "CE2", "CZ"])],
    "TYR": [("6", ["CG", "CD1", "CD2", "CE1", "CE2", "CZ"])],
    "HIS": [("5", ["CG", "ND1", "CD2", "CE1", "NE2"])],
    "TRP": [("5", ["CG", "CD1", "CD2", "NE1", "CE2"]),
            ("6", ["CD2", "CE2", "CE3", "CZ2", "CZ3", "CH2"])],
}

# side-chain polar atoms that can donate and/or accept
SC_DONOR = {
    "ARG": ["NE", "NH1", "NH2"], "LYS": ["NZ"], "ASN": ["ND2"], "GLN": ["NE2"],
    "HIS": ["ND1", "NE2"], "SER": ["OG"], "THR": ["OG1"], "TYR": ["OH"],
    "TRP": ["NE1"], "CYS": ["SG"],
}
SC_ACCEPT = {
    "ASP": ["OD1", "OD2"], "GLU": ["OE1", "OE2"], "ASN": ["OD1"], "GLN": ["OE1"],
    "HIS": ["ND1", "NE2"], "SER": ["OG"], "THR": ["OG1"], "TYR": ["OH"],
    "MET": ["SD"], "CYS": ["SG"],
}


class Atom(object):
    __slots__ = ("name", "resn", "chain", "resi", "icode", "xyz", "elem", "het", "serial")

    def __init__(self, line):
        self.serial = int(line[6:11])
        self.name = line[12:16].strip()
        self.resn = line[17:20].strip()
        self.chain = line[21].strip()
        self.resi = int(line[22:26])
        self.icode = line[26].strip()
        self.xyz = np.array([float(line[30:38]), float(line[38:46]), float(line[46:54])])
        e = line[76:78].strip()
        if not e:
            e = self.name[0]
        self.elem = e.upper()
        self.het = line.startswith("HETATM")

    @property
    def key(self):
        return (self.chain, self.resi, self.icode, self.resn)


def read_pdb(path):
    atoms = []
    for line in open(path):
        if line.startswith(("ATOM  ", "HETATM")) and len(line) >= 54:
            a = Atom(line)
            if a.resn in SOLVENT:
                continue
            atoms.append(a)
        elif line.startswith("ENDMDL"):
            break
    return atoms


def split(atoms, ligname):
    lig = [a for a in atoms if a.resn == ligname]
    prot = [a for a in atoms if a.resn != ligname and a.resn not in IONS]
    if not lig:
        sys.exit("no residue named %s in the file" % ligname)
    # keep one copy if the ligand is present more than once
    first = lig[0].key
    lig = [a for a in lig if a.key == first]
    return prot, lig


def heavy(atoms):
    return [a for a in atoms if a.elem != "H"]


def centroid_normal(atoms):
    pts = np.array([a.xyz for a in atoms])
    c = pts.mean(axis=0)
    u, s, vt = np.linalg.svd(pts - c)
    return c, vt[2]          # smallest singular vector = plane normal


def ring_geometry(r1, r2):
    """centroid distance, interplanar angle, lateral offset"""
    c1, n1 = centroid_normal(r1)
    c2, n2 = centroid_normal(r2)
    d = np.linalg.norm(c1 - c2)
    cosang = abs(float(np.dot(n1, n2)))
    cosang = max(-1.0, min(1.0, cosang))
    ang = math.degrees(math.acos(cosang))
    v = c2 - c1
    # project the centroid separation onto each plane, take the smaller offset
    off1 = np.linalg.norm(v - np.dot(v, n1) * n1)
    off2 = np.linalg.norm(-v - np.dot(-v, n2) * n2)
    return d, ang, min(off1, off2)


def ligand_rings(lig):
    """Perceive the ligand's rings from its own geometry with Open Babel,
    then map back to PDB atom names. Falls back to a geometric search if
    Open Babel is unavailable."""
    try:
        from openbabel import openbabel as ob
    except ImportError:
        return []
    import tempfile
    tmp = tempfile.NamedTemporaryFile(suffix=".pdb", delete=False, mode="w")
    for i, a in enumerate(lig):
        tmp.write("HETATM%5d %-4s %3s %s%4d    %8.3f%8.3f%8.3f  1.00  0.00          %2s\n"
                  % (i + 1, a.name if len(a.name) < 4 else a.name,
                     a.resn, a.chain or "A", a.resi,
                     a.xyz[0], a.xyz[1], a.xyz[2], a.elem))
    tmp.write("END\n"); tmp.close()
    conv = ob.OBConversion(); conv.SetInFormat("pdb")
    mol = ob.OBMol()
    if not conv.ReadFile(mol, tmp.name):
        os.unlink(tmp.name); return []
    rings = []
    for r in mol.GetSSSR():
        idx = [i - 1 for i in r._path]
        members = [lig[i] for i in idx if 0 <= i < len(lig)]
        if len(members) != r.Size():
            continue
        rings.append({"size": r.Size(), "aromatic": bool(r.IsAromatic()),
                      "atoms": members,
                      "names": [m.name for m in members]})
    os.unlink(tmp.name)
    return rings


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdb")
    ap.add_argument("--lig", default="QO4")
    ap.add_argument("--tag", default=None)
    ap.add_argument("--offset", type=int, default=0,
                    help="added to protein residue numbers in the report")
    ap.add_argument("--json", default=None)
    args = ap.parse_args()
    tag = args.tag or os.path.basename(args.pdb)

    atoms = read_pdb(args.pdb)
    prot, lig = split(atoms, args.lig)
    protH = heavy(prot); ligH = heavy(lig)
    has_h = any(a.elem == "H" for a in prot)

    print("=" * 78)
    print("INTERACTION PROFILE  %s" % tag)
    print("=" * 78)
    print("file           : %s" % args.pdb)
    print("protein        : %d heavy atoms, %d residues%s"
          % (len(protH), len(set(a.key for a in protH)),
             "  (hydrogens present)" if has_h else "  (heavy atoms only)"))
    print("ligand         : %s %s%d, %d heavy atoms"
          % (args.lig, lig[0].chain, lig[0].resi, len(ligH)))
    if args.offset:
        print("numbering      : structure numbers %+d" % args.offset)
    print("")

    P = np.array([a.xyz for a in protH])
    L = np.array([a.xyz for a in ligH])
    D = np.linalg.norm(P[:, None, :] - L[None, :, :], axis=2)

    # ---------- 1. residue contact inventory --------------------------------
    byres = {}
    for i, a in enumerate(protH):
        m = D[i].min()
        if m > CONTACT_CUT:
            continue
        k = a.key
        e = byres.setdefault(k, {"min": 99.0, "n45": 0, "n40": 0, "atoms": [],
                                 "closest": None, "closest_lig": None})
        if m < e["min"]:
            e["min"] = m
            e["closest"] = a.name
            e["closest_lig"] = ligH[int(D[i].argmin())].name
        for j, d in enumerate(D[i]):
            if d <= HYDROPHOB_CUT:
                e["n45"] += 1
                if a.elem == "C" and ligH[j].elem == "C" and d <= 4.0:
                    e["n40"] += 1

    print("-" * 78)
    print("1. BINDING-SITE RESIDUES  (any heavy atom within %.1f A)" % CONTACT_CUT)
    print("-" * 78)
    print("%-10s %8s %7s %7s   %s" % ("residue", "closest", "<=4.5A", "C..C<=4A", "closest pair"))
    rows = []
    for k in sorted(byres, key=lambda k: byres[k]["min"]):
        e = byres[k]
        ch, resi, ic, resn = k
        label = "%s%d%s" % (resn.capitalize(), resi + args.offset, ic)
        print("%-10s %8.2f %7d %7d   %s - %s"
              % (label, e["min"], e["n45"], e["n40"], e["closest"], e["closest_lig"]))
        rows.append({"residue": label, "resn": resn, "resi": resi + args.offset,
                     "min_dist": round(e["min"], 2), "n_le_4_5": e["n45"],
                     "n_CC_le_4": e["n40"],
                     "closest_pair": "%s-%s" % (e["closest"], e["closest_lig"])})
    print("\n%d residues line the site; %d make a contact at or inside %.1f A"
          % (len(byres), sum(1 for e in byres.values() if e["min"] <= HYDROPHOB_CUT),
             HYDROPHOB_CUT))

    # ---------- 2. hydrogen bonds -------------------------------------------
    def prot_polar(a):
        don = acc = False
        if a.name == "N" and not a.het:
            don = True
        if a.name in ("O", "OXT") and not a.het:
            acc = True
        don = don or a.name in SC_DONOR.get(a.resn, [])
        acc = acc or a.name in SC_ACCEPT.get(a.resn, [])
        return don, acc

    hyd = [a for a in prot if a.elem == "H"]

    def best_angle(donor_heavy, acceptor):
        """largest D-H...A angle over hydrogens bonded to the donor"""
        best = None
        for h in hyd:
            if np.linalg.norm(h.xyz - donor_heavy.xyz) > 1.3:
                continue
            v1 = donor_heavy.xyz - h.xyz
            v2 = acceptor.xyz - h.xyz
            c = float(np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2)))
            c = max(-1.0, min(1.0, c))
            ang = math.degrees(math.acos(c))
            if best is None or ang > best:
                best = ang
        return best

    print("\n" + "-" * 78)
    print("2. HYDROGEN BONDS  (polar heavy-atom pairs within %.1f A)" % HBOND_DA)
    print("-" * 78)
    print("%-14s %-10s %7s %9s  %s" % ("protein", "ligand", "D...A", "D-H...A", "role"))
    hb = []
    for i, a in enumerate(protH):
        if a.elem not in ("N", "O", "S"):
            continue
        pd, pa = prot_polar(a)
        if not (pd or pa):
            continue
        for j, b in enumerate(ligH):
            if b.elem not in ("N", "O", "F", "S"):
                continue
            d = D[i][j]
            if d > HBOND_DA:
                continue
            if b.elem == "F":
                continue          # handled as a halogen contact below
            ang = best_angle(a, b) if (pd and has_h) else None
            role = "protein donor" if pd else "protein acceptor"
            if pd and pa:
                role = "protein donor/acceptor"
            ch, resi, ic, resn = a.key
            label = "%s%d %s" % (resn.capitalize(), resi + args.offset, a.name)
            print("%-14s %-10s %7.2f %9s  %s"
                  % (label, b.name, d,
                     ("%.1f" % ang) if ang is not None else "n/a", role))
            hb.append({"protein": label, "ligand": b.name, "d_da": round(d, 2),
                       "angle": round(ang, 1) if ang is not None else None,
                       "role": role})
    if not hb:
        print("(none)")

    # ---------- 3. aromatic stacking ----------------------------------------
    print("\n" + "-" * 78)
    print("3. AROMATIC RING GEOMETRY  (centroids within %.1f A)" % RING_CENT)
    print("-" * 78)
    lrings = [r for r in ligand_rings(ligH)]
    if lrings:
        print("ligand rings perceived: " +
              ", ".join("%s%d[%s]" % ("ar" if r["aromatic"] else "al", r["size"],
                                      "/".join(r["names"][:3]) + "..")
                        for r in lrings))
    pres = {}
    for a in protH:
        pres.setdefault(a.key, []).append(a)
    print("\n%-14s %-16s %8s %8s %8s  %s"
          % ("protein ring", "ligand ring", "cent", "angle", "offset", "type"))
    stacks = []
    for k, ats in pres.items():
        ch, resi, ic, resn = k
        for rname, names in PROT_RINGS.get(resn, []):
            sel = [a for a in ats if a.name in names]
            if len(sel) != len(names):
                continue
            for r in lrings:
                if not r["aromatic"]:
                    continue
                d, ang, off = ring_geometry(sel, r["atoms"])
                if d > RING_CENT:
                    continue
                if ang <= 30 and off <= 2.0 and d <= 5.5:
                    typ = "parallel (pi-pi)"
                elif 50 <= ang <= 90 and d <= 5.5:
                    typ = "T-shaped / edge-to-face"
                else:
                    typ = "proximal, not stacked"
                label = "%s%d %s-ring" % (resn.capitalize(), resi + args.offset, rname)
                lig_lab = "/".join(r["names"][:3]) + ".."
                print("%-14s %-16s %8.2f %8.1f %8.2f  %s"
                      % (label, lig_lab, d, ang, off, typ))
                stacks.append({"protein": label, "ligand_ring": r["names"],
                               "centroid": round(d, 2), "angle": round(ang, 1),
                               "offset": round(off, 2), "type": typ})
    if not stacks:
        print("(no aromatic ring within %.1f A)" % RING_CENT)

    # ---------- 4. organofluorine contacts ----------------------------------
    print("\n" + "-" * 78)
    print("4. ORGANOFLUORINE CONTACTS  (F...O/N within %.1f A)" % HALOGEN_CUT)
    print("-" * 78)
    print("%-14s %-8s %7s %9s  %s" % ("protein", "ligand F", "dist", "C-F...X", "acceptor"))
    hal = []
    lig_by_name = dict((a.name, a) for a in ligH)
    for j, b in enumerate(ligH):
        if b.elem != "F":
            continue
        # the carbon this F hangs off, for the C-F...X angle
        cf = min((a for a in ligH if a.elem == "C"),
                 key=lambda a: np.linalg.norm(a.xyz - b.xyz))
        for i, a in enumerate(protH):
            if a.elem not in ("O", "N"):
                continue
            d = D[i][j]
            if d > HALOGEN_CUT:
                continue
            v1 = cf.xyz - b.xyz
            v2 = a.xyz - b.xyz
            c = float(np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2)))
            ang = math.degrees(math.acos(max(-1.0, min(1.0, c))))
            ch, resi, ic, resn = a.key
            label = "%s%d %s" % (resn.capitalize(), resi + args.offset, a.name)
            kind = "backbone C=O" if a.name == "O" else (
                   "backbone N" if a.name == "N" else "side chain")
            print("%-14s %-8s %7.2f %9.1f  %s" % (label, b.name, d, ang, kind))
            hal.append({"protein": label, "F": b.name, "dist": round(d, 2),
                        "angle": round(ang, 1), "acceptor": kind})
    if not hal:
        print("(none)")

    # ---------- 5. burial ----------------------------------------------------
    print("\n" + "-" * 78)
    print("5. LIGAND BURIAL")
    print("-" * 78)
    try:
        import freesasa
        freesasa.setVerbosity(freesasa.silent)

        def sasa(ats):
            radii, coords = [], []
            for a in ats:
                radii.append({"C": 1.70, "N": 1.55, "O": 1.52, "S": 1.80,
                              "F": 1.47, "P": 1.80, "CL": 1.75,
                              "BR": 1.85, "I": 1.98, "H": 1.09}.get(a.elem, 1.70))
                coords.extend([float(x) for x in a.xyz])
            return freesasa.calcCoord(coords, radii)

        free = sasa(ligH)
        comp = sasa(protH + ligH)
        n = len(ligH)
        bound_lig = sum(comp.atomArea(len(protH) + i) for i in range(n))
        free_lig = free.totalArea()
        buried = free_lig - bound_lig
        print("ligand SASA free      : %8.1f A^2" % free_lig)
        print("ligand SASA in complex: %8.1f A^2" % bound_lig)
        print("buried on binding     : %8.1f A^2  (%.1f%% of the ligand surface)"
              % (buried, 100.0 * buried / free_lig))
        burial = {"free": round(free_lig, 1), "bound": round(bound_lig, 1),
                  "buried": round(buried, 1),
                  "fraction": round(buried / free_lig, 3)}
    except Exception as exc:
        print("freesasa unavailable (%s)" % exc)
        burial = None

    if args.json:
        with open(args.json, "w") as fh:
            json.dump({"tag": tag, "file": args.pdb, "offset": args.offset,
                       "site_residues": rows, "hbonds": hb, "stacking": stacks,
                       "fluorine": hal, "burial": burial}, fh, indent=2)
        print("\nwrote %s" % args.json)
    return 0


if __name__ == "__main__":
    sys.exit(main())
