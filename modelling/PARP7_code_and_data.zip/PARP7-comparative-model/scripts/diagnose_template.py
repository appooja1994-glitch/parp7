#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Ask MODELLER what it actually reads from the cleaned template, and compare that
with the alignment. Run from the project folder:

    conda activate parp7
    python scripts/diagnose_template.py
"""
import os
import sys

root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
os.chdir(root)

TMPL = "02_template/6v3wA.pdb"
ALI = "03_model/parp7_6v3w.ali"

for f in (TMPL, ALI):
    if not os.path.exists(f):
        sys.exit("missing %s - run 01_prepare_alignment.py first" % f)

# ---------------------------------------------------------------- raw file --
prot, het, lastres = set(), {}, None
for line in open(TMPL):
    rec = line[:6]
    if rec in ("ATOM  ", "HETATM"):
        key = line[17:27]
        if rec == "ATOM  ":
            prot.add(key)
        else:
            het[key] = het.get(key, 0) + 1
        lastres = key
print("raw file parse:")
print("  ATOM   residues : %d" % len(prot))
print("  HETATM residues : %d  %r" % (len(het), sorted(het)))
print("  last residue in file: %r" % lastres)

# -------------------------------------------------------------- alignment --
body, state = [], None
for ln in open(ALI):
    if ln.startswith(">P1;6v3wA"):
        state = "hdr"; continue
    if state == "hdr":
        print("\nPIR header (%d fields):\n  %s"
              % (len(ln.rstrip("\n").split(":")), ln.rstrip()))
        state = "seq"; continue
    if state == "seq":
        body.append(ln.strip())
        if ln.rstrip().endswith("*"):
            break
s = "".join(body).rstrip("*")
print("  alignment chars : %d total, %d gaps, %d dots, %d residues"
      % (len(s), s.count("-"), s.count("."), len(s) - s.count("-")))

# --------------------------------------------------------------- MODELLER --
try:
    from modeller import Environ, Model
except ImportError:
    try:
        from modeller import environ as Environ, model as Model
    except ImportError:
        sys.exit("\nMODELLER not importable - run `conda activate parp7` first")

print("\nwhat MODELLER reads:")
for flag in (True, False):
    try:
        env = Environ()
        env.io.atom_files_directory = [".", "02_template"]
        env.io.hetatm = flag
        m = Model(env, file=TMPL)
        counts = {}
        for r in m.residues:
            counts[r.name] = counts.get(r.name, 0) + 1
        blk = [r.name for r in m.residues if r.name in ("BLK", "UNK", ".")]
        tail = [r.name for r in m.residues][-4:]
        print("  io.hetatm=%-5s -> %3d residues   last four: %r"
              % (flag, len(m.residues), tail))
        if blk:
            print("                     BLK/unknown residues: %r" % blk)
    except Exception as e:
        print("  io.hetatm=%-5s -> FAILED: %s" % (flag, e))

print("""
Reading of the result
  If hetatm=True gives one MORE residue than hetatm=False, MODELLER is reading
  the ligand and the mismatch lies elsewhere.
  If both give the same number, MODELLER is NOT reading the ligand from this
  file. Rebuild the alignment without it:

      KEEP_LIGAND=0 python scripts/01_prepare_alignment.py
      python scripts/02_model_parp7.py
""")
