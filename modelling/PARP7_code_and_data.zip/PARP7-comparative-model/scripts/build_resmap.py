#!/usr/bin/env python
"""Residue-by-residue correspondence between the 6V3W template and the PARP7
model, taken from the MODELLER alignment itself rather than assuming a
constant offset. Writes resmap.csv: parp7_resi, parp7_aa, tmpl_resi, tmpl_aa."""
import sys, csv

ali = sys.argv[1] if len(sys.argv) > 1 else "inputs/parp7_6v3w.ali"
out = sys.argv[2] if len(sys.argv) > 2 else "out/resmap.csv"
tmpl_pdb = sys.argv[3] if len(sys.argv) > 3 else "inputs/crystal_6v3w.pdb"

blocks, cur, hdr = {}, None, None
for line in open(ali):
    line = line.rstrip("\n")
    if line.startswith(">P1;"):
        cur = line[4:].strip(); blocks[cur] = {"hdr": None, "seq": []}
        hdr = "next"
    elif hdr == "next":
        blocks[cur]["hdr"] = line; hdr = None
    elif cur:
        blocks[cur]["seq"].append(line)

for k in blocks:
    blocks[k]["seq"] = "".join(blocks[k]["seq"]).replace("*", "")

names = list(blocks)
tmpl = [n for n in names if "6v3w" in n.lower()][0]
targ = [n for n in names if n != tmpl][0]
ts, qs = blocks[tmpl]["seq"], blocks[targ]["seq"]
t_start = int(blocks[tmpl]["hdr"].split(":")[2])
q_start = int(blocks[targ]["hdr"].split(":")[2])
assert len(ts) == len(qs), "aligned sequences differ in length: %d vs %d" % (len(ts), len(qs))

# The template's residue numbers are NOT contiguous: 6V3W has a disordered
# loop, so counting sequentially from the header's start residue drifts by
# the size of every gap. Take the real numbers from the structure, in order.
obs, last = [], None
for line in open(tmpl_pdb):
    if line.startswith("ATOM  "):
        k = (int(line[22:26]), line[17:20].strip())
        if k != last:
            obs.append(k); last = k
assert obs[0][0] == t_start, ("alignment says the template starts at %d but the "
                              "structure starts at %d" % (t_start, obs[0][0]))
n_tmpl = sum(1 for c in ts if c not in "-/.")
assert n_tmpl == len(obs), ("alignment has %d template residues, structure has %d"
                            % (n_tmpl, len(obs)))

rows, tk, qi = [], 0, q_start
for a, b in zip(ts, qs):
    if a in "/." or b in "/.":
        continue
    ta = None if a == "-" else obs[tk][0]
    qa = None if b == "-" else qi
    if ta is not None or qa is not None:
        rows.append((qa, b if b != "-" else "", ta, a if a != "-" else ""))
    if a != "-": tk += 1
    if b != "-": qi += 1

with open(out, "w") as fh:
    w = csv.writer(fh); w.writerow(["parp7_resi", "parp7_aa", "tmpl_resi", "tmpl_aa"])
    for r in rows: w.writerow(["" if r[0] is None else r[0], r[1],
                               "" if r[2] is None else r[2], r[3]])

ident = sum(1 for r in rows if r[1] and r[3] and r[1] == r[3])
both = sum(1 for r in rows if r[1] and r[3])
print("aligned columns          : %d" % len(rows))
print("positions with both      : %d" % both)
print("identical                : %d  (%.1f%%)" % (ident, 100.0*ident/both))
print("template span            : %d-%d  (%d observed residues, gaps at %s)"
      % (obs[0][0], obs[-1][0], len(obs),
         [(obs[i][0], obs[i+1][0]) for i in range(len(obs)-1)
          if obs[i+1][0] != obs[i][0]+1] or "none"))
print("target span              : %d-%d" % (q_start, qi-1))
offs = {}
for r in rows:
    if r[0] and r[2]:
        offs[r[2]-r[0]] = offs.get(r[2]-r[0], 0) + 1
print("template-target offsets  : %s" % sorted(offs.items(), key=lambda x: -x[1]))
print("wrote %s" % out)
