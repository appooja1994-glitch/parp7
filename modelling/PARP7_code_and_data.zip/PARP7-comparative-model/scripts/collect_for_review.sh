#!/usr/bin/env bash
# Package everything needed to review and finalise the model.
#   conda activate parp7 && bash scripts/collect_for_review.sh
# Produces  parp7_review.zip  in the project folder.
set -uo pipefail

OUT=parp7_review
rm -rf "$OUT" "$OUT.zip"
mkdir -p "$OUT"/{01_sequence,02_template,03_model,03_model/top5,05_site,logs}

copy() { [ -f "$1" ] && cp "$1" "$2" && echo "  + $1" || echo "  - $1 (absent)"; }

echo "==> inputs"
copy 01_sequence/PARP7_Q7Z3E1.fasta  "$OUT/01_sequence/"
copy 02_template/6V3W.pdb            "$OUT/02_template/"
copy 02_template/6v3wA.pdb           "$OUT/02_template/"
copy 02_template/6v3wA_apo.pdb       "$OUT/02_template/"

echo "==> alignment and model"
copy 03_model/parp7_6v3w.ali             "$OUT/03_model/"
copy 03_model/alignment_report.txt       "$OUT/03_model/"
copy 03_model/model_scores.csv           "$OUT/03_model/"
copy 03_model/PARP7_model_primary.pdb    "$OUT/03_model/"
copy 03_model/PARP7_model_primary_withlig.pdb "$OUT/03_model/"
copy 03_model/RBN2397_reference.pdb      "$OUT/03_model/"
copy 03_model/AF_PARP7_ART.pdb           "$OUT/03_model/"
for f in 03_model/AF-Q7Z3E1-F1*.pdb; do copy "$f" "$OUT/03_model/"; done

echo "==> the five best models by z-DOPE (for the ensemble check)"
python - <<'PY'
import csv, os, shutil
src = "03_model/model_scores.csv"
if not os.path.exists(src):
    print("  - model_scores.csv absent; skipping top5"); raise SystemExit
rows = list(csv.DictReader(open(src)))
rows.sort(key=lambda r: float(r["zDOPE"]))
for r in rows[:5]:
    p = os.path.join("03_model", os.path.basename(r["model"]))
    if os.path.exists(p):
        shutil.copy(p, "parp7_review/03_model/top5/")
        print("  + %s  zDOPE %s" % (os.path.basename(p), r["zDOPE"]))
    else:
        print("  - %s (absent)" % p)
PY

echo "==> docking"
copy 05_site/vina_box.conf   "$OUT/05_site/"
copy 05_site/reference.sdf   "$OUT/05_site/"
copy 05_site/probe.sdf       "$OUT/05_site/"
for f in 05_site/redock_seed*.sdf 05_site/redock_seed*.pdbqt; do copy "$f" "$OUT/05_site/"; done

echo "==> re-running the quick checks to capture their output"
python scripts/03_validate_model.py 03_model/PARP7_model_primary_withlig.pdb \
     > "$OUT/logs/validate_withlig.log" 2>&1 || true
python scripts/03_validate_model.py 03_model/PARP7_model_primary.pdb \
     > "$OUT/logs/validate_apo.log" 2>&1 || true
python scripts/04_alphafold_compare.py > "$OUT/logs/alphafold.log" 2>&1 || true
python scripts/05_place_ligand.py      > "$OUT/logs/place_ligand.log" 2>&1 || true
echo "  + logs/"

echo "==> environment"
{
  echo "date      : $(date)"
  echo "host      : $(hostname)"
  python -c "import sys; print('python    : ' + sys.version.split()[0])"
  python -c "import modeller; print('modeller  : ' + modeller.__version__)" 2>/dev/null
  python -c "import Bio; print('biopython : ' + Bio.__version__)" 2>/dev/null
  python -c "from rdkit import Chem; print('rdkit     : ' + Chem.rdBase.rdkitVersion)" 2>/dev/null
  vina --version 2>&1 | head -1 | sed 's/^/vina      : /'
  obabel -V 2>&1 | head -1 | sed 's/^/openbabel : /'
} > "$OUT/logs/versions.txt" 2>&1
cat "$OUT/logs/versions.txt" | sed 's/^/  /'

echo
echo "==> IMPORTANT: paste the final verdict block from 06_redock_gate.py into"
echo "    $OUT/logs/redock_verdict.txt  (the 'top-ranked pose RMSD by seed' lines)"
echo "    -- or just paste it in the chat."
touch "$OUT/logs/redock_verdict.txt"

zip -qr "$OUT.zip" "$OUT"
echo
echo "Created $(pwd)/$OUT.zip  ($(du -h "$OUT.zip" | cut -f1))"
echo "Send that file."
