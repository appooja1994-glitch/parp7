#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Consolidate the interaction profiles into the tables used in the paper."""
import json, csv, os

S = {
    "crystal": ("6V3W crystal", json.load(open("out/crystal_native.json"))),
    "asbuilt": ("Model, as built", json.load(open("out/asbuilt.json"))),
    "refined": ("Model, refined", json.load(open("out/refined.json"))),
    "docked":  ("Vina top pose", json.load(open("out/docked.json"))),
}
ORDER = ["crystal", "asbuilt", "refined", "docked"]

# template numbering -> PARP7 numbering
t2q = {}
for r in csv.DictReader(open("out/resmap.csv")):
    if r["parp7_resi"] and r["tmpl_resi"]:
        t2q[int(r["tmpl_resi"])] = int(r["parp7_resi"])


def rename(tag, label):
    """crystal residues are reported in PARP7 numbering for comparability"""
    if tag != "crystal":
        return label
    import re
    m = re.match(r"([A-Za-z]{3})(\d+)(.*)", label)
    if not m:
        return label
    q = t2q.get(int(m.group(2)))
    return "%s%s%s" % (m.group(1), q if q else m.group(2), m.group(3))


def hb_key(tag, h):
    return (rename(tag, h["protein"]), h["ligand"])


print("=" * 100)
print("TABLE A.  Hydrogen bonds (heavy-atom donor...acceptor distance, A)")
print("=" * 100)
keys = []
for t in ORDER:
    for h in S[t][1]["hbonds"]:
        k = hb_key(t, h)
        if k not in keys:
            keys.append(k)
print("%-18s %-8s %12s %12s %12s %12s" % ("protein atom", "ligand", *[S[t][0] for t in ORDER]))
rowsA = []
for k in keys:
    vals = []
    for t in ORDER:
        v = [h["d_da"] for h in S[t][1]["hbonds"] if hb_key(t, h) == k]
        vals.append("%.2f" % v[0] if v else "-")
    print("%-18s %-8s %12s %12s %12s %12s" % (k[0], k[1], *vals))
    rowsA.append([k[0], k[1]] + vals)

print()
print("=" * 100)
print("TABLE B.  Aromatic stacking on the pyridazinone warhead")
print("=" * 100)
print("%-16s %-14s %10s %10s %10s  %s"
      % ("structure", "protein ring", "centroid", "angle", "offset", "classification"))
rowsB = []
for t in ORDER:
    for s in S[t][1]["stacking"]:
        if "C28" not in s["ligand_ring"]:
            continue
        lab = rename(t, s["protein"].split()[0]) + " " + s["protein"].split()[1]
        print("%-16s %-14s %10.2f %10.1f %10.2f  %s"
              % (S[t][0], lab, s["centroid"], s["angle"], s["offset"], s["type"]))
        rowsB.append([S[t][0], lab, s["centroid"], s["angle"], s["offset"], s["type"]])

print()
print("=" * 100)
print("TABLE C.  Ligand burial")
print("=" * 100)
print("%-16s %12s %12s %12s %10s" % ("structure", "SASA free", "SASA bound", "buried", "fraction"))
rowsC = []
for t in ORDER:
    b = S[t][1]["burial"]
    print("%-16s %12.1f %12.1f %12.1f %9.1f%%"
          % (S[t][0], b["free"], b["bound"], b["buried"], 100 * b["fraction"]))
    rowsC.append([S[t][0], b["free"], b["bound"], b["buried"], round(100 * b["fraction"], 1)])

print()
print("=" * 100)
print("TABLE D.  Contact recovery against the crystal structure")
print("=" * 100)
def resi_of(label):
    import re
    m = re.match(r"([A-Za-z]{3})(\d+)", label)
    return int(m.group(2)), m.group(1)


xt = {}
for r in S["crystal"][1]["site_residues"]:
    n, aa = resi_of(rename("crystal", r["residue"]))
    xt[n] = (aa, r["min_dist"])
xt45 = set(n for n, v in xt.items() if v[1] <= 4.5)
rowsD = []
for t in ORDER[1:]:
    cur = {}
    for r in S[t][1]["site_residues"]:
        n, aa = resi_of(r["residue"])
        cur[n] = (aa, r["min_dist"])
    cur45 = set(n for n, v in cur.items() if v[1] <= 4.5)
    shared = xt45 & cur45
    import statistics
    dd = [abs(cur[n][1] - xt[n][1]) for n in shared]
    subs = sorted("%s%d/%s" % (xt[n][0], n, cur[n][0]) for n in shared
                  if cur[n][0] != xt[n][0])
    lost = sorted(xt45 - cur45); gained = sorted(cur45 - xt45)
    print("%-16s  %2d/%2d crystal contact POSITIONS recovered (%.0f%%); "
          "mean |delta d| %.2f A, max %.2f A"
          % (S[t][0], len(shared), len(xt45), 100.0 * len(shared) / len(xt45),
             statistics.mean(dd), max(dd)))
    print("                  sequence substitutions among them: %s"
          % (", ".join(subs) or "none"))
    for n in lost:
        print("                  not recovered: %s%d (crystal %.2f A, model %s)"
              % (xt[n][0], n, xt[n][1],
                 ("%.2f A" % cur[n][1]) if n in cur else "beyond 6 A"))
    for n in gained:
        print("                  extra contact: %s%d (model %.2f A, crystal %s)"
              % (cur[n][0], n, cur[n][1],
                 ("%.2f A" % xt[n][1]) if n in xt else "beyond 6 A"))
    rowsD.append([S[t][0], len(shared), len(xt45),
                  round(100.0 * len(shared) / len(xt45), 1), round(statistics.mean(dd), 2),
                  ";".join("%s%d" % (xt[n][0], n) for n in lost),
                  ";".join("%s%d" % (cur[n][0], n) for n in gained),
                  ";".join(subs)])

os.makedirs("out/tables", exist_ok=True)
for name, hdr, rows in (
    ("tableA_hbonds", ["protein_atom", "ligand_atom"] + [S[t][0] for t in ORDER], rowsA),
    ("tableB_stacking", ["structure", "protein_ring", "centroid_A", "angle_deg",
                         "offset_A", "classification"], rowsB),
    ("tableC_burial", ["structure", "sasa_free_A2", "sasa_bound_A2",
                       "buried_A2", "buried_pct"], rowsC),
    ("tableD_recovery", ["structure", "recovered", "crystal_total", "pct",
                         "mean_abs_delta_A", "lost", "gained", "substitutions"], rowsD)):
    with open("out/tables/%s.csv" % name, "w") as fh:
        w = csv.writer(fh); w.writerow(hdr); w.writerows(rows)
print("\nwrote out/tables/*.csv")
