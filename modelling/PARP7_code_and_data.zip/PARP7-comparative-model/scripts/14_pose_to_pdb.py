#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Write a docked pose out with the crystallographic atom names, so the pose
can be pushed through the same interaction profiler as the modelled complex.

The docked ligand was re-embedded from SMILES, so its atom order bears no
relation to the PDB chemical component. A symmetry-aware substructure match
against the reference recovers the correspondence.

    python 14_pose_to_pdb.py poses.sdf reference_ligand.pdb receptor.pdb out.pdb [pose_index]
"""
import sys
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, rdMolAlign
RDLogger.DisableLog("rdApp.*")

sdf, refpdb, rec, out = sys.argv[1:5]
idx = int(sys.argv[5]) if len(sys.argv) > 5 else 0

ref = Chem.MolFromPDBFile(refpdb, removeHs=True, sanitize=False)
if ref is None:
    sys.exit("cannot read %s" % refpdb)
names = [a.GetPDBResidueInfo().GetName() for a in ref.GetAtoms()]
resn = ref.GetAtomWithIdx(0).GetPDBResidueInfo().GetResidueName().strip()

poses = [m for m in Chem.SDMolSupplier(sdf, removeHs=True, sanitize=True) if m]
if not poses:
    sys.exit("no readable poses in %s" % sdf)
pose = poses[idx]
score = pose.GetProp("minimizedAffinity") if pose.HasProp("minimizedAffinity") else (
        pose.GetProp("REMARK").split()[2] if pose.HasProp("REMARK") else "?")

# bond orders on the reference, from the pose, so the match can be made
ref2 = Chem.MolFromPDBFile(refpdb, removeHs=True, sanitize=False)
try:
    ref2 = AllChem.AssignBondOrdersFromTemplate(pose, ref2)
except Exception as e:
    sys.exit("could not transfer bond orders: %s" % e)

match = pose.GetSubstructMatch(ref2)          # pose index for each ref atom
if not match or len(match) != ref2.GetNumAtoms():
    sys.exit("substructure match failed (%d of %d atoms)"
             % (len(match), ref2.GetNumAtoms()))

rmsd = rdMolAlign.CalcRMS(pose, ref2)
sys.stderr.write("pose %d: in-place symmetry-corrected RMSD to reference %.2f A, score %s\n"
                 % (idx + 1, rmsd, score))

conf = pose.GetConformer()
lines = [l for l in open(rec) if l.startswith("ATOM  ")]
ser = 1
with open(out, "w") as fh:
    for l in lines:
        fh.write(l[:6] + "%5d" % ser + l[11:]); ser += 1
    fh.write("TER\n")
    for i, pi in enumerate(match):
        p = conf.GetAtomPosition(pi)
        nm = names[i]
        el = ref2.GetAtomWithIdx(i).GetSymbol().upper()
        fh.write("HETATM%5d %-4s %3s %s%4d    %8.3f%8.3f%8.3f  1.00  0.00          %2s\n"
                 % (ser, nm.strip().ljust(3) if len(nm.strip()) < 4 else nm.strip(),
                    resn, "B", 649, p.x, p.y, p.z, el))
        ser += 1
    fh.write("END\n")
print(out)
