#!/usr/bin/env python3
"""
Build the PARP7 / 6V3W alignment for MODELLER, and refuse to write a bad one.

Reads the files fetched by 00_fetch.sh, extracts chain A of 6V3W (protein +
inhibitor, no water/ions), aligns the PARP7 ART domain to the residues that are
actually present in the coordinates, and writes:

    02_template/6v3wA.pdb          cleaned template, ligand retained
    02_template/6v3wA_apo.pdb      same, ligand stripped (for redocking)
    03_model/parp7_6v3w.ali        PIR alignment for MODELLER

Design rule: the cleaned PDB and the alignment are built from ONE list of
residues, so their counts cannot drift apart. Everything is then re-read from
the written files and verified before the script reports success.
"""
import sys, os
from Bio import Align, SeqIO
from Bio.Align import substitution_matrices

AA3 = {'ALA':'A','ARG':'R','ASN':'N','ASP':'D','CYS':'C','GLN':'Q','GLU':'E',
       'GLY':'G','HIS':'H','ILE':'I','LEU':'L','LYS':'K','MET':'M','PHE':'F',
       'PRO':'P','SER':'S','THR':'T','TRP':'W','TYR':'Y','VAL':'V','MSE':'M'}
SKIP_HET = {'HOH','WAT','CL','NA','K','SO4','PO4','GOL','EDO','ACT','MG','ZN',
            'CA','MN','NO3','ACY','DMS','PEG','TRS','IOD','BR','FMT','CIT'}

# MODELLER only counts the ligand as a residue when it reads it as a BLK.
# If it does not (see scripts/diagnose_template.py), rebuild without it:
#     KEEP_LIGAND=0 python scripts/01_prepare_alignment.py
KEEP_LIGAND = os.environ.get('KEEP_LIGAND', '1').lower() not in ('0', 'no', 'false')

MOTIFS = [(532, 'HGTS', 'catalytic His-Gly-Thr-Ser'),
          (562, 'GSYFA', 'Gly-Ser-Tyr-Phe-Ala stacking motif')]
POCKET = [532, 533, 538, 541, 545, 564, 566, 572, 575]


def die(msg):
    sys.stderr.write("\nABORTED: " + msg + "\n")
    sys.exit(1)


def read_template(path, chain='A'):
    """Observed chain-A residues, in file order, with their atom lines."""
    seq, nums, keys = [], [], []
    atoms = {}
    het, het_ids, het_nums = [], [], []
    seen = set()
    for line in open(path):
        rec = line[:6]
        is_mse = (rec == 'HETATM' and line[17:20].strip() == 'MSE')
        if rec == 'ATOM  ' or is_mse:
            if line[21] != chain or line[16] not in (' ', 'A'):
                continue
            r3 = line[17:20].strip()
            if r3 not in AA3:
                continue                      # skip the residue entirely
            key = line[22:27]
            if key not in seen:
                seen.add(key)
                seq.append(AA3[r3])
                nums.append(int(line[22:26]))
                keys.append(key)
            atoms.setdefault(key, []).append(line)
        elif rec == 'HETATM':
            if line[21] != chain:
                continue
            r3 = line[17:20].strip()
            if r3 in SKIP_HET or r3 == 'MSE':
                continue
            het.append(line)
            k = line[17:27]
            if k not in het_ids:
                het_ids.append(k)
                het_nums.append(int(line[22:26]))
    return ''.join(seq), nums, keys, atoms, het, het_ids, het_nums


def wrap(s, n=60):
    return '\n'.join(s[i:i+n] for i in range(0, len(s), n))


def pir_header(fields):
    """A PIR header has EXACTLY 10 colon-separated fields."""
    if len(fields) != 10:
        die("PIR header needs exactly 10 fields, built %d: %r" % (len(fields), fields))
    for f in fields:
        if ':' in str(f):
            die("PIR field must not contain a colon: %r" % (f,))
    return ':'.join(str(f) for f in fields)


def main():
    root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
    os.chdir(root)

    fa, tp = '01_sequence/PARP7_Q7Z3E1.fasta', '02_template/6V3W.pdb'
    for f in (fa, tp):
        if not os.path.exists(f):
            die("missing input %s - run 00_fetch.sh first" % f)

    p7 = str(next(SeqIO.parse(fa, 'fasta')).seq)
    if len(p7) != 657:
        die("PARP7 is %d aa, expected 657 (wrong isoform?)" % len(p7))

    tseq, tnums, tkeys, tatoms, het, het_ids, het_nums = read_template(tp)
    print("template chain A: %d observed residues, numbered %d-%d"
          % (len(tseq), tnums[0], tnums[-1]))
    breaks = [(tnums[i], tnums[i+1]) for i in range(len(tnums)-1)
              if tnums[i+1] != tnums[i] + 1]
    if breaks:
        print("  chain breaks (missing residues): %r" % (breaks,))
    if not KEEP_LIGAND:
        print("  KEEP_LIGAND=0 -> building an APO model; ligand discarded")
        het, het_ids, het_nums = [], [], []
    print("  het residues retained: %d -> %r"
          % (len(het_ids), [h.strip() for h in het_ids]))

    # ---- align -------------------------------------------------------------
    al = Align.PairwiseAligner()
    al.substitution_matrix = substitution_matrices.load('BLOSUM62')
    al.open_gap_score, al.extend_gap_score, al.mode = -11, -1, 'local'
    aln = al.align(p7, tseq)[0]
    A, B = str(aln[0]), str(aln[1])
    c = aln.coordinates

    # ---- ONE pass over the alignment defines everything --------------------
    # tcols[i] = index into tseq for column i, or None for a template gap
    # qcols[i] = PARP7 residue number for column i, or None for a query gap
    ti, qi = int(c[1][0]), int(c[0][0])
    tcols, qcols = [], []
    for a, b in zip(A, B):
        if b == '-':
            tcols.append(None)
        else:
            tcols.append(ti); ti += 1
        if a == '-':
            qcols.append(None)
        else:
            qi += 1; qcols.append(qi)

    used = [t for t in tcols if t is not None]      # template residues we keep
    if not used:
        die("alignment contains no template residues")

    p7_to_t, t_to_p7 = {}, {}
    for t, q in zip(tcols, qcols):
        if t is not None and q is not None:
            p7_to_t[q] = tnums[t]
            t_to_p7[tnums[t]] = q

    pairs = len(p7_to_t)
    ident = sum(1 for t, q in zip(tcols, qcols)
                if t is not None and q is not None and tseq[t] == p7[q-1])
    pct = 100.0 * ident / pairs
    print("\nalignment: %d/%d = %.1f%% identity, %d gap positions"
          % (ident, pairs, pct, len(A) - pairs))
    if pct < 30:
        die("identity %.1f%% is too low for comparative modelling" % pct)

    p7_lo, p7_hi = min(p7_to_t), max(p7_to_t)
    t_lo, t_hi = tnums[used[0]], tnums[used[-1]]
    print("aligned span: PARP7 %d-%d  <->  6V3W %d-%d" % (p7_lo, p7_hi, t_lo, t_hi))

    # ---- verification ------------------------------------------------------
    print("\nverifying landmarks:")
    for start, motif, label in MOTIFS:
        got = p7[start-1:start-1+len(motif)]
        if got != motif:
            die("%s: PARP7 %d is '%s', expected '%s' - numbering is off"
                % (label, start, got, motif))
        tr = [p7_to_t.get(start + i) for i in range(len(motif))]
        if any(x is None for x in tr):
            die("%s at PARP7 %d is not fully aligned to the template" % (label, start))
        if tr != list(range(tr[0], tr[0] + len(motif))):
            die("%s at PARP7 %d is broken by a gap in the template" % (label, start))
        tgot = ''.join(tseq[tnums.index(x)] for x in tr)
        print("  PARP7 %-6s @%d -> 6V3W %-6s @%d  %s"
              % (motif, start, tgot, tr[0], "OK" if tgot == motif else "DIFFERS (check)"))

    seqadv = {}
    for line in open(tp):
        if line.startswith('SEQADV') and 'ENGINEERED MUTATION' in line:
            try:
                seqadv[int(line[18:22])] = (line[39:42].strip(), line[12:15].strip())
            except ValueError:
                pass
    if seqadv:
        print("\nengineered mutations -> PARP7 equivalents:")
        bad = []
        for pos, (wt, mut) in sorted(seqadv.items()):
            pn = t_to_p7.get(pos)
            pr = p7[pn-1] if pn else None
            m1 = AA3.get(mut)
            ok = pr == m1
            print("  6V3W %d %s->%s   PARP7 %s%s   %s"
                  % (pos, wt, mut, pr, pn, "match" if ok else "MISMATCH"))
            if not ok:
                bad.append(pos)
        if bad:
            die("engineered positions %r do not match PARP7 - the alignment is "
                "wrong, or the entry has been re-refined" % bad)

    missing = [r for r in POCKET if r not in p7_to_t]
    if missing:
        die("pocket residues %r have no template partner" % missing)
    print("\nall %d pocket residues have a template partner" % len(POCKET))

    # ---- write the cleaned template from EXACTLY the residues used ---------
    keep = []
    for t in used:
        keep.extend(tatoms[tkeys[t]])
    with open('02_template/6v3wA.pdb', 'w') as fh:
        fh.writelines(keep + het + ['END\n'])
    with open('02_template/6v3wA_apo.pdb', 'w') as fh:
        fh.writelines(keep + ['END\n'])
    print("wrote 02_template/6v3wA.pdb (%d residues + %d het) and 6v3wA_apo.pdb"
          % (len(used), len(het_ids)))

    # ---- write the PIR, from the same single pass --------------------------
    # MODELLER convention: BLK (ligand) residues are separated from the
    # protein by a chain break '/'. Without it the structure's het residue is
    # not matched to the '.' and the residue counts disagree by one.
    dots = ('/' + '.' * len(het_ids)) if het_ids else ''
    tline = ''.join(tseq[t] if t is not None else '-' for t in tcols) + dots
    qline = A + dots

    # MODELLER reads only the residues inside the declared structureX range.
    # The ligand sits beyond the last protein residue, so the range must be
    # extended to reach it - otherwise the het is silently not read and the
    # residue counts disagree by exactly the number of ligands.
    t_end = max(het_nums) if het_nums else t_hi
    if het_nums:
        print("  structureX range extended to %d to include the ligand "
              "(protein ends at %d)" % (t_end, t_hi))

    tmpl_hdr = pir_header(['structureX', '6v3wA', t_lo, 'A', t_end, 'A',
                           'PARP12 catalytic fragment PARP7-site mutant',
                           'PDB 6V3W', '2.04', '-1.00'])
    targ_hdr = pir_header(['sequence', 'PARP7_ART', p7_lo, ' ', p7_hi, ' ',
                           'Human PARP7 ART domain', 'Homo sapiens',
                           '-1.00', '-1.00'])

    os.makedirs('03_model', exist_ok=True)
    with open('03_model/parp7_6v3w.ali', 'w') as fh:
        fh.write(">P1;6v3wA\n" + tmpl_hdr + "\n" + wrap(tline) + "*\n\n")
        fh.write(">P1;PARP7_ART\n" + targ_hdr + "\n" + wrap(qline) + "*\n")
    print("wrote 03_model/parp7_6v3w.ali")

    # ---- re-read both written files and check they agree -------------------
    cseq, cnums, _, _, chet, chet_ids, _ = read_template('02_template/6v3wA.pdb')
    pdb_count = len(cseq) + len(chet_ids)

    body, inseq = [], False
    for ln in open('03_model/parp7_6v3w.ali'):
        if ln.startswith('>P1;6v3wA'):
            inseq = 'header'; continue
        if inseq == 'header':
            n = len(ln.rstrip('\n').split(':'))
            if n != 10:
                die("written PIR header has %d fields, expected 10:\n  %s" % (n, ln.rstrip()))
            inseq = True; continue
        if inseq is True:
            body.append(ln.strip())
            if ln.rstrip().endswith('*'):
                break
    aln_seq = ''.join(body).rstrip('*')
    aln_count = len(aln_seq) - aln_seq.count('-') - aln_seq.count('/')

    if not KEEP_LIGAND:
        print("\nNOTE: apo model. The pocket still inherits the template's")
        print("      ligand-bound side-chain rotamers, since the coordinates")
        print("      come from a holo structure. Re-dock RBN-2397 into the")
        print("      finished model to confirm the site is intact.")

    print("\nconsistency check:")
    print("  residues in 02_template/6v3wA.pdb : %d protein + %d het = %d"
          % (len(cseq), len(chet_ids), pdb_count))
    print("  residues in the alignment entry   : %d" % aln_count)
    if aln_count != pdb_count:
        die("alignment has %d residues but the template PDB has %d.\n"
            "       MODELLER would reject this (read_te_290E)." % (aln_count, pdb_count))
    if het_nums:
        hdr = [l for l in open('03_model/parp7_6v3w.ali')
               if l.startswith('structureX:')][0]
        declared_end = int(hdr.split(':')[4])
        if declared_end < max(het_nums):
            die("structureX ends at %d but the ligand is at %d - MODELLER "
                "would not read it" % (declared_end, max(het_nums)))
        print("  structureX range %s-%s covers the ligand at %d"
              % (hdr.split(':')[2], hdr.split(':')[4], max(het_nums)))
    print("  match - MODELLER will accept this pair")

    with open('03_model/alignment_report.txt', 'w') as fh:
        fh.write("identity      %d/%d = %.1f%%\n" % (ident, pairs, pct))
        fh.write("PARP7 span    %d-%d\n" % (p7_lo, p7_hi))
        fh.write("6V3W span     %d-%d\n" % (t_lo, t_hi))
        fh.write("residues      %d protein + %d het\n" % (len(cseq), len(chet_ids)))
        fh.write("chain breaks  %r\n\n" % (breaks,))
        fh.write(str(aln))
    print("wrote 03_model/alignment_report.txt")
    print("\nAlignment verified. Next: python scripts/02_model_parp7.py")


if __name__ == '__main__':
    main()
