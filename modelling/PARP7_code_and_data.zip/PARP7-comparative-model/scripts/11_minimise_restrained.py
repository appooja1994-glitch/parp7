#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Restrained energy minimisation of a holo comparative model.

A model built with a rigid ligand restraint carries strain: the optimiser
holds the cleft open and pays for it by over-packing side chains elsewhere.
That strain is what drives a bad MolProbity clashscore, and it is almost
entirely outside the binding site. This script relieves it without moving
the site, by restraining the backbone everywhere and every heavy atom within
a shell of the ligand, then minimising.

    python 11_minimise_restrained.py holo_model.pdb --out refined
       --> refined_holo.pdb        protein + ligand, heavy atoms, original numbering
           refined_receptor.pdb    protein only
           refined_receptor_H.pdb  protein with the hydrogens used in minimisation

The ligand is NOT parameterised and NOT minimised: it is removed before
minimisation and re-attached afterwards, unchanged. That is deliberate. The
pose came from a 2.04 A crystal structure and is the reference the redocking
gate is measured against; a force field has nothing to add to it, and moving
it would invalidate every number already earned.

Because atoms move, the redocking gate must be re-run on the output before
the refined model replaces the input for production work.
"""
import argparse
import os
import sys

import numpy as np

SOLVENT = ("HOH", "WAT", "DOD")


def read_blocks(path, ligname=None):
    prot, het = [], []
    for line in open(path):
        if line.startswith("ATOM  "):
            prot.append(line)
        elif line.startswith("HETATM"):
            resn = line[17:20].strip()
            if resn in SOLVENT:
                continue
            if ligname is None or resn == ligname:
                het.append(line)
    return prot, het


def xyz(lines):
    return np.array([[float(l[30:38]), float(l[38:46]), float(l[46:54])] for l in lines])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("model", help="holo PDB: protein as ATOM, ligand as HETATM")
    ap.add_argument("--out", default="refined", help="output prefix")
    ap.add_argument("--lig", default=None, help="ligand residue name (default: any HETATM)")
    ap.add_argument("--shell", type=float, default=6.0,
                    help="restrain every residue with a heavy atom within this of the ligand")
    ap.add_argument("--k", type=float, default=1000.0,
                    help="restraint force constant, kJ/mol/nm^2")
    ap.add_argument("--iterations", type=int, default=5000)
    ap.add_argument("--ph", type=float, default=7.4,
                    help="pH for hydrogen placement; 7.4 was used for the published model")
    args = ap.parse_args()

    from openmm import app, unit, CustomExternalForce, LangevinMiddleIntegrator, Platform
    from pdbfixer import PDBFixer

    prot, het = read_blocks(args.model, args.lig)
    if not het:
        sys.exit("no ligand HETATM records in %s - nothing to restrain the site around" % args.model)
    print("protein atoms %d, ligand atoms %d" % (len(prot), len(het)))

    L = xyz(het)
    near = set()
    for line in prot:
        p = np.array([float(line[30:38]), float(line[38:46]), float(line[46:54])])
        if np.linalg.norm(L - p, axis=1).min() <= args.shell:
            near.add(int(line[22:26]))
    print("residues within %.1f A of the ligand: %d" % (args.shell, len(near)))

    # protein only, for the force field
    tmp = args.out + "_protein_in.pdb"
    with open(tmp, "w") as fh:
        fh.writelines(prot)
        fh.write("END\n")

    fixer = PDBFixer(filename=tmp)
    fixer.findMissingResidues(); fixer.missingResidues = {}
    fixer.findMissingAtoms(); fixer.addMissingAtoms()
    fixer.addMissingHydrogens(args.ph)

    ff = app.ForceField("amber14-all.xml", "implicit/gbn2.xml")
    system = ff.createSystem(fixer.topology, nonbondedMethod=app.NoCutoff,
                             constraints=None, rigidWater=False)

    rest = CustomExternalForce("0.5*k*periodicdistance(x,y,z,x0,y0,z0)^2")
    rest.addGlobalParameter("k", args.k * unit.kilojoule_per_mole / unit.nanometer**2)
    for p in ("x0", "y0", "z0"):
        rest.addPerParticleParameter(p)
    pos = fixer.positions
    n = 0
    for atom in fixer.topology.atoms():
        if atom.element is None or atom.element.symbol == "H":
            continue
        resid = int(atom.residue.id)
        if atom.name in ("N", "CA", "C", "O", "OXT") or resid in near:
            rest.addParticle(atom.index, pos[atom.index].value_in_unit(unit.nanometer))
            n += 1
    system.addForce(rest)
    print("restrained heavy atoms: %d (backbone everywhere + the %.1f A shell)"
          % (n, args.shell))

    integrator = LangevinMiddleIntegrator(300 * unit.kelvin, 1 / unit.picosecond,
                                          0.002 * unit.picoseconds)
    sim = app.Simulation(fixer.topology, system, integrator,
                         Platform.getPlatformByName("CPU"))
    sim.context.setPositions(pos)
    e0 = sim.context.getState(getEnergy=True).getPotentialEnergy()
    print("energy before: %.1f kJ/mol" % e0.value_in_unit(unit.kilojoule_per_mole))
    sim.minimizeEnergy(maxIterations=args.iterations)
    e1 = sim.context.getState(getEnergy=True).getPotentialEnergy()
    print("energy after : %.1f kJ/mol" % e1.value_in_unit(unit.kilojoule_per_mole))

    with_h = args.out + "_receptor_H.pdb"
    app.PDBFile.writeFile(fixer.topology,
                          sim.context.getState(getPositions=True).getPositions(),
                          open(with_h, "w"), keepIds=True)

    # heavy atoms only, with the original residue numbering restored
    heavy = [l for l in open(with_h)
             if l.startswith("ATOM  ") and (l[76:78].strip() or l[12:16].strip()[0]) != "H"]
    if len(heavy) != len(prot):
        sys.exit("atom count changed during minimisation (%d -> %d); refusing to "
                 "write a file whose numbering cannot be trusted" % (len(prot), len(heavy)))
    out_rec = args.out + "_receptor.pdb"
    out_holo = args.out + "_holo.pdb"
    rebuilt = []
    for src, new in zip(prot, heavy):
        if src[12:16] != new[12:16] or src[17:20] != new[17:20]:
            sys.exit("atom order changed during minimisation at %s - aborting"
                     % src[12:26])
        rebuilt.append(src[:30] + new[30:54] + src[54:])
    with open(out_rec, "w") as fh:
        fh.writelines(rebuilt); fh.write("END\n")
    with open(out_holo, "w") as fh:
        fh.writelines(rebuilt); fh.write("TER\n"); fh.writelines(het); fh.write("END\n")

    before, after = xyz(prot), xyz(rebuilt)
    ca = [i for i, l in enumerate(prot) if l[12:16].strip() == "CA"]
    pocket = [i for i, l in enumerate(prot)
              if l[12:16].strip() == "CA" and int(l[22:26]) in near]
    rms = lambda idx: float(np.sqrt(((after[idx] - before[idx]) ** 2).sum(axis=1).mean()))
    print("backbone Ca RMSD to the input : %.3f A" % rms(ca))
    print("pocket   Ca RMSD to the input : %.3f A" % rms(pocket))
    os.remove(tmp)
    print("wrote %s, %s, %s" % (out_holo, out_rec, with_h))
    print("\nRe-run the redocking gate on %s before using it: atoms moved." % out_holo)


if __name__ == "__main__":
    main()
