#!/usr/bin/env bash
#
# One-time environment setup on a Linux server.
# Installs Miniforge into $HOME if conda is absent, then builds the `parp7`
# environment with MODELLER and Biopython on a matched Python.
#
#   bash scripts/setup_env.sh
#
# No root needed - everything lands in your home directory.
set -uo pipefail

ENV_NAME=parp7
PREFIX="$HOME/miniforge3"

say()  { printf '\n==> %s\n' "$*"; }
die()  { printf '\nFAILED: %s\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------- conda ----
if command -v conda >/dev/null 2>&1; then
  say "conda already available: $(command -v conda)"
  eval "$(conda shell.bash hook)" 2>/dev/null || true
elif [ -x "$PREFIX/bin/conda" ]; then
  say "using existing Miniforge at $PREFIX"
  eval "$("$PREFIX/bin/conda" shell.bash hook)"
else
  ARCH=$(uname -m)
  case "$ARCH" in
    x86_64|aarch64) ;;
    *) die "unsupported architecture '$ARCH' - install conda manually" ;;
  esac
  URL="https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Linux-${ARCH}.sh"
  say "installing Miniforge for $ARCH (~100 MB)"
  curl -fsSL -o "$HOME/Miniforge3.sh" "$URL" \
    || die "could not download Miniforge. If this server has no outbound
    internet, build the environment on a machine that does and move it across
    with conda-pack."
  bash "$HOME/Miniforge3.sh" -b -p "$PREFIX" || die "Miniforge installer failed"
  rm -f "$HOME/Miniforge3.sh"
  eval "$("$PREFIX/bin/conda" shell.bash hook)"
  "$PREFIX/bin/conda" init bash >/dev/null 2>&1 || true
  say "Miniforge installed at $PREFIX"
fi

# ------------------------------------------------------------ environment --
if conda env list | awk '{print $1}' | grep -qx "$ENV_NAME"; then
  say "environment '$ENV_NAME' already exists - reusing it"
else
  say "creating environment '$ENV_NAME' (conda picks a Python MODELLER supports)"
  # --override-channels keeps us off repo.anaconda.com entirely. Those default
  # channels now require Terms-of-Service acceptance and carry Anaconda's
  # commercial licence terms; salilab + conda-forge have everything we need.
  conda create -n "$ENV_NAME" --override-channels \
        -c salilab -c conda-forge modeller biopython -y \
    || die "environment creation failed.
    If the solver complained about Terms of Service for repo.anaconda.com,
    this command should not have reached those channels - check for a
    'default_channels' entry in ~/.condarc that is forcing them in."
fi

conda activate "$ENV_NAME" || die "could not activate '$ENV_NAME'"

# ---------------------------------------------------------------- verify ---
say "verifying"
python - <<'PY'
import sys
print("  Python     : %s" % sys.version.split()[0])
print("  Executable : %s" % sys.executable)
ok = True
try:
    import modeller
    print("  MODELLER   : %s" % getattr(modeller, "__version__", "unknown"))
except Exception as e:
    print("  MODELLER   : FAILED -> %s" % e); ok = False
try:
    import Bio
    print("  Biopython  : %s" % Bio.__version__)
except Exception as e:
    print("  Biopython  : FAILED -> %s" % e); ok = False
sys.exit(0 if ok else 1)
PY
VERIFY=$?

# ------------------------------------------------------------ licence key --
CFG=$(python -c "import modeller, os; print(os.path.join(os.path.dirname(modeller.__file__),'config.py'))" 2>/dev/null)
if [ -n "${CFG:-}" ] && [ -f "$CFG" ]; then
  say "licence file: $CFG"
  grep -n "license" "$CFG" || true
  if grep -q "XXXX" "$CFG" 2>/dev/null; then
    cat <<'MSG'

    The licence key is still the placeholder. Register (free, academic,
    arrives by email in about a minute):

        https://salilab.org/modeller/registration.html

    then edit the file above and set:   license = 'YOUR_KEY'
MSG
  fi
fi

echo
if [ "$VERIFY" -eq 0 ]; then
  cat <<MSG
Environment ready.

Every session from now on starts with:

    conda activate $ENV_NAME

Next:
    bash   scripts/00_fetch.sh
    python scripts/01_prepare_alignment.py
MSG
else
  die "verification failed - see the errors above"
fi
