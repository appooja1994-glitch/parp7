#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Build the PARP7 ART-domain model with MODELLER.

    conda activate parp7
    python scripts/02_model_parp7.py

Smoke-test with a handful of models before committing to the full run:

    N_MODELS=5 python scripts/02_model_parp7.py

No f-strings and no __future__ import in this file, so it parses under any
interpreter and can report which one it is rather than dying on a SyntaxError.
"""
import os
import csv
import sys
import shutil

# Override for a quick smoke test:  N_MODELS=5 python scripts/02_model_parp7.py
try:
    N_MODELS = int(os.environ.get("N_MODELS", "100"))
except ValueError:
    sys.exit("ERROR: N_MODELS must be an integer, got %r"
             % os.environ.get("N_MODELS"))
if N_MODELS < 1:
    sys.exit("ERROR: N_MODELS must be >= 1")

print("Python    : " + sys.version.replace("\n", " "))
print("Executable: " + sys.executable)
print("Models    : %d" % N_MODELS)

root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
work = os.path.join(root, "03_model")
if not os.path.isdir(work):
    sys.exit("ERROR: %s does not exist - are you running from the project folder?" % work)
os.chdir(work)

ali = "parp7_6v3w.ali"
if not os.path.exists(ali):
    sys.exit("ERROR: %s not found.\n"
             "       Run step 3 first:  python3 scripts/01_prepare_alignment.py"
             % os.path.join(work, ali))
print("Alignment : " + os.path.join(work, ali))

# ---------------------------------------------------------------- MODELLER --
try:
    import modeller
except ImportError:
    sys.exit("\nMODELLER could not be imported by this Python (%s).\n\n"
             "Activate the environment first:\n\n"
             "    conda activate parp7\n\n"
             "If it does not exist yet, build it:\n\n"
             "    bash scripts/setup_env.sh\n"
             % sys.version.split()[0])

print("MODELLER  : " + str(getattr(modeller, "__version__", "unknown")))

if sys.version_info[0] < 3:
    sys.exit("\nERROR: MODELLER 10.x requires Python 3, but the launcher started\n"
             "       Python %s.\n\n"
             "       Fix: run with your own python3 after putting MODELLER on its\n"
             "       path. Find the lib directory, then:\n\n"
             "         ls -d /Library/modeller-10.8/lib/*/\n"
             "         export PYTHONPATH=/Library/modeller-10.8/modlib:"
             "$(ls -d /Library/modeller-10.8/lib/*/ | head -1):$PYTHONPATH\n"
             "         python3 scripts/02_model_parp7.py\n"
             % sys.version.split()[0])

# class names are capitalised in MODELLER 10.x, lowercase in 9.x
try:
    from modeller import Environ, log
    from modeller.automodel import AutoModel, assess, refine
except ImportError:
    from modeller import environ as Environ, log
    from modeller.automodel import automodel as AutoModel, assess, refine

log.verbose()

# Absolute path, and only one directory, so no stale copy elsewhere can win.
TMPL_DIR = os.path.abspath(os.path.join(root, "02_template"))
TMPL_PDB = os.path.join(TMPL_DIR, "6v3wA.pdb")
if not os.path.exists(TMPL_PDB):
    sys.exit("ERROR: %s not found - run 01_prepare_alignment.py first" % TMPL_PDB)
print("Template  : " + TMPL_PDB)

env = Environ()
env.io.atom_files_directory = [TMPL_DIR]
env.io.hetatm = True            # retain the inhibitor as a rigid body

# ---- pre-flight: compare what MODELLER reads with what the alignment says --
try:
    from modeller import Model
except ImportError:
    Model = None

if Model is not None:
    # Parse the template entry of the alignment the way MODELLER will.
    _hdr, _body, _state = None, [], None
    for _ln in open(ali):
        if _ln.startswith(">P1;6v3wA"):
            _state = "hdr"; continue
        if _state == "hdr":
            _hdr = _ln.rstrip("\n").split(":"); _state = "seq"; continue
        if _state == "seq":
            _body.append(_ln.strip())
            if _ln.rstrip().endswith("*"):
                break
    if _hdr is None or len(_hdr) != 10:
        sys.exit("ERROR: could not read a 10-field structureX header from %s" % ali)
    _lo, _hi = int(_hdr[2]), int(_hdr[4])
    _s = "".join(_body).rstrip("*")
    _aln_n = len(_s) - _s.count("-") - _s.count("/")
    _dots = _s.count(".")

    # Count what MODELLER will actually read: residues INSIDE the declared
    # range only. A ligand beyond the range is silently not read.
    _prot, _het, _seen = 0, 0, set()
    for _l in open(TMPL_PDB):
        if _l[:6] not in ("ATOM  ", "HETATM"):
            continue
        _n = int(_l[22:26])
        if not (_lo <= _n <= _hi):
            continue
        _k = _l[17:27]
        if _k in _seen:
            continue
        _seen.add(_k)
        if _l[:6] == "ATOM  ":
            _prot += 1
        else:
            _het += 1
    _struct_n = _prot + _het

    print("Pre-flight:")
    print("  structureX range        : %d-%d" % (_lo, _hi))
    print("  residues MODELLER reads : %d protein + %d het = %d"
          % (_prot, _het, _struct_n))
    print("  alignment declares      : %d residues (%d ligand '.')" % (_aln_n, _dots))

    if _het != _dots:
        print("")
        print("  WARNING: %d het residue(s) inside the range but %d '.' in the"
              % (_het, _dots))
        print("           alignment. These must match.")

    if _struct_n != _aln_n:
        _msg = ("\nERROR: counts differ (%d vs %d); MODELLER would reject this.\n"
                % (_struct_n, _aln_n))
        if _dots > _het:
            _msg += ("\nThe alignment declares a ligand that MODELLER will not read."
                     "\nThe structureX range ends at %d. Check where the ligand sits:"
                     "\n    grep HETATM %s | awk '{print $4, $6}' | sort -u\n"
                     "\nIf its residue number is above %d, the range is too short.\n"
                     "Rebuild the alignment:\n"
                     "    rm -f %s 02_template/6v3wA*.pdb\n"
                     "    python scripts/01_prepare_alignment.py\n"
                     % (_hi, TMPL_PDB, _hi, ali))
        _msg += ("\nOr build without the ligand:\n"
                 "    KEEP_LIGAND=0 python scripts/01_prepare_alignment.py\n")
        sys.exit(_msg)
    print("  match - proceeding")

# class names are capitalised in MODELLER 10.x, lowercase in 9.x
try:
    from modeller import Environ, log
    from modeller.automodel import AutoModel, assess, refine
except ImportError:
    from modeller import environ as Environ, log
    from modeller.automodel import automodel as AutoModel, assess, refine

log.verbose()

# Absolute path, and only one directory, so no stale copy elsewhere can win.
TMPL_DIR = os.path.abspath(os.path.join(root, "02_template"))
TMPL_PDB = os.path.join(TMPL_DIR, "6v3wA.pdb")
if not os.path.exists(TMPL_PDB):
    sys.exit("ERROR: %s not found - run 01_prepare_alignment.py first" % TMPL_PDB)
print("Template  : " + TMPL_PDB)

env = Environ()
env.io.atom_files_directory = [TMPL_DIR]
env.io.hetatm = True            # retain the inhibitor as a rigid body

# ---- pre-flight: compare what MODELLER reads with what the alignment says --
try:
    from modeller import Model
except ImportError:
    Model = None

if Model is not None:
    _m = Model(env, file=TMPL_PDB)
    _struct_n = len(_m.residues)

    _body, _state = [], None
    for _ln in open(ali):
        if _ln.startswith(">P1;6v3wA"):
            _state = "hdr"; continue
        if _state == "hdr":
            _state = "seq"; continue
        if _state == "seq":
            _body.append(_ln.strip())
            if _ln.rstrip().endswith("*"):
                break
    _s = "".join(_body).rstrip("*")
    _aln_n = len(_s) - _s.count("-") - _s.count("/")

    print("Pre-flight: MODELLER reads %d residues from the template" % _struct_n)
    print("            alignment entry declares %d residues" % _aln_n)
    if _struct_n != _aln_n:
        sys.exit("\nERROR: counts differ (%d vs %d), MODELLER would reject this.\n\n"
                 "Rebuild the alignment:\n"
                 "    rm -f 03_model/parp7_6v3w.ali 02_template/6v3wA*.pdb\n"
                 "    python scripts/01_prepare_alignment.py\n\n"
                 "If it still differs, build without the ligand:\n"
                 "    KEEP_LIGAND=0 python scripts/01_prepare_alignment.py\n"
                 % (_struct_n, _aln_n))
    print("            match - proceeding")

a = AutoModel(env,
              alnfile=ali,
              knowns="6v3wA",
              sequence="PARP7_ART",
              assess_methods=(assess.DOPE, assess.normalized_dope, assess.GA341))
# AutoModel numbers its output from 1. Renumbering is done after make() by
# rewriting the files, rather than with rename_segments(): that method needs a
# built model and cannot be called on the AutoModel object beforehand, and the
# segment layout changes when a ligand is present.
_start = None
_state = None
for _ln in open(ali):
    if _ln.startswith(">P1;PARP7_ART"):
        _state = "hdr"; continue
    if _state == "hdr":
        _f = _ln.rstrip("\n").split(":")
        try:
            _start = int(_f[2])
        except (IndexError, ValueError):
            _start = None
        break
if _start is None:
    print("WARNING: could not read the start residue from %s;" % ali)
    print("         models will stay numbered from 1 - fix with "
          "scripts/renumber_model.py")
else:
    print("Numbering : output will be renumbered to start at PARP7 %d" % _start)

a.starting_model = 1
a.ending_model = N_MODELS
a.md_level = refine.slow
a.make()

POCKET_EXPECT = {532:'HIS', 533:'GLY', 538:'VAL', 541:'GLY', 545:'HIS',
                 564:'TYR', 566:'ALA', 572:'SER', 575:'PHE'}


def renumber(path, start):
    """Shift residue numbers so the first protein residue becomes `start`,
    then verify the pocket residues landed where they should."""
    first = None
    for line in open(path):
        if line[:6] == "ATOM  ":
            first = int(line[22:26]); break
    if first is None:
        return False, "no ATOM records"
    off = start - first
    if off == 0:
        return True, "already numbered from %d" % start
    out = []
    for line in open(path):
        if line[:6] in ("ATOM  ", "HETATM", "TER   ", "ANISOU"):
            try:
                n = int(line[22:26])
            except ValueError:
                out.append(line); continue
            out.append(line[:22] + ("%4d" % (n + off)) + line[26:])
        elif line[:6] == "CONECT":
            continue
        else:
            out.append(line)
    open(path, "w").writelines(out)
    got = {}
    for line in out:
        if line[:6] == "ATOM  " and line[12:16].strip() == "CA":
            got[int(line[22:26])] = line[17:20].strip()
    bad = [(k, v, got.get(k)) for k, v in POCKET_EXPECT.items()
           if k in got and got[k] != v]
    if bad:
        return False, "pocket mismatch after renumbering: %r" % bad
    return True, "shifted %+d; %d/%d pocket residues verified" % (
        off, sum(1 for k in POCKET_EXPECT if k in got), len(POCKET_EXPECT))


if _start is not None:
    print("")
    ok_n = 0
    for m in a.outputs:
        if m["failure"] is not None:
            continue
        ok, msg = renumber(m["name"], _start)
        if ok:
            ok_n += 1
        else:
            print("  %s: %s" % (m["name"], msg))
    print("renumbered %d models to PARP7 numbering (%s)"
          % (ok_n, renumber.__doc__.split("\n")[0].strip()))

rows = []
for m in a.outputs:
    if m["failure"] is not None:
        continue
    rows.append({"model": m["name"],
                 "molpdf": m["molpdf"],
                 "DOPE": m["DOPE score"],
                 "zDOPE": m["Normalized DOPE score"],
                 "GA341": m["GA341 score"][0]})

if not rows:
    sys.exit("ERROR: every model failed. Check the MODELLER log above, and the "
             "alignment in " + ali)

rows.sort(key=lambda r: r["zDOPE"])

fh = open("model_scores.csv", "w")
w = csv.DictWriter(fh, fieldnames=["model", "molpdf", "DOPE", "zDOPE", "GA341"])
w.writeheader()
w.writerows(rows)
fh.close()

print("")
print("%d models built. Best 5 by normalised DOPE:" % len(rows))
for r in rows[:5]:
    print("  %-28s zDOPE %8.3f   GA341 %.3f" % (r["model"], r["zDOPE"], r["GA341"]))

best = rows[0]
if best["zDOPE"] > -1.0:
    print("")
    print("WARNING: best zDOPE is %.3f. Values above -1.0 indicate a poor model;" % best["zDOPE"])
    print("         re-check the alignment before continuing.")

shutil.copy(best["model"], "PARP7_model_primary.pdb")
print("")
print("copied %s -> 03_model/PARP7_model_primary.pdb" % best["model"])
print("Next: python3 scripts/03_validate_model.py")
