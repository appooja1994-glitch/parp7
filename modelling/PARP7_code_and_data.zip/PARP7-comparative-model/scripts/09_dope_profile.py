#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Per-residue DOPE profiles, to localise where a model loses native-likeness.

The holo model scores z-DOPE -0.698 against -1.107 for the apo model and
-1.642 for the experimental template. This writes a per-residue energy profile
for each structure so the deficit can be attributed: localised around the
ligand or the 550-560 loop, or spread across the whole chain.

    conda activate parp7
    python scripts/09_dope_profile.py
    python scripts/09_dope_profile.py fileA.pdb fileB.pdb      # explicit

Writes 04_validation/dope_profiles.csv  (one column per structure).
"""
import os
import sys
import glob

try:
    from modeller import Environ, Selection, log
    from modeller.scripts import complete_pdb
except ImportError:
    sys.exit("MODELLER not importable - run 'conda activate parp7' first")

log.none()

root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
os.chdir(root)

defaults = ["03_model/candidates/candidate3.pdb",
            "apo_build/PARP7_model_primary.pdb",
            "03_model/AF_PARP7_ART.pdb"]
targets = sys.argv[1:] or [p for p in defaults if os.path.exists(p)]
targets = [t for t in targets if os.path.exists(t)]
if not targets:
    sys.exit("no input structures found")

env = Environ()
env.libs.topology.read(file="$(LIB)/top_heav.lib")
env.libs.parameters.read(file="$(LIB)/par.lib")
os.makedirs("04_validation/protein_only", exist_ok=True)

profiles, labels = {}, []
for t in targets:
    label = os.path.basename(t).replace(".pdb", "")
    stripped = "04_validation/protein_only/%s_prof.pdb" % label
    with open(stripped, "w") as fh:
        for line in open(t):
            if line[:6] == "ATOM  ":
                fh.write(line[:80].rstrip() + "\n")
        fh.write("END\n")
    try:
        mdl = complete_pdb(env, stripped)
        sel = Selection(mdl)
        zs = mdl.assess_normalized_dope()
        prof = sel.get_dope_profile()
    except Exception as e:
        print("%-34s failed: %s" % (label, e)); continue

    per = {}
    for i, res in enumerate(mdl.residues):
        try:
            per[int(res.num)] = prof[i].energy
        except Exception:
            pass
    profiles[label] = per
    labels.append(label)
    print("%-34s z-DOPE %7.3f   %d residues profiled" % (label, zs, len(per)))

if not profiles:
    sys.exit(1)

allres = sorted({n for p in profiles.values() for n in p})
out = "04_validation/dope_profiles.csv"
with open(out, "w") as fh:
    fh.write("residue," + ",".join(labels) + "\n")
    for n in allres:
        fh.write("%d," % n + ",".join(
            ("%.3f" % profiles[l][n]) if n in profiles[l] else "" for l in labels) + "\n")
print("\nwrote %s" % out)

if len(labels) >= 2:
    a, b = labels[0], labels[1]
    common = [n for n in allres if n in profiles[a] and n in profiles[b]]
    diffs = sorted(((profiles[a][n] - profiles[b][n], n) for n in common), reverse=True)
    tot = sum(d for d, _ in diffs)
    print("\ntotal DOPE difference %s - %s : %+.1f" % (a, b, tot))
    print("the 15 residues contributing most to it:")
    print("  %-8s %12s %12s %10s" % ("residue", a[:12], b[:12], "diff"))
    for d, n in diffs[:15]:
        print("  %-8d %12.2f %12.2f %+10.2f" % (n, profiles[a][n], profiles[b][n], d))
    top15 = sum(d for d, _ in diffs[:15])
    print("\n  those 15 account for %+.1f of %+.1f (%.0f%%)" % (top15, tot, 100*top15/tot if tot else 0))
    print("  -> strain is LOCALISED" if abs(top15) > 0.5*abs(tot) else
          "  -> strain is SPREAD across the chain")
