#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Side-chain packing audit.

MolProbity's clashscore needs its own hydrogen placement (reduce) and its own
radii; reproducing it locally is not worth the risk of quoting a number that
is not MolProbity's. What IS robust on heavy atoms alone is the count of
close carbon-carbon contacts between residues that are not sequence
neighbours. A crystal structure sets the scale: 6V3W has 11 such contacts
below 3.4 A. A model with ten times that is over-packed, and that is exactly
what drives a bad clashscore.

Reported at three cut-offs so the distribution, not one threshold, is visible.
"""
import sys, json
import numpy as np
from scipy.spatial import cKDTree

CUTS = (3.2, 3.4, 3.6)
SKIP = ("HOH", "WAT")


def read(path, lig=None):
    at = []
    for l in open(path):
        if not l.startswith("ATOM  ") or len(l) < 54:
            continue
        resn = l[17:20].strip()
        if resn in SKIP or resn == lig:
            continue
        e = (l[76:78].strip() or l[12:16].strip()[0]).upper()
        if e == "H":
            continue
        at.append((l[12:16].strip(), resn, l[21], int(l[22:26]), e,
                   np.array([float(l[30:38]), float(l[38:46]), float(l[46:54])])))
    return at


def audit(path, tag):
    at = read(path)
    X = np.array([a[5] for a in at])
    isC = np.array([a[4] == "C" for a in at])
    key = [(a[2], a[3]) for a in at]
    tree = cKDTree(X)
    pairs = tree.query_pairs(r=max(CUTS), output_type="ndarray")
    counts = dict((c, 0) for c in CUTS)
    per_res = {}
    for i, j in pairs:
        if not (isC[i] and isC[j]):
            continue
        if key[i][0] == key[j][0] and abs(key[i][1] - key[j][1]) <= 1:
            continue
        d = float(np.linalg.norm(X[i] - X[j]))
        for c in CUTS:
            if d <= c:
                counts[c] += 1
        if d <= 3.4:
            for k in (i, j):
                lbl = "%s%d" % (at[k][1].capitalize(), key[k][1])
                per_res[lbl] = per_res.get(lbl, 0) + 1
    n = len(at)
    print("%-22s %5d heavy atoms | C..C  <=3.2A %4d   <=3.4A %4d   <=3.6A %4d | "
          "%5.1f per 1000 atoms"
          % (tag, n, counts[3.2], counts[3.4], counts[3.6], 1000.0 * counts[3.4] / n))
    top = sorted(per_res.items(), key=lambda x: -x[1])[:6]
    if top:
        print("%-22s worst: %s" % ("", ", ".join("%s(%d)" % t for t in top)))
    return {"tag": tag, "atoms": n,
            "cc_3_2": counts[3.2], "cc_3_4": counts[3.4], "cc_3_6": counts[3.6],
            "per_1000": round(1000.0 * counts[3.4] / n, 1),
            "worst": top}


if __name__ == "__main__":
    out = [audit(a.split("=")[0], a.split("=")[1]) for a in sys.argv[1:]]
    json.dump(out, open("out/packing_audit.json", "w"), indent=2)
