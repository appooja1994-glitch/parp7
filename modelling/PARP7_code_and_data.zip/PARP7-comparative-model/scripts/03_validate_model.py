#!/usr/bin/env python3
"""
Check the model where it matters: the NAD+ pocket.

Generic validation servers (MolProbity, ProSA, Verify3D) tell you the model is a
plausible protein. They cannot tell you the nicotinamide sub-pocket is correctly
formed. This does that, by measuring the contacts the retained inhibitor makes.

    python 03_validate_model.py [model.pdb]
"""
import os, sys, math
from Bio.PDB import PDBParser, Superimposer

POCKET = {532: 'catalytic His', 533: 'Gly - bidentate anchor',
          538: 'PARP7-specific', 541: 'PARP7-specific', 545: 'PARP7-specific',
          564: 'Tyr - aromatic wall', 566: 'Ala - hydrophobic',
          572: 'Ser - H-bond to lactam O', 575: 'Phe - stacking platform'}
SKIP = {'HOH', 'WAT', 'CL', 'NA', 'SO4', 'GOL', 'EDO'}


def centroid(atoms):
    n = len(atoms)
    return [sum(a.coord[i] for a in atoms) / n for i in range(3)]


def dist(a, b):
    return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(3)))


def main():
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    os.chdir(root)
    path = sys.argv[1] if len(sys.argv) > 1 else '03_model/PARP7_model_primary.pdb'
    if not os.path.exists(path):
        sys.exit(f"{path} not found - run 02_model_parp7.py first")

    st = PDBParser(QUIET=True).get_structure('m', path)
    ch = next(st[0].get_chains())

    res = {r.id[1]: r for r in ch if r.id[0] == ' '}
    lig = [r for r in ch if r.id[0] != ' ' and r.resname.strip() not in SKIP]

    print(f"model: {path}")
    print(f"  residues {min(res)}-{max(res)} ({len(res)} present)")
    print(f"  ligand: {[r.resname.strip() for r in lig] or 'none (apo model)'}\n")

    print("pocket residues present:")
    missing = []
    for n, role in sorted(POCKET.items()):
        r = res.get(n)
        if r is None:
            missing.append(n); print(f"  {n:>4}  MISSING   {role}"); continue
        print(f"  {r.resname} {n:<5} {role}")
    if missing:
        print(f"\nFAIL: pocket residues absent: {missing}")
        return 1

    ok = True
    if lig:
        la = [a for r in lig for a in r]
        print("\ncontacts to the retained ligand:")

        g = res[533]
        for an, label, lo, hi in [('N', 'Gly533 N-H  -> ligand acceptor', 2.6, 3.4),
                                  ('O', 'Gly533 C=O  -> ligand donor   ', 2.6, 3.4)]:
            if an not in g:
                print(f"  {label}: backbone atom {an} absent"); ok = False; continue
            d = min(dist(g[an].coord, a.coord) for a in la
                    if a.element in ('N', 'O'))
            flag = 'OK' if lo <= d <= hi else ('close' if d < lo else 'TOO FAR')
            print(f"  {label}: {d:5.2f} A   {flag}")
            if not (lo <= d <= hi):
                ok = False

        s = res[572]
        if 'OG' in s:
            d = min(dist(s['OG'].coord, a.coord) for a in la if a.element in ('N', 'O'))
            flag = 'OK' if 2.5 <= d <= 3.4 else 'check'
            print(f"  Ser572 OG   -> ligand O/N     : {d:5.2f} A   {flag}")
        else:
            print("  Ser572 OG absent"); ok = False

    y = [a for a in res[564] if a.name in ('CG','CD1','CD2','CE1','CE2','CZ')]
    f = [a for a in res[575] if a.name in ('CG','CD1','CD2','CE1','CE2','CZ')]
    if len(y) >= 6 and len(f) >= 6:
        d = dist(centroid(y), centroid(f))
        flag = 'OK' if 5.5 <= d <= 9.0 else ('COLLAPSED' if d < 5.5 else 'too open')
        print(f"\naromatic cleft Tyr564 <-> Phe575 centroid: {d:5.2f} A   {flag}")
        if not (5.5 <= d <= 9.0):
            ok = False
    else:
        print("\ncould not measure the aromatic cleft (side chains incomplete)")
        ok = False

    # how far are the truncation points from the pocket? (MD construct sanity)
    pa = [res[n]['CA'] for n in POCKET if n in res and 'CA' in res[n]]
    for term, n in (('N-terminal', min(res)), ('C-terminal', max(res))):
        if 'CA' in res[n]:
            d = min(dist(res[n]['CA'].coord, a.coord) for a in pa)
            flag = 'OK' if d > 15 else 'TOO CLOSE - caps may perturb the site'
            print(f"{term} truncation (res {n}) is {d:5.1f} A from the nearest "
                  f"pocket residue   {flag}")

    print("\n" + ("PASS - pocket geometry is consistent with the holo template."
                  if ok else
                  "FAIL - pocket geometry is wrong. Do not dock against this model."))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
