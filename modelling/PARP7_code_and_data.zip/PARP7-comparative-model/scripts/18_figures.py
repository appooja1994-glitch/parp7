#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Manuscript and thesis figures. Every figure is built from a file written
by one of the analysis scripts, so a figure cannot drift from its data."""
import csv, json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

OUT = os.environ.get("PARP7_FIGDIR", "figures")
os.makedirs(OUT, exist_ok=True)

C = {"blue": "#2a78d6", "orange": "#eb6834", "aqua": "#1baf7a", "yellow": "#eda100",
     "ink": "#0b0b0b", "ink2": "#55544e", "muted": "#8a8880",
     "grid": "#e1e0d9", "axis": "#c3c2b7", "surface": "#ffffff"}

plt.rcParams.update({
    "figure.dpi": 150, "savefig.dpi": 300,
    "font.family": "DejaVu Sans", "font.size": 8.5,
    "axes.edgecolor": C["axis"], "axes.linewidth": 0.8,
    "axes.labelcolor": C["ink"], "axes.titlesize": 9.5,
    "axes.titleweight": "bold", "axes.titlecolor": C["ink"],
    "xtick.color": C["ink2"], "ytick.color": C["ink2"],
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
    "grid.color": C["grid"], "grid.linewidth": 0.6,
    "legend.frameon": False, "legend.fontsize": 7.5,
    "savefig.bbox": "tight", "savefig.facecolor": C["surface"],
})


def finish(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig("%s/%s.%s" % (OUT, name, ext))
    plt.close(fig)
    print("  %s.png / .pdf" % name)


def tidy(ax, grid="y"):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    if grid:
        ax.grid(axis=grid, zorder=0)
        ax.set_axisbelow(True)


# ------------------------------------------------------------------ Figure 1
def _read_select_log(path=os.environ.get("PARP7_SELECT_LOG",
                                        "04_validation/select_all.log")):
    """All 100 assessed models. The CSV companion holds only the leading 25."""
    rows = []
    for line in open(path):
        if not line.startswith("PARP7_ART.B9999"):
            continue
        f = line.split()
        rows.append({"model": f[0], "zDOPE": float(f[1]), "clash": int(f[3]),
                     "lys554": float(f[4]), "g533_N": float(f[5]),
                     "g533_O": float(f[6]), "s572": float(f[7]),
                     "cleft": float(f[8]), "pass": line.rstrip().endswith("PASS"),
                     "fails": "" if line.rstrip().endswith("PASS")
                              else line.split("fail:")[-1].strip()})
    seen, uniq = set(), []
    for r in rows:
        if r["model"] in seen:
            continue
        seen.add(r["model"]); uniq.append(r)
    return uniq


def fig1_selection():
    rows = _read_select_log()
    z = np.array([r["zDOPE"] for r in rows])
    lys = np.array([r["lys554"] for r in rows])
    ok = np.array([r["pass"] for r in rows])
    name = [r["model"] for r in rows]
    cand = {"PARP7_ART.B99990015.pdb": "1", "PARP7_ART.B99990089.pdb": "2",
            "PARP7_ART.B99990098.pdb": "3"}

    fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.6, 3.3),
                                 gridspec_kw={"width_ratios": [1.3, 1]})
    a1.axhline(3.0, color=C["orange"], lw=1.2, ls="--", zorder=1)
    a1.text(z.min() - 0.005, 3.04, "Lys554 cut-off 3.0 \u00c5", color=C["orange"],
            fontsize=7, va="bottom")
    a1.scatter(z[~ok], lys[~ok], s=20, facecolor="none", edgecolor=C["muted"],
               lw=0.8, zorder=2, label="rejected (%d)" % int((~ok).sum()))
    a1.scatter(z[ok], lys[ok], s=24, color=C["blue"], zorder=3,
               label="passed all criteria (%d)" % int(ok.sum()))
    for i, n in enumerate(name):
        if n in cand:
            a1.scatter([z[i]], [lys[i]], s=95, facecolor="none",
                       edgecolor=C["ink"], lw=1.3, zorder=5)
            dy = {"1": (8, 5), "2": (8, 5), "3": (9, -11)}[cand[n]]
            a1.annotate("candidate %s" % cand[n], (z[i], lys[i]),
                        textcoords="offset points", xytext=dy,
                        fontsize=7.2, color=C["ink"], weight="bold", zorder=6)
    a1.set_xlabel("normalised DOPE (z-DOPE)")
    a1.set_ylabel("Lys554 side chain \u2013 ligand closest approach (\u00c5)")
    a1.set_title("a   Ensemble screening, 100 models", pad=24)
    a1.legend(loc="lower left", bbox_to_anchor=(0.0, 1.0), ncol=2,
              borderaxespad=0.2)
    tidy(a1, grid="both")

    gate = [("candidate 1\nB99990015", [1.05, 1.32, 0.99], C["blue"]),
            ("candidate 2\nB99990089", [1.28, 1.27, 1.25], C["blue"]),
            ("candidate 3\nB99990098", [0.73, 0.73, 0.75], C["aqua"])]
    xs = np.arange(len(gate)); w = 0.25
    for k, (lab, vals, col) in enumerate(gate):
        for sdx, v in enumerate(vals):
            a2.bar(xs[k] + (sdx - 1) * w, v, w * 0.86, color=col, zorder=3,
                   edgecolor=C["surface"], linewidth=0.6)
        a2.text(xs[k], max(vals) + (0.30 if k == 1 else 0.10),
                "%.2f / %.2f / %.2f" % tuple(vals), ha="center",
                fontsize=6.6, color=C["ink2"])
    a2.axhline(2.0, color=C["orange"], lw=1.2, ls="--", zorder=4)
    a2.text(2.45, 2.04, "pass \u2264 2.0 \u00c5", color=C["orange"], fontsize=7,
            ha="right", va="bottom")
    a2.set_xticks(xs); a2.set_xticklabels([g[0] for g in gate], fontsize=7)
    a2.set_ylabel("top-pose RMSD to crystal pose (\u00c5)")
    a2.set_ylim(0, 2.3)
    a2.set_title("b   Redocking gate, three seeds each", pad=24)
    a2.legend(handles=[Line2D([], [], color=C["blue"], lw=5, label="not selected"),
                       Line2D([], [], color=C["aqua"], lw=5, label="selected")],
              loc="lower left", bbox_to_anchor=(0.0, 1.0), ncol=2,
              fontsize=7, borderaxespad=0.2)
    tidy(a2)
    finish(fig, "Fig1_model_selection")


# ------------------------------------------------------------------ Figure 2
def fig2_site_fidelity():
    rows = json.load(open("out/compare.json"))
    rows = [r for r in rows if r["d_model"] is not None and r["d_xtal"] is not None]
    x = np.array([r["d_xtal"] for r in rows])
    y = np.array([r["d_model"] for r in rows])
    sub = np.array(["substitution" in (r["note"] or "") for r in rows])

    fig, ax = plt.subplots(figsize=(4.0, 3.9))
    lo, hi = 2.4, 6.3
    ax.plot([lo, hi], [lo, hi], color=C["axis"], lw=1.0, zorder=1)
    for off, lw in ((0.5, 0.7),):
        ax.fill_between([lo, hi], [lo - off, hi - off], [lo + off, hi + off],
                        color=C["grid"], alpha=0.45, zorder=0, lw=0)
    ax.scatter(x[~sub], y[~sub], s=30, color=C["blue"], zorder=3,
               label="conserved position (30)")
    ax.scatter(x[sub], y[sub], s=46, color=C["orange"], marker="D", zorder=4,
               label="PARP7/PARP12 substitution (2)")
    for r in rows:
        if abs(r["d_model"] - r["d_xtal"]) > 0.6 or "substitution" in (r["note"] or ""):
            ax.annotate(r["parp7"], (r["d_xtal"], r["d_model"]),
                        textcoords="offset points", xytext=(6, -2),
                        fontsize=7, color=C["ink"])
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)
    ax.set_xlabel("closest approach in 6V3W crystal (Å)")
    ax.set_ylabel("closest approach in refined model (Å)")
    ax.set_title("Binding-site geometry, 32 shared residues")
    ax.text(0.04, 0.95, "mean |Δ| = 0.21 Å\n31 of 32 within 0.5 Å",
            transform=ax.transAxes, fontsize=7.5, va="top", color=C["ink2"])
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.14), ncol=2,
              borderaxespad=0.0)
    tidy(ax, grid="both")
    finish(fig, "Fig2_site_fidelity")


# ------------------------------------------------------------------ Figure 3
def fig3_interactions():
    rows = list(csv.DictReader(open("out/tables/tableA_hbonds.csv")))
    keep = [r for r in rows
            if r["6V3W crystal"] != "-" and r["Model, refined"] != "-"
            and float(r["6V3W crystal"]) <= 3.3]
    keep.sort(key=lambda r: float(r["6V3W crystal"]))
    labels = ["%s \u00b7\u00b7\u00b7 %s" % (r["protein_atom"], r["ligand_atom"])
              for r in keep]
    cols = [("6V3W crystal", C["blue"], "o"), ("Model, as built", C["orange"], "s"),
            ("Model, refined", C["aqua"], "D"), ("Vina top pose", C["yellow"], "^")]
    y = np.arange(len(keep))[::-1]

    fig, ax = plt.subplots(figsize=(6.2, 3.1))
    for yi, r in zip(y, keep):
        vals = [float(r[c]) for c, _, _ in cols if r[c] != "-"]
        ax.plot([min(vals), max(vals)], [yi, yi], color=C["grid"], lw=4,
                solid_capstyle="round", zorder=2)
    for col, colour, mk in cols:
        v = [float(r[col]) if r[col] != "-" else np.nan for r in keep]
        ax.scatter(v, y, s=42, color=colour, marker=mk, zorder=4, label=col,
                   edgecolor=C["surface"], linewidth=0.7)
    ax.set_yticks(y); ax.set_yticklabels(labels, fontsize=7.5)
    ax.set_xlim(2.6, 3.6)
    ax.set_ylim(-0.7, len(keep) - 0.3)
    ax.set_xlabel("donor\u00b7\u00b7\u00b7acceptor distance (\u00c5)")
    ax.set_title("Hydrogen bonds to RBN-2397")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.16), ncol=4,
              borderaxespad=0.0)
    tidy(ax, grid="x")
    finish(fig, "Fig3_hydrogen_bonds")


# ------------------------------------------------------------------ Figure 4
def fig4_gate():
    rows = list(csv.DictReader(open("out/pose_rmsd.csv")))
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 3.0),
                                 gridspec_kw={"width_ratios": [1.25, 1]})
    cols = [C["blue"], C["orange"], C["aqua"]]
    for s in (1, 2, 3):
        rr = sorted([r for r in rows if int(r["seed"]) == s],
                    key=lambda r: int(r["rank"]))
        a1.plot([int(r["rank"]) for r in rr], [float(r["rmsd"]) for r in rr],
                "-o", color=cols[s - 1], ms=3.4, lw=1.3, zorder=3,
                label="seed %d" % s)
    a1.axhline(2.0, color=C["ink2"], lw=1.0, ls="--", zorder=2)
    a1.text(20, 2.12, "2.0 Å", fontsize=7, color=C["ink2"], ha="right")
    a1.set_xlabel("pose rank (Vina)"); a1.set_ylabel("RMSD to crystal pose (Å)")
    a1.set_title("a   All 20 poses per run")
    a1.set_xticks([1, 5, 10, 15, 20])
    a1.legend(loc="lower right"); tidy(a1, grid="both")

    sc = np.array([float(r["score"]) for r in rows])
    rm = np.array([float(r["rmsd"]) for r in rows])
    rk = np.array([int(r["rank"]) for r in rows])
    a2.scatter(sc[rk > 1], rm[rk > 1], s=22, facecolor="none",
               edgecolor=C["muted"], lw=0.8, zorder=3, label="ranks 2–20")
    a2.scatter(sc[rk == 1], rm[rk == 1], s=52, color=C["aqua"], zorder=4,
               label="top-ranked pose")
    a2.axhline(2.0, color=C["ink2"], lw=1.0, ls="--", zorder=2)
    a2.set_xlabel("Vina score (kcal mol$^{-1}$)")
    a2.set_ylabel("RMSD to crystal pose (Å)")
    a2.set_title("b   Score against accuracy")
    a2.legend(loc="upper left"); tidy(a2, grid="both")
    finish(fig, "Fig4_redocking_gate")


# ------------------------------------------------------------------ Figure 5
def fig5_packing():
    data = json.load(open("out/packing_audit.json"))
    names = {"6V3W_crystal": "6V3W\ncrystal", "AlphaFold_ART": "AlphaFold\nART",
             "Model_as_built": "Model\nas built", "Model_refined": "Model\nrefined"}
    order = ["6V3W_crystal", "AlphaFold_ART", "Model_as_built", "Model_refined"]
    d = dict((x["tag"], x) for x in data)
    xs = np.arange(len(order)); w = 0.26
    fig, ax = plt.subplots(figsize=(4.6, 3.2))
    for k, (field, lab, colour) in enumerate(
            [("cc_3_2", "≤ 3.2 Å", C["blue"]),
             ("cc_3_4", "≤ 3.4 Å", C["orange"]),
             ("cc_3_6", "≤ 3.6 Å", C["aqua"])]):
        v = [d[o][field] for o in order]
        ax.bar(xs + (k - 1) * w, v, w * 0.9, color=colour, zorder=3, label=lab,
               edgecolor=C["surface"], linewidth=0.6)
        for xi, vi in zip(xs + (k - 1) * w, v):
            ax.text(xi, vi + 4, str(vi), ha="center", fontsize=6.4, color=C["ink2"])
    ax.set_xticks(xs); ax.set_xticklabels([names[o] for o in order], fontsize=7.5)
    ax.set_ylabel("non-local C···C contacts")
    ax.set_title("Side-chain packing before and after refinement")
    ax.legend(title="separation", title_fontsize=7.5, loc="upper left")
    tidy(ax)
    finish(fig, "Fig5_packing")


# ------------------------------------------------------------------ Figure 6
def fig6_dope():
    src = os.environ.get("PARP7_DOPE_PROFILES",
                         "04_validation/dope_profiles.csv")
    rows = list(csv.DictReader(open(src)))
    res = np.array([int(r["residue"]) for r in rows]) + 461   # 1 -> PARP7 462
    series = [("AF_PARP7_ART", "AlphaFold, z-DOPE −1.668", C["blue"]),
              ("PARP7_model_primary", "apo build, z-DOPE −1.107", C["orange"]),
              ("candidate3", "holo build (final), z-DOPE −0.698", C["aqua"])]
    fig, ax = plt.subplots(figsize=(7.2, 2.9))
    for key, lab, colour in series:
        v = np.array([float(r[key]) if r[key] else np.nan for r in rows])
        ax.plot(res[:len(v)], v, lw=1.1, color=colour, label=lab, zorder=3)
    for r0, r1 in [(531, 534), (541, 548), (562, 576)]:
        ax.axvspan(r0, r1, color=C["grid"], alpha=0.8, lw=0, zorder=1)
    ax.text(552, ax.get_ylim()[1] * 0.92, "pocket-forming segments",
            fontsize=7, color=C["ink2"], ha="center")
    ax.set_xlabel("PARP7 residue"); ax.set_ylabel("per-residue DOPE")
    ax.set_title("Per-residue DOPE profile")
    ax.legend(ncol=3, loc="lower center"); tidy(ax, grid="y")
    finish(fig, "Fig6_dope_profile")


if __name__ == "__main__":
    print("writing figures to %s" % OUT)
    fig1_selection(); fig2_site_fidelity(); fig3_interactions()
    fig4_gate(); fig5_packing(); fig6_dope()
