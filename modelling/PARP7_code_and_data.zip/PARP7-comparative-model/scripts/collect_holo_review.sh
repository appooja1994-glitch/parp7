#!/usr/bin/env bash
# Package the holo build for review.
#   conda activate parp7 && bash scripts/collect_holo_review.sh
# Produces parp7_holo_review.zip in the project folder.
set -uo pipefail

OUT=parp7_holo_review
rm -rf "$OUT" "$OUT.zip"
mkdir -p "$OUT"/{01_sequence,02_template,03_model,03_model/top20,03_model/candidates,04_validation,05_site,logs}

copy() { [ -f "$1" ] && cp "$1" "$2" && echo "  + $1" || echo "  - $1 (absent)"; }

echo "==> inputs"
copy 01_sequence/PARP7_Q7Z3E1.fasta "$OUT/01_sequence/"
copy 02_template/6V3W.pdb           "$OUT/02_template/"
copy 02_template/6v3wA.pdb          "$OUT/02_template/"

echo "==> alignment"
copy 03_model/parp7_6v3w.ali       "$OUT/03_model/"
copy 03_model/alignment_report.txt "$OUT/03_model/"
copy 03_model/model_scores.csv     "$OUT/03_model/"

echo "==> models"
copy 03_model/PARP7_model_primary.pdb "$OUT/03_model/"
copy 03_model/PARP7_FINAL.pdb         "$OUT/03_model/"
copy 03_model/AF_PARP7_ART.pdb        "$OUT/03_model/"
for f in 03_model/candidates/*.pdb; do copy "$f" "$OUT/03_model/candidates/"; done

echo "==> the twenty best models (so the ensemble can be re-triaged independently)"
python - <<'PY'
import csv, os, shutil
src = "03_model/model_scores.csv"
if not os.path.exists(src):
    print("  - model_scores.csv absent"); raise SystemExit
rows = sorted(csv.DictReader(open(src)), key=lambda r: float(r["zDOPE"]))
n = 0
for r in rows[:20]:
    p = os.path.join("03_model", os.path.basename(r["model"]))
    if os.path.exists(p):
        shutil.copy(p, "parp7_holo_review/03_model/top20/"); n += 1
print("  + %d model files (of %d scored)" % (n, len(rows)))
PY

echo "==> docking"
copy 05_site/vina_box.conf            "$OUT/05_site/"
copy 05_site/reference_from_model.pdb "$OUT/05_site/"
copy 05_site/reference.sdf            "$OUT/05_site/"
copy 05_site/probe.sdf                "$OUT/05_site/"
for f in 05_site/redock_seed*.sdf 05_site/redock_seed*.pdbqt; do copy "$f" "$OUT/05_site/"; done

echo "==> existing validation output"
copy 04_validation/selection_table.csv "$OUT/04_validation/"
for f in 04_validation/gate_cand*.log; do copy "$f" "$OUT/logs/"; done

echo "==> re-running the quick checks to capture their output"
python scripts/07_select_model.py --all > "$OUT/logs/select_all.log" 2>&1 || true
python scripts/03_validate_model.py      > "$OUT/logs/validate.log"   2>&1 || true
python scripts/04_alphafold_compare.py   > "$OUT/logs/alphafold.log"  2>&1 || true
echo "  + logs/"

echo "==> environment"
{
  echo "date : $(date)"
  echo "host : $(hostname)"
  python -c "import sys; print('python   : '+sys.version.split()[0])"
  python -c "import modeller; print('modeller : '+modeller.__version__)" 2>/dev/null
  python -c "import Bio; print('biopython: '+Bio.__version__)" 2>/dev/null
  python -c "from rdkit import Chem; print('rdkit    : '+Chem.rdBase.rdkitVersion)" 2>/dev/null
  vina --version 2>&1 | head -1 | sed 's/^/vina     : /'
  obabel -V 2>&1 | head -1 | sed 's/^/openbabel: /'
} > "$OUT/logs/versions.txt" 2>&1
cat "$OUT/logs/versions.txt" | sed 's/^/  /'

echo
echo "==> if you have run the external servers, drop their reports in:"
echo "    $OUT/04_validation/    (MolProbity, SAVES, ProSA, QMEAN - any format)"
echo "    Not required; say so and I will note them as outstanding."

zip -qr "$OUT.zip" "$OUT"
echo
echo "Created $(pwd)/$OUT.zip  ($(du -h "$OUT.zip" | cut -f1))"
echo "Send that file."
