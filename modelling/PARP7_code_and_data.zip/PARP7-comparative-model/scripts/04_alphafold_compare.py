#!/usr/bin/env python3
"""
Extract the AlphaFold ART domain, read its confidence, and compare it with the
template-based model.

AlphaFold is the independent check here, not the primary receptor: it has no
ligand to define the pocket, and side-chain placement in an empty cavity is its
weakest feature. This script tells you whether the two models agree where it
matters.

    python 04_alphafold_compare.py
"""
import os, sys, statistics as st
from Bio.PDB import PDBParser, PDBIO, Superimposer, Select

LO, HI = 458, 648
POCKET = [532, 533, 538, 541, 545, 564, 566, 572, 575]


class Domain(Select):
    def accept_residue(self, r):
        return r.id[0] == ' ' and LO <= r.id[1] <= HI


def main():
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    os.chdir(root)

    af_in = None
    for cand in ('03_model/AF-Q7Z3E1-F1.pdb',
                 '03_model/AF-Q7Z3E1-F1-model_v4.pdb'):
        if os.path.exists(cand):
            af_in = cand; break
    if af_in is None:
        sys.exit("AlphaFold model not found in 03_model/ - run 00_fetch.sh")

    p = PDBParser(QUIET=True)
    af = p.get_structure('af', af_in)

    io = PDBIO(); io.set_structure(af)
    io.save('03_model/AF_PARP7_ART.pdb', Domain())
    print(f"wrote 03_model/AF_PARP7_ART.pdb  (residues {LO}-{HI})")

    # pLDDT lives in the B-factor column
    ch = next(af[0].get_chains())
    pl = {r.id[1]: r['CA'].bfactor for r in ch
          if r.id[0] == ' ' and 'CA' in r and LO <= r.id[1] <= HI}
    vals = list(pl.values())
    print(f"\npLDDT over {LO}-{HI}: mean {st.mean(vals):.1f}, "
          f"min {min(vals):.1f}, max {max(vals):.1f}")
    low = [n for n, v in pl.items() if v < 70]
    if low:
        print(f"  {len(low)} residues below 70 (low confidence): "
              f"{low[:12]}{' ...' if len(low) > 12 else ''}")
    print("\n  pocket residue confidence:")
    weak = []
    for n in POCKET:
        v = pl.get(n)
        if v is None:
            print(f"    {n}: absent"); continue
        tag = 'very high' if v >= 90 else 'confident' if v >= 70 else 'LOW'
        print(f"    {n:>4}: pLDDT {v:5.1f}   {tag}")
        if v < 70:
            weak.append(n)
    if weak:
        print(f"  NOTE: pocket residues {weak} are low confidence in AlphaFold. "
              "Prefer the template-based model and say so in your methods.")

    mdl_path = '03_model/PARP7_model_primary.pdb'
    if not os.path.exists(mdl_path):
        print("\n(no MODELLER model yet - run 02_model_parp7.py to compare)")
        return 0

    mdl = p.get_structure('m', mdl_path)
    mch = next(mdl[0].get_chains())
    mres = {r.id[1]: r for r in mch if r.id[0] == ' '}
    ares = {r.id[1]: r for r in next(af[0].get_chains())
            if r.id[0] == ' ' and LO <= r.id[1] <= HI}

    common = sorted(set(mres) & set(ares))
    fixed = [mres[n]['CA'] for n in common if 'CA' in mres[n] and 'CA' in ares[n]]
    moving = [ares[n]['CA'] for n in common if 'CA' in mres[n] and 'CA' in ares[n]]
    sup = Superimposer()
    sup.set_atoms(fixed, moving)
    print(f"\nglobal Ca RMSD over {len(fixed)} residues: {sup.rms:.2f} A")

    sup.apply([a for r in ares.values() for a in r])
    pk = [n for n in POCKET if n in mres and n in ares
          and 'CA' in mres[n] and 'CA' in ares[n]]
    import math
    d = [math.dist(mres[n]['CA'].coord, ares[n]['CA'].coord) for n in pk]
    prms = math.sqrt(sum(x * x for x in d) / len(d))
    print(f"pocket Ca RMSD over {len(pk)} residues:  {prms:.2f} A")

    print()
    if prms < 1.5:
        print("VERDICT  < 1.5 A: the two models agree. Use the template-based")
        print("         model as primary and keep AlphaFold in the docking ensemble.")
    elif prms < 2.5:
        print("VERDICT  1.5-2.5 A: partial agreement. Run the full retrospective")
        print("         validation on BOTH receptors and report both.")
    else:
        print("VERDICT  > 2.5 A: STOP. Re-inspect the Step 5 alignment and the")
        print("         pLDDT of the pocket residues before going further.")
    return 0


if __name__ == '__main__':
    sys.exit(main())
