import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(11.6, 9.0))
fig.patch.set_facecolor("white")
ink, body = "#1b1b1b", "#3a3a3a"
A_FILL, A_EDGE = "#dce8f3", "#4a7fad"      # approach A
B_FILL, B_EDGE = "#f3e8d8", "#b08d4f"      # approach B
C_FILL, C_EDGE = "#e2eee2", "#5a8a5a"      # shared
OUT_FILL, OUT_EDGE = "#4a6b8a", "#2e4a66"

def box(x, y, w, h, title, sub, fill, edge, tcol=None, fs=9.4, sfs=7.9):
    ax.add_patch(FancyBboxPatch((x - w/2, y - h/2), w, h,
        boxstyle="round,pad=0.035,rounding_size=0.09",
        facecolor=fill, edgecolor=edge, linewidth=1.15, zorder=3))
    tc = tcol or ink
    if sub:
        ax.text(x, y + h*0.17, title, ha="center", va="center",
                fontsize=fs, fontweight="bold", color=tc, zorder=4)
        ax.text(x, y - h*0.21, sub, ha="center", va="center",
                fontsize=sfs, color=tc, linespacing=1.35, zorder=4)
    else:
        ax.text(x, y, title, ha="center", va="center",
                fontsize=fs, fontweight="bold", color=tc, zorder=4)

def arrow(x1, y1, x2, y2, color="#5a6b7a", style="-|>", lw=1.3, rad=0.0):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2),
        arrowstyle=style, mutation_scale=13, linewidth=lw, color=color,
        connectionstyle="arc3,rad=%.2f" % rad, zorder=2))

LX, RX = -3.05, 3.05
W, H = 5.0, 0.92

# ---- headers
ax.text(LX, 7.62, "APPROACH A", ha="center", fontsize=10.2, fontweight="bold",
        color=A_EDGE)
ax.text(LX, 7.30, "Anticancer databases first", ha="center", fontsize=8.6, color=body)
ax.text(RX, 7.62, "APPROACH B", ha="center", fontsize=10.2, fontweight="bold",
        color=B_EDGE)
ax.text(RX, 7.30, "COCONUT wide, then annotate", ha="center", fontsize=8.6, color=body)

# ---- approach A chain
box(LX, 6.55, W, H, "Anticancer source databases",
    "NPASS 3.0, NPCARE, CancerHSP, NPACT\nevery compound has reported activity",
    A_FILL, A_EDGE)
box(LX, 5.25, W, H, "Join and select cancer cell-line actives",
    "target is a cancer cell line\nIC50, GI50 or EC50 at or below 10 µM",
    A_FILL, A_EDGE)
box(LX, 3.95, W, H, "Merge sources on InChIKey",
    "provenance recorded per compound", A_FILL, A_EDGE)

# ---- approach B chain
box(RX, 6.55, W, H, "COCONUT 2.0 complete release",
    "738,795 molecules from 71 collections\nno activity data attached",
    B_FILL, B_EDGE)
box(RX, 5.25, W, H, "Tag the anticancer collections",
    "NPACT, NPCARE, AfroCancer, InPACdb\nmembership recorded, nothing removed",
    B_FILL, B_EDGE)
box(RX, 3.95, W, H, "Diversity selection to target size",
    "all tagged compounds kept\nremainder by sphere exclusion",
    B_FILL, B_EDGE)

for x in (LX, RX):
    arrow(x, 6.55 - H/2, x, 5.25 + H/2)
    arrow(x, 5.25 - H/2, x, 3.95 + H/2)

# ---- converge
arrow(LX, 3.95 - H/2, -0.55, 2.95 + 0.52, rad=-0.16)
arrow(RX, 3.95 - H/2,  0.55, 2.95 + 0.52, rad=0.16)

box(0, 2.95, 7.5, 0.98, "Chemical curation   (identical for both approaches)",
    "sanitise • desalt • neutralise • organic elements only • deglycosylate\n"
    "MW 150–600 Da • at most one Lipinski violation • PAINS flagged • InChIKey dedup",
    C_FILL, C_EDGE, fs=9.6, sfs=7.9)
arrow(0, 2.95 - 0.49, 0, 1.62 + 0.46)

box(0, 1.62, 7.5, 0.92, "Three dimensional preparation",
    "ETKDGv3 embedding • MMFF94 optimisation • Meeko PDBQT with torsion tree",
    C_FILL, C_EDGE, fs=9.6, sfs=7.9)
arrow(0, 1.62 - 0.46, 0, 0.42 + 0.44)

box(0, 0.42, 7.5, 0.88, "SCREENING LIBRARY",
    "anticancer_final.sdf  •  final_molecules.smi  •  pdbqt/  •  annotations.tsv",
    OUT_FILL, OUT_EDGE, tcol="white", fs=10.2, sfs=8.2)
arrow(0, 0.42 - 0.44, 0, -0.72 + 0.40)

box(0, -0.72, 7.5, 0.80, "Molecular docking against the PARP7 catalytic domain model",
    "AutoDock Vina • NAD⁺ site defined by the RBN-2397 pose",
    "#eef1f4", "#8a9aa8", fs=9.6, sfs=7.9)

# ---- side note on the benchmark, kept visually separate
ax.add_patch(FancyBboxPatch((4.30, -1.16), 3.25, 0.90,
    boxstyle="round,pad=0.03,rounding_size=0.07",
    facecolor="#faf0f0", edgecolor="#b07a7a", linewidth=1.0,
    linestyle=(0, (4, 2)), zorder=3))
ax.text(5.925, -0.56, "Benchmark actives, built separately",
        ha="center", fontsize=8.3, fontweight="bold", color="#8a3b3b", zorder=4)
ax.text(5.925, -0.88, "ChEMBL and BindingDB for Q7Z3E1,\n"
                      "with property matched decoys",
        ha="center", fontsize=7.4, color="#8a3b3b", linespacing=1.3, zorder=4)
arrow(4.30, -0.72, 3.76, -0.72, color="#b07a7a", style="-|>", lw=1.0)

ax.set_xlim(-6.1, 7.9)
ax.set_ylim(-1.80, 8.05)
ax.axis("off")
plt.tight_layout()
plt.savefig("workflow.png", dpi=220, bbox_inches="tight", facecolor="white")
print("wrote workflow.png")
